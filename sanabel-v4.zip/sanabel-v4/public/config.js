// إعدادات Firebase لمشروع sanabelaltahoona
// هذي القيم عامة وعادي تكون بالتطبيق، الحماية بقواعد firestore.rules
window.APP_CONFIG = {
  firebase: {
    apiKey: "AIzaSyBNSoNsA8KLtNVKWp2KVPvRPzW65jgilCw",
    authDomain: "sanabelaltahoona-3bec5.firebaseapp.com",
    projectId: "sanabelaltahoona-3bec5",
    storageBucket: "sanabelaltahoona-3bec5.firebasestorage.app",
    messagingSenderId: "69384462717",
    appId: "1:69384462717:web:79d04fccb78ad85455ac14"
  },
  emailDomain: "sanabel.app"
};
