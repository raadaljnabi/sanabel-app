/* ===== الصالة: الجرد + طلبيات الصالة للمطبخ + المستودع + الدوام ===== */
/* ---------- حسابات الجرد ---------- */
const recKey = (d, s) => d + '|' + s;
const hm = d => pad2(d.getHours()) + ':' + pad2(d.getMinutes());
const tlabel = t => { const [h, m] = t.split(':').map(Number); const h12 = h % 12 || 12; return `${h12}:${pad2(m)} ${h < 12 ? 'ص' : 'م'}`; };
const shiftRange = s => { const t = S.settings.shift_times[s]; return `${tlabel(t.start)} - ${tlabel(t.end)}`; };
function currentCtx(now = new Date()) {
  const st = S.settings.shift_times, t = hm(now), d = fmtD(now);
  if (t >= st.am.start && t < st.am.end) return { date: d, shift: 'am' };
  if (t >= st.am.end) return { date: d, shift: 'pm' };
  return { date: addDays(d, -1), shift: 'pm' };
}
function shiftEnd(d, s) { const t = S.settings.shift_times[s]; let e = new Date(d + 'T' + t.end + ':00'); if (t.end <= t.start) e = new Date(e.getTime() + 864e5); return e; }
function assigned(d, s) {
  const sc = S.settings.schedule; const ov = sc.overrides[recKey(d, s)];
  if (ov) return [ov];
  const wd = new Date(d + 'T12:00').getDay();
  return Object.entries(sc.weekly).filter(([id, days]) => days && days[wd] === s && userOf(id)?.active).map(([id]) => id);
}
const scheduleEmpty = () => !Object.values(S.settings.schedule.weekly).some(a => a && a.some(Boolean));
function canEditShift(d, s) {
  if (P('jard_any')) return true;
  if (!P('jard')) return false;
  return scheduleEmpty() || assigned(d, s).includes(S.me.id);
}
function shiftState(d, s) { const r = getRec(d, s); if (!r || (!r.opened && !Object.keys(r.rows || {}).length)) return 'none'; if (r.closed) return 'closed'; return 'open'; }
function handoverDiff(d, s, id) {
  const r = getRec(d, s); if (!r || !r.opened) return null;
  const v = r.rows?.[id]?.open; if (v == null) return null;
  const [pd, ps] = prevOf(d, s); const p = getRec(pd, ps);
  if (!p || !p.closed || p.rows?.[id]?.close == null) return null;
  return r3(v - p.rows[id].close);
}
function getRec(d, s, create) {
  const k = recKey(d, s);
  if (!S.shifts[k] && create) S.shifts[k] = { date: d, shift: s, rows: {}, closed: false, employee_id: null, employee_name: null };
  return S.shifts[k] || null;
}
const prevOf = (d, s) => s === 'am' ? [addDays(d, -1), 'pm'] : [d, 'am'];
function effOpen(d, s, id) {
  const r = getRec(d, s)?.rows?.[id];
  if (r && r.open != null) return r.open;
  const [pd, ps] = prevOf(d, s);
  return getRec(pd, ps)?.rows?.[id]?.close ?? 0;
}
function soldOf(d, s, id) {
  const r = getRec(d, s)?.rows?.[id];
  if (!r || r.close == null) return null;
  return r3(effOpen(d, s, id) + (r.recv || 0) - (r.waste || 0) - r.close);
}
const daySold = (d, id) => Math.max(soldOf(d, 'am', id) || 0, 0) + Math.max(soldOf(d, 'pm', id) || 0, 0);
const dayWaste = (d, id) => (getRec(d, 'am')?.rows?.[id]?.waste || 0) + (getRec(d, 'pm')?.rows?.[id]?.waste || 0);
const shiftPayload = rec => ({ date: rec.date, shift: rec.shift, rows: rec.rows, opened: !!rec.opened, opened_at: rec.opened_at || null, opened_by_name: rec.opened_by_name || null, receipts: rec.receipts || [],
  closed: !!rec.closed, closed_at: rec.closed_at || null, employee_id: rec.employee_id || null, employee_name: rec.employee_name || null, updated_at: new Date().toISOString() });
function saveShiftNow(d, s) { clearTimeout(S.timers[recKey(d, s)]); delete S.timers[recKey(d, s)]; return DB.upsert('shifts', shiftPayload(getRec(d, s))); }
function saveShift(d, s) {
  const k = recKey(d, s); const rec = S.shifts[k];
  const st = $('#saveState'); if (st) st.textContent = 'جارِ الحفظ…';
  clearTimeout(S.timers[k]);
  S.timers[k] = setTimeout(async () => {
    try {
      rec.updated_at = new Date().toISOString();
      await DB.upsert('shifts', shiftPayload(rec));
      const st = $('#saveState'); if (st) st.innerHTML = ic('check') + ' محفوظ';
    } catch (e) { const st = $('#saveState'); if (st) st.textContent = 'تعذّر الحفظ'; toast('تعذّر الحفظ: ' + e.message); }
    delete S.timers[k];
  }, 600);
}

/* ---------- الجرد ---------- */
async function renderJard() {
  const { date, shift } = S; await ensureShifts(addDays(date, -2));
  const rec = getRec(date, shift, true);
  const [pd, ps] = prevOf(date, shift); const prev = getRec(pd, ps);
  const mine = canEditShift(date, shift); const mgr = P('jard_any');
  const its = jardItems();
  const asg = assigned(date, shift).map(id => userOf(id)?.full_name).filter(Boolean);
  const cur = currentCtx(); const isCur = cur.date === date && cur.shift === shift;
  const mleft = Math.round((shiftEnd(date, shift) - Date.now()) / 60000);
  let timeNote = '';
  if (isCur && !rec.closed && mleft <= S.settings.shift_times.remind && mleft > 0) timeNote = `<div class="alert warn">${ic('clock')}<div>باقي ${mleft} دقيقة على نهاية الشفت. سجّل المتبقي وأغلق الشفت.</div></div>`;
  else if (!rec.closed && rec.opened && mleft <= -30) timeNote = `<div class="alert">${ic('alert')}<div>انتهى وقت الشفت ولم يُغلق بعد.</div></div>`;
  const head = `
  <div class="toolbar">${dateCtl('jDate', date)}<div class="seg">${['am', 'pm'].map(s => `<button data-shift="${s}" class="${s === shift ? 'on' : ''}">${SHIFT[s]}</button>`).join('')}</div>
    <span class="muted small">${ic('clock', 'sm')} ${shiftRange(shift)}${isCur ? ' · الشفت الحالي' : ''}</span></div>
  ${timeNote}
  <div class="card jhead"><div class="av">${esc(initials(rec.employee_name || asg[0] || S.me.full_name))}</div>
    <div class="st"><b>${esc(rec.employee_name || asg.join('، ') || 'غير محدد')}</b><div class="muted small">${rec.opened ? `استلم الشفت ${timeAgo(rec.opened_at)}` : asg.length ? 'مسجل على هذا الشفت بالجدول' : 'لا يوجد أحد بالجدول لهذا الشفت'}</div></div>
    ${rec.closed ? `<span class="chip done">${ic('check')} مغلق</span>` : rec.opened ? `<span class="muted small row" id="saveState" style="gap:4px">${ic('check')} محفوظ</span>` : `<span class="chip">لم يُستلم</span>`}</div>`;

  if (!mine && !rec.opened) { $('#view').innerHTML = head + `<div class="card">${empty('user', mgr ? '' : 'أنت غير مسجل على هذا الشفت بجدول الدوام. للتبديل راجع المدير.')}</div>`; return; }

  /* المرحلة الأولى: استلام الشفت بالعد الأعمى */
  if (!rec.opened && !rec.closed) {
    const prevOk = prev && prev.closed;
    $('#view').innerHTML = head + `
    <div class="card pad"><div class="sec" style="margin-top:0">${ic('clip')} استلام الشفت ال${SHIFT[shift]}</div>
      <p class="muted" style="margin:-4px 0 12px">اعدّ الموجود فعلاً بالصالة لكل صنف. أرقام الشفت السابق مخفية حتى يكون العد دقيقاً، والفرق يظهر بعد التأكيد.</p>
      ${prev && !prev.closed ? `<div class="alert warn" style="margin-bottom:12px">${ic('alert')}<div>الشفت ال${SHIFT[ps]} لم يُغلق بعد. يُفضّل إغلاقه أولاً حتى تُحسب فروقات التسليم.</div></div>` : ''}
      <div class="hgrid">${its.map(it => `<label class="hrow"><span>${esc(it.name)} <span class="unit">${esc(it.unit)}</span></span>
        <input class="num" inputmode="${im(it.unit)}" data-h="${it.id}" value="${S.hdraft[recKey(date, shift) + it.id] ?? ''}" placeholder="العدد"></label>`).join('')}</div>
      <div class="row" style="margin-top:14px"><button class="btn p" id="confirmOpen" style="flex:1;padding:13px">${ic('check')} تأكيد العد واستلام الشفت</button>
      ${mgr && prevOk ? `<button class="btn" id="usePrev">استخدام متبقي الشفت السابق</button>` : ''}</div></div>`;
    return;
  }

  /* المرحلة الثانية: أثناء الشفت */
  const editable = mine && !rec.closed;
  const dis = editable ? '' : 'disabled';
  const diffs = its.map(it => [it, handoverDiff(date, shift, it.id)]).filter(([, d]) => d);
  const pendingOrders = S.porders.filter(o => o.status !== 'done' && o.for_date <= addDays(date, 1));
  const receipts = rec.receipts || [];
  $('#view').innerHTML = head + `
  ${diffs.length ? `<div class="alert" style="margin-bottom:12px">${ic('alert')}<div><b>فروقات بالتسليم من الشفت ال${SHIFT[ps]}:</b> ${diffs.map(([it, d]) => `${esc(it.name)} <b dir="ltr">${d > 0 ? '+' : ''}${d}</b>`).join('، ')}</div></div>` : ''}
  ${editable ? `<div class="row" style="margin-bottom:12px"><button class="btn p" id="kitchenRecv">${ic('chef')} استلام من المطبخ${pendingOrders.length ? ` <span class="badge" style="background:#fff;color:var(--accent-d)">${pendingOrders.length}</span>` : ''}</button>
    <button class="btn" id="manualRecv">${ic('plus')} وارد بدون طلبية</button></div>` : ''}
  <div class="jgrid">${its.map(it => {
    const r = rec.rows[it.id] || {}; const m = im(it.unit); const hd = handoverDiff(date, shift, it.id);
    const wb = Object.entries(r.wasteBy || {}).filter(([, q]) => q).map(([k, q]) => `${k} ${q}`).join('، ');
    return `<div class="card item" data-id="${it.id}"><div class="ih"><b>${esc(it.name)} <span class="unit">${esc(it.unit)}</span></b><span class="sold" data-sold></span></div>
      <div class="nums">
        <label>بداية<input class="num auto" inputmode="${m}" data-f="open" value="${r3(effOpen(date, shift, it.id))}" ${editable && mgr ? '' : 'disabled'}></label>
        <label>وارد<input class="num auto" inputmode="${m}" data-f="recv" value="${r.recv ?? 0}" ${editable && mgr ? '' : 'disabled'}></label>
        <label>تالف<button class="num wbtn" data-waste="${it.id}" ${dis}>${r.waste || 0}</button></label>
        <label>متبقي<input class="num" inputmode="${m}" data-f="close" value="${r.close ?? ''}" placeholder="—" ${dis}></label>
      </div>${hd || wb ? `<div class="inote">${hd ? `<span class="chip red">فرق تسليم <b dir="ltr">${hd > 0 ? '+' : ''}${hd}</b></span>` : ''}${wb ? `<span class="muted">تالف: ${esc(wb)}</span>` : ''}</div>` : ''}</div>`; }).join('')}</div>
  <div class="totbar"><div class="card"><span>المبيع</span><b id="tSold">0</b></div><div class="card"><span>التالف</span><b id="tWaste">0</b></div><div class="card"><span>المتبقي</span><b id="tClose">0</b></div></div>
  ${receipts.length ? `<div class="card pad" style="margin-bottom:14px"><div class="sec" style="margin-top:0">الوارد خلال الشفت</div>
    <div class="feed">${receipts.map(rc => `<div class="ev"><span class="ic">${ic(rc.order_id ? 'chef' : 'plus')}</span><div><p>${Object.entries(rc.lines || {}).filter(([, q]) => q).map(([id, q]) => `${esc(itemOf(id)?.name || '')} ${q}`).join('، ')}</p>
      <small>${rc.order_id ? 'من طلبية المطبخ' : 'بدون طلبية'}${rc.note ? ' · ' + esc(rc.note) : ''} · ${esc(rc.by_name || '')} · ${timeAgo(rc.at)}</small></div></div>`).join('')}</div></div>` : ''}
  ${rec.closed ? (P('reopen') ? `<button class="btn w" id="reopen">${ic('edit')} فتح الشفت للتعديل</button>` : `<p class="muted small" style="text-align:center">الشفت مغلق. لإعادة فتحه راجع المدير.</p>`)
    : editable ? `<button class="btn d w" id="closeShift" style="padding:13px">${ic('check')} إغلاق الشفت ال${SHIFT[shift]}</button>` : ''}`;
  updateSold();
}
function updateSold() {
  const { date, shift } = S; const A = [], W = [], C = [];
  $$('.item[data-id]').forEach(row => {
    const id = row.dataset.id, u = itemOf(id).unit, r = getRec(date, shift)?.rows?.[id] || {};
    const s = soldOf(date, shift, id), el = row.querySelector('[data-sold]');
    el.className = 'sold' + (s != null && s < 0 ? ' bad' : '');
    el.innerHTML = s == null ? 'المبيع: —' : (s < 0 ? 'خطأ بالعد ' : 'المبيع ') + `<strong dir="ltr">${s}</strong>`;
    A.push([u, Math.max(s || 0, 0)]); W.push([u, r.waste || 0]); C.push([u, r.close || 0]);
  });
  if ($('#tSold')) { $('#tSold').textContent = byUnit(A); $('#tWaste').textContent = byUnit(W); $('#tClose').textContent = byUnit(C); }
}
function openWaste(id) {
  const it = itemOf(id), r = getRec(S.date, S.shift).rows[id] || {};
  modal(`<h2>تالف: ${esc(it.name)}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <p class="hint" style="margin-top:-6px">سجّل الكمية حسب السبب (${esc(it.unit)}).</p>
    ${WASTE_REASONS.map(k => `<div class="fline"><span>${k}</span><input class="num" inputmode="${im(it.unit)}" data-wr="${k}" value="${r.wasteBy?.[k] ?? ''}" placeholder="0"><span></span></div>`).join('')}
    <div class="mact"><button class="btn p" id="wasteSave" data-id="${id}">${ic('check')} حفظ</button><button class="btn" data-close>إلغاء</button></div>`);
}
/* الاستلام من المطبخ بالكمية الفعلية */
function pickOrder() {
  const list = S.porders.filter(o => o.status !== 'done').sort((a, b) => a.for_date.localeCompare(b.for_date));
  modal(`<h2>استلام من المطبخ<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    ${list.length ? `<p class="hint" style="margin-top:-6px">اختر الطلبية التي وصلت.</p>` + list.map(o => `<button class="navi" data-pick="${o.id}" style="border:1px solid var(--line);margin-bottom:6px">
      ${ic('chef')}<span style="flex:1">إنتاج ${dayName(o.for_date)}${o.notes ? ' · ' + esc(o.notes) : ''}<br><small class="muted">${Object.values(o.lines || {}).filter(Boolean).length} صنف · ${esc(userOf(o.chef_id)?.full_name || '')}</small></span><span class="chip ${o.status}">${OST[o.status]}</span></button>`).join('')
      : empty('chef', 'لا توجد طلبيات مفتوحة')}
    <button class="btn w" id="manualRecv" style="margin-top:8px">${ic('plus')} وارد بدون طلبية</button>`);
}
function openReceive(o, target) {
  S.rcv = { o, target: target || null };
  const its = o ? Object.keys(o.lines || {}).filter(id => o.lines[id] > 0).map(itemOf).filter(Boolean) : jardItems();
  modal(`<h2>${o ? `استلام طلبية ${dayName(o.for_date)}` : 'وارد بدون طلبية'}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <p class="hint" style="margin-top:-6px">${o ? 'اعدّ ما وصل فعلاً وعدّل الرقم إذا كان مختلفاً عن المطلوب.' : 'أدخل الكميات التي وصلت للصالة.'}</p>
    ${its.map(it => `<div class="fline"><span>${esc(it.name)} ${o ? `<span class="unit">المطلوب ${o.lines[it.id]}</span>` : `<span class="unit">${esc(it.unit)}</span>`}</span>
      <input class="num" inputmode="${im(it.unit)}" data-rc="${it.id}" value="${o ? o.lines[it.id] : ''}" placeholder="0"><span class="hint">${esc(it.unit)}</span></div>`).join('')}
    ${o ? '' : `<label class="field" style="margin-top:10px"><span>ملاحظة</span><input class="inp" id="rcNote" placeholder="مثلاً: دفعة إضافية"></label>`}
    <div class="mact"><button class="btn p" id="doReceive">${ic('check')} تأكيد الاستلام</button><button class="btn" data-close>إلغاء</button></div>`);
}
async function doReceive() {
  const { o } = S.rcv; const lines = {};
  $$('[data-rc]').forEach(i => { const n = num(i.value); if (n) lines[i.dataset.rc] = n; });
  if (!Object.keys(lines).length) return toast('أدخل كمية واحدة على الأقل');
  let tg = S.rcv.target;
  if (!tg) { const c = currentCtx(); tg = o && o.for_date > c.date ? { date: o.for_date, shift: 'am' } : c; }
  await ensureShifts(tg.date);
  const rec = getRec(tg.date, tg.shift, true);
  rec.receipts = rec.receipts || [];
  rec.receipts.push({ id: uid(), at: new Date().toISOString(), by_name: S.me.full_name, order_id: o ? o.id : null, note: o ? '' : ($('#rcNote')?.value.trim() || ''), lines });
  for (const [id, q] of Object.entries(lines)) { rec.rows[id] = rec.rows[id] || {}; rec.rows[id].recv = r3((rec.rows[id].recv || 0) + q); }
  await saveShiftNow(tg.date, tg.shift);
  if (o) { Object.assign(o, await DB.upsert('kitchen_orders', { ...o, status: 'done', received_lines: lines, received_at: new Date().toISOString(), received_by_name: S.me.full_name })); }
  closeModal(); render();
  toast(`تم الاستلام وإضافته لوارد الشفت ال${SHIFT[tg.shift]}`);
}

/* ---------- طلبيات الصالة للمطبخ (كل طلبية لقسم واحد وشيف محدد) ---------- */
const can = { editJard: () => PA('jard', 'jard_any'), reopen: () => P('reopen'), newOrder: () => P('po_new'), receive: () => P('po_new'), newWh: () => P('wh_req'), issue: () => P('wh_issue') };
const canProd = o => o.chef_id === S.me.id || P('prod_all');
async function suggest(forDate) {
  const night = addDays(forDate, -1); await ensureShifts(addDays(night, -8));
  const days = Array.from({ length: 7 }, (_, i) => addDays(night, -i)); const out = {};
  for (const it of jardItems()) {
    let sum = 0, n = 0;
    days.forEach(d => { const a = soldOf(d, 'am', it.id), p = soldOf(d, 'pm', it.id); if (a != null || p != null) { sum += Math.max(a || 0, 0) + Math.max(p || 0, 0); n++; } });
    const left = getRec(night, 'pm')?.rows?.[it.id]?.close || 0;
    const need = n ? Math.max(0, sum / n - left) : null;
    out[it.id] = need == null ? '' : isW(it.unit) ? Math.ceil(need * 2) / 2 : Math.ceil(need);
  }
  return out;
}
function renderOrders() {
  const f = S.ofilter, onlyChef = P('prod') && !P('po_new') && !P('prod_all');
  let list = [...S.porders];
  if (onlyChef || (P('prod') && S.mine)) list = list.filter(o => o.chef_id === S.me.id);
  if (S.pdept) list = list.filter(o => (o.dept || '') === S.pdept);
  const cnt = s => list.filter(o => s === 'open' ? o.status !== 'done' : s === 'all' ? true : o.status === s).length;
  list = list.filter(o => f === 'open' ? o.status !== 'done' : f === 'all' ? true : o.status === f)
    .sort((a, b) => (a.status === 'done') - (b.status === 'done') || b.for_date.localeCompare(a.for_date) || (b.created_at || '').localeCompare(a.created_at || ''));
  const filters = [['open', 'المفتوحة'], ['new', 'جديدة'], ['prod', 'قيد الإنتاج'], ['sent', 'بانتظار الاستلام'], ['done', 'مستلمة'], ['all', 'الكل']];
  $('#view').innerHTML = `
  <div class="toolbar"><div class="filters">${filters.map(([k, l]) => `<button data-of="${k}" class="${k === f ? 'on' : ''}">${l} (${cnt(k)})</button>`).join('')}</div><span class="sp"></span>
  ${onlyChef ? '' : `<select class="inp" id="pDept" style="width:auto"><option value="">كل الأقسام</option>${act(S.depts).map(d => `<option value="${d.id}" ${d.id === S.pdept ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select>`}
  ${P('prod') && !onlyChef ? `<label class="row small muted" style="gap:6px"><input type="checkbox" id="mine" ${S.mine ? 'checked' : ''}> طلبياتي فقط</label>` : ''}
  ${can.newOrder() ? `<button class="btn p" id="newOrder">${ic('plus')} طلبية جديدة للمطبخ</button>` : ''}</div>
  ${list.length ? `<div class="cols2">${list.map(orderCard).join('')}</div>` : empty('chef', 'ماكو طلبيات هنا')}`;
}
function orderCard(o) {
  const lines = Object.entries(o.lines || {}).filter(([, q]) => q > 0);
  const chefN = o.chef_id ? (userOf(o.chef_id)?.full_name || '') : 'غير محدد';
  return `<div class="card ocard s-${o.status}" data-oid="${o.id}">
    <div class="oh"><div><h3>إنتاج ${dayName(o.for_date)} <span class="muted small" dir="ltr">${o.for_date}</span></h3><div class="meta">${deptDot(o.dept)} ${esc(deptName(o.dept))} · الشيف: <b>${esc(chefN)}</b> · من ${esc(o.created_by_name || '—')}</div></div><span class="chip ${o.status}">${OST[o.status]}</span></div>
    <div class="lines">${lines.map(([id, q]) => { const rv = o.received_lines ? (o.received_lines[id] || 0) : null; const df = rv != null && rv !== q;
      return `<span>${esc(itemOf(id)?.name || 'صنف محذوف')}</span><b class="${df ? 'diff' : ''}">${rv != null ? rv : q} <em>${esc(itemOf(id)?.unit || '')}${df ? ` (المطلوب ${q})` : ''}</em></b>`; }).join('')}</div>
    ${o.notes ? `<p class="small muted" style="margin:0 0 10px">ملاحظات: ${esc(o.notes)}</p>` : ''}
    ${o.status === 'done' ? `<p class="small muted" style="margin:0 0 10px">استلمها ${esc(o.received_by_name || '')} · ${timeAgo(o.received_at)}</p>` : ''}
    <div class="oacts">
      ${o.status === 'new' && canProd(o) ? `<button class="btn s" data-act="prod">${ic('play')} بدء الإنتاج</button>` : ''}
      ${o.status !== 'done' && can.receive() ? `<button class="btn s p" data-act="done">${ic('check')} تأكيد الاستلام</button>` : ''}
      <button class="btn s" data-act="share">${ic('share')} مشاركة</button>
      ${o.status === 'new' && can.newOrder() ? `<button class="btn s" data-act="edit">${ic('edit')} تعديل</button>` : ''}
      ${(o.status === 'new' && can.newOrder()) || isOwner() ? `<button class="btn s x" data-act="del">${ic('trash')}</button>` : ''}
    </div></div>`;
}
function orderText(o) {
  return `طلبية للمطبخ · ${deptName(o.dept)}\nإنتاج ${dayName(o.for_date)} ${o.for_date}${o.chef_id ? `\nالشيف: ${userOf(o.chef_id)?.full_name || ''}` : ''}\n\n` +
    Object.entries(o.lines || {}).filter(([, q]) => q > 0).map(([id, q]) => `${itemOf(id)?.name || ''}: ${q} ${itemOf(id)?.unit || ''}`).join('\n') +
    (o.notes ? `\n\nملاحظات: ${o.notes}` : '') + `\nمن: ${o.created_by_name || ''}`;
}
const chefSel = (dept, sel) => { const L = dept ? chefsOf(dept) : S.users.filter(u => u.active && u.role !== OWNER && roleHas(u.role, 'prod'));
  return `<select class="inp" data-chef="${dept}"><option value="">${L.length ? 'اختار الشيف' : 'ماكو شيف بهالقسم'}</option>${L.map(c => `<option value="${c.id}" ${c.id === sel ? 'selected' : ''}>${esc(c.full_name)}</option>`).join('')}</select>`; };
/* المنتجات مجمّعة حسب القسم */
function byDept(list) { const g = {}; list.forEach(it => { const k = deptOf(it.dept) ? it.dept : ''; (g[k] = g[k] || []).push(it); }); return [...act(S.depts).map(d => d.id), ''].filter(k => g[k]).map(k => [k, g[k]]); }
function openOrderForm(o) {
  S.draft = o ? JSON.parse(JSON.stringify(o)) : { for_date: addDays(todayStr(), 1), lines: {}, chefs: {}, notes: '', status: 'new', created_by: S.me.id, created_by_name: S.me.full_name };
  if (o) S.draft.chefs = { [o.dept || '']: o.chef_id };
  drawOrderForm();
}
function drawOrderForm() {
  const d = S.draft, groups = byDept(jardItems()).filter(([k]) => !d.id || k === (d.dept || ''));
  modal(`<h2>${d.id ? 'تعديل طلبية' : 'طلبية جديدة للمطبخ'}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <label class="field"><span>يوم الإنتاج</span><input class="inp" type="date" id="oDate" value="${d.for_date}"></label>
    <div class="row" style="justify-content:space-between;margin:2px 0 6px"><span class="hint">الاقتراح = معدل بيع آخر 7 أيام ناقص متبقي الليلة</span><button class="btn s" id="oSug">${ic('chart')} اقترح الكميات</button></div>
    <p class="hint">كل قسم تنرسل طلبيته لشيف القسم اللي تختاره.</p>
    ${groups.map(([k, its]) => `<div class="dgroup"><div class="dgh">${deptDot(k)}<b>${esc(k ? deptName(k) : 'منتجات بدون قسم')}</b><span class="sp"></span>${chefSel(k, d.chefs[k])}</div>
      ${its.map(it => `<div class="fline"><span>${esc(it.name)} <span class="unit">${esc(it.unit)}</span></span>
      <input class="num" inputmode="${im(it.unit)}" data-line="${it.id}" value="${d.lines[it.id] ?? ''}" placeholder="0">
      <span class="hint">${d.sug && d.sug[it.id] !== undefined && d.sug[it.id] !== '' ? 'مقترح ' + d.sug[it.id] : ''}</span></div>`).join('')}</div>`).join('') || empty('box', 'ماكو منتجات للصالة. ضيفها من «المنتجات والأسعار»')}
    <label class="field" style="margin-top:12px"><span>ملاحظات</span><textarea class="inp" id="oNotes" rows="2">${esc(d.notes || '')}</textarea></label>
    <div class="mact"><button class="btn p" id="oSave">${ic('check')} حفظ وإرسال للمطبخ</button><button class="btn" data-close>إلغاء</button></div>`, true);
}
function readDraft() {
  const d = S.draft; d.for_date = $('#oDate').value || d.for_date; d.notes = $('#oNotes').value.trim();
  $$('[data-line]').forEach(i => { const n = num(i.value); if (n) d.lines[i.dataset.line] = n; else delete d.lines[i.dataset.line]; });
  $$('[data-chef]').forEach(sl => d.chefs[sl.dataset.chef] = sl.value || '');
}
async function saveOrderDraft(btn) {
  readDraft(); const d = S.draft, per = {};
  Object.entries(d.lines).forEach(([id, q]) => { const it = itemOf(id); const k = it && deptOf(it.dept) ? it.dept : ''; (per[k] = per[k] || {})[id] = q; });
  const ks = Object.keys(per); if (!ks.length) return toast('اكتب كمية لصنف واحد على الأقل');
  const miss = ks.filter(k => !d.chefs[k]); if (miss.length) return toast('اختار الشيف لقسم: ' + miss.map(k => k ? deptName(k) : 'بدون قسم').join('، '));
  btn.disabled = true;
  for (const k of ks) {
    const o = { ...d, dept: k || null, chef_id: d.chefs[k], lines: per[k] }; delete o.chefs; delete o.sug;
    if (!d.id || ks.length > 1) { if (d.id && k !== (d.dept || '')) delete o.id; }
    const saved = await DB.upsert('kitchen_orders', o);
    const i = S.porders.findIndex(x => x.id === saved.id); if (i >= 0) S.porders[i] = saved; else S.porders.push(saved);
    logAdd(`${d.id ? 'تعديل' : 'إرسال'} طلبية للمطبخ (${deptName(k)}) ليوم ${o.for_date} · الشيف ${userOf(o.chef_id)?.full_name || ''}`, 'po');
  }
  closeModal(); S.ofilter = 'open'; render(); toast(ks.length > 1 ? `انرسلت ${ks.length} طلبيات، وحدة لكل قسم` : 'انرسلت الطلبية للمطبخ');
}

/* ---------- المستودع ---------- */
function renderWh() {
  const chef = P('wh_req') && !P('wh_issue'); const f = S.wfilter;
  let list = chef ? S.whs.filter(w => w.chef_id === S.me.id) : [...S.whs];
  const cnt = k => list.filter(w => k === 'all' || w.status === k).length;
  list = list.filter(w => f === 'all' || w.status === f).sort((a, b) => (a.status !== 'new') - (b.status !== 'new') || (b.created_at || '').localeCompare(a.created_at || ''));
  $('#view').innerHTML = `
  <div class="toolbar"><div class="filters">${[['new', 'بانتظار الصرف'], ['issued', 'مصروف'], ['all', 'الكل']].map(([k, l]) => `<button data-wf="${k}" class="${k === f ? 'on' : ''}">${l} (${cnt(k)})</button>`).join('')}</div><span class="sp"></span>
  ${can.newWh() ? `<button class="btn p" id="newWh">${ic('plus')} طلب مواد أولية</button>` : ''}</div>
  ${list.length ? `<div class="cols2">${list.map(whCard).join('')}</div>` : empty('box', 'لا توجد طلبات هنا')}`;
}
function whCard(w) {
  const lines = Object.entries(w.lines || {});
  const mine = w.chef_id === S.me.id;
  return `<div class="card ocard s-${w.status}" data-wid="${w.id}">
    <div class="oh"><div class="row" style="gap:10px;flex-wrap:nowrap"><div class="av" style="width:36px;height:36px">${esc(initials(w.chef_name))}</div><div><h3>${esc(w.chef_name || '—')}</h3><div class="meta">${dayName(w.date)} <span dir="ltr">${w.date}</span> · ${timeAgo(w.created_at)}</div></div></div><span class="chip ${w.status === 'new' ? 'new' : 'done'}">${WST[w.status]}</span></div>
    <div class="lines">${lines.map(([id, q]) => { const m = matOf(id); const is = w.issued?.[id]; const diff = w.status === 'issued' && is !== q;
      return `<span>${esc(m?.name || 'مادة محذوفة')}</span><b class="${diff ? 'diff' : ''}">${w.status === 'issued' ? (is ?? 0) : q} <em>${esc(m?.unit || '')}${diff ? ` (المطلوب ${q})` : ''}</em></b>`; }).join('')}</div>
    ${w.notes ? `<p class="small muted" style="margin:0 0 10px">ملاحظات: ${esc(w.notes)}</p>` : ''}
    ${w.status === 'issued' ? `<p class="small muted" style="margin:0 0 10px">صرفها ${esc(w.issued_by_name || '')} · ${timeAgo(w.issued_at)}</p>` : ''}
    <div class="oacts">
      ${w.status === 'new' && can.issue() ? `<button class="btn s p" data-wact="issue">${ic('check')} صرف</button>` : ''}
      <button class="btn s" data-wact="share">${ic('share')} مشاركة</button>
      ${w.status === 'new' && (mine || P('wh_issue')) ? `<button class="btn s" data-wact="edit">${ic('edit')} تعديل</button>` : ''}
      ${(w.status === 'new' && mine) || isOwner() ? `<button class="btn s x" data-wact="del">${ic('trash')}</button>` : ''}
    </div></div>`;
}
function whText(w) {
  return `طلب مواد من المستودع\nالشيف: ${w.chef_name}\n${dayName(w.date)} ${w.date}\n\n` +
    Object.entries(w.lines || {}).map(([id, q]) => `${matOf(id)?.name || ''}: ${w.status === 'issued' ? (w.issued?.[id] ?? 0) : q} ${matOf(id)?.unit || ''}`).join('\n') +
    (w.notes ? `\n\nملاحظات: ${w.notes}` : '') + (w.status === 'issued' ? `\n\nتم الصرف بواسطة ${w.issued_by_name || ''}` : '');
}
function openWhForm(w) {
  const mgr = P('wh_issue') || !P('prod');
  const allChefs = S.users.filter(u => u.active && u.role !== OWNER && roleHas(u.role, 'prod'));
  if (mgr && !allChefs.length) { toast('ماكو شيفات بعد. ضيف مستخدم دوره بيه صلاحية «شيف»'); return; }
  S.wdraft = w ? JSON.parse(JSON.stringify(w)) : { date: todayStr(), chef_id: mgr ? '' : S.me.id, chef_name: mgr ? '' : S.me.full_name, lines: {}, notes: '', status: 'new' };
  const d = S.wdraft;
  modal(`<h2>${d.id ? 'تعديل الطلب' : 'طلب مواد أولية'}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <div class="grid g2" style="gap:10px">${mgr ? `<label class="field"><span>الشيف</span><select class="inp" id="wChef"><option value="">اختار الشيف</option>${allChefs.map(c => `<option value="${c.id}" ${c.id === d.chef_id ? 'selected' : ''}>${esc(c.full_name)}</option>`).join('')}</select></label>` : ''}
    <label class="field"><span>التاريخ</span><input class="inp" type="date" id="wDate" value="${d.date}"></label></div>
    <input class="inp" id="mFilter" placeholder="ابحث عن مادة…" style="margin-bottom:6px">
    <div>${act(S.mats).map(m => `<div class="fline" data-name="${esc(m.name)}"><span>${esc(m.name)}</span>
      <input class="num" inputmode="${im(m.unit)}" data-wline="${m.id}" value="${d.lines[m.id] ?? ''}" placeholder="0"><span class="hint">${esc(m.unit)}</span></div>`).join('')}</div>
    <label class="field" style="margin-top:12px"><span>ملاحظات</span><textarea class="inp" id="wNotes" rows="2">${esc(d.notes || '')}</textarea></label>
    <div class="mact"><button class="btn p" id="wSave">${ic('check')} إرسال للمستودع</button><button class="btn" data-close>إلغاء</button></div>`);
}
function openIssue(w) {
  S.wdraft = w;
  modal(`<h2>صرف مواد لـ ${esc(w.chef_name)}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <p class="hint" style="margin-top:-6px">عدّل الكمية إذا صرفت كمية مختلفة عن المطلوب.</p>
    ${Object.entries(w.lines || {}).map(([id, q]) => { const m = matOf(id); return `<div class="fline"><span>${esc(m?.name || '')} <span class="unit">المطلوب ${q}</span></span>
      <input class="num" inputmode="${im(m?.unit)}" data-iss="${id}" value="${q}"><span class="hint">${esc(m?.unit || '')}</span></div>`; }).join('')}
    <p class="hint">يُسجل الصرف باسمك: ${esc(S.me.full_name)}</p>
    <div class="mact"><button class="btn p" id="doIssue">${ic('check')} تأكيد الصرف</button><button class="btn" data-close>إلغاء</button></div>`);
}

/* ---------- جدول الدوام ---------- */
function renderSchedule() {
  const st = S.settings.shift_times, sc = S.settings.schedule;
  const hall = hallStaff();
  const DAYS = [[6, 'السبت'], [0, 'الأحد'], [1, 'الاثنين'], [2, 'الثلاثاء'], [3, 'الأربعاء'], [4, 'الخميس'], [5, 'الجمعة']];
  const cov = (wd, s) => hall.filter(u => sc.weekly[u.id]?.[wd] === s).length;
  const ovs = Object.entries(sc.overrides || {}).filter(([k]) => k.split('|')[0] >= addDays(todayStr(), -1)).sort();
  $('#view').innerHTML = `
  <div class="card pad"><div class="sec" style="margin-top:0">${ic('clock')} أوقات الشفتات</div>
    <div class="grid g3" style="gap:12px;align-items:end">
      <div><b>الصباحي</b><div class="row" style="margin-top:6px;flex-wrap:nowrap"><input class="inp" type="time" id="amS" value="${st.am.start}"><span class="muted">إلى</span><input class="inp" type="time" id="amE" value="${st.am.end}"></div></div>
      <div><b>المسائي</b><div class="row" style="margin-top:6px;flex-wrap:nowrap"><input class="inp" type="time" id="pmS" value="${st.pm.start}"><span class="muted">إلى</span><input class="inp" type="time" id="pmE" value="${st.pm.end}"></div></div>
      <label class="field" style="margin:0"><span>تذكير قبل نهاية الشفت (دقيقة)</span><input class="inp" id="remind" inputmode="numeric" value="${st.remind || 15}"></label>
    </div>
    <p class="hint">التطبيق يفتح الشفت الحالي تلقائياً حسب هذه الأوقات، ويذكّر الموظف قبل النهاية.</p>
    <button class="btn d" id="saveTimes">حفظ الأوقات</button></div>

  <div class="card" style="margin-top:14px"><div class="pad" style="padding-bottom:0"><div class="sec" style="margin-top:0">${ic('users')} الجدول الأسبوعي لموظفي الصالة</div></div>
    ${hall.length ? `<div class="tw"><table class="t sched"><thead><tr><th>الموظف</th>${DAYS.map(([, n]) => `<th>${n}</th>`).join('')}</tr></thead><tbody>
      ${hall.map(u => `<tr><td><b>${esc(u.full_name)}</b></td>${DAYS.map(([wd]) => { const v = sc.weekly[u.id]?.[wd] || '';
        return `<td><select class="cell ${v}" data-wk="${u.id}|${wd}"><option value="">عطلة</option><option value="am" ${v === 'am' ? 'selected' : ''}>صباحي</option><option value="pm" ${v === 'pm' ? 'selected' : ''}>مسائي</option></select></td>`; }).join('')}</tr>`).join('')}
      </tbody><tfoot><tr><td class="small">التغطية</td>${DAYS.map(([wd]) => { const a = cov(wd, 'am'), p = cov(wd, 'pm'); return `<td class="small"><span class="${a ? '' : 'bad'}">ص ${a}</span> · <span class="${p ? '' : 'bad'}">م ${p}</span></td>`; }).join('')}</tr></tfoot></table></div>
      <div class="pad"><button class="btn d" id="saveWeek">حفظ الجدول</button> <span class="hint">يفتح كل موظف شفته فقط. إذا لم يُحدد أحد بالجدول، يستطيع الجميع فتح أي شفت.</span></div>`
      : `<div class="pad">${empty('users', 'ماكو موظفين دورهم بيه صلاحية «تسجيل جرد الشفت». ضيفهم من «المستخدمين»')}</div>`}</div>

  <div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">${ic('edit')} تبديل ليوم معين</div>
    <p class="hint" style="margin-top:-6px">عند غياب موظف أو تبديل بين اثنين، سجّل من يغطي الشفت بذلك اليوم.</p>
    <div class="row"><input class="inp" type="date" id="ovD" value="${addDays(todayStr(), 1)}" style="width:auto">
      <select class="inp" id="ovS" style="width:auto"><option value="am">صباحي</option><option value="pm">مسائي</option></select>
      <select class="inp" id="ovU" style="width:auto"><option value="">اختر الموظف</option>${hall.map(u => `<option value="${u.id}">${esc(u.full_name)}</option>`).join('')}</select>
      <button class="btn p" id="addOv">${ic('plus')} إضافة</button></div>
    ${ovs.length ? `<div class="feed" style="margin-top:10px">${ovs.map(([k, u]) => { const [d, sh] = k.split('|'); return `<div class="ev"><span class="ic">${ic('clock')}</span><div style="flex:1"><p>${dayName(d)} <span dir="ltr">${d}</span> · الشفت ال${SHIFT[sh]}</p><small>يغطيه: ${esc(userOf(u)?.full_name || '')}</small></div><button class="iconbtn" data-delov="${k}">${ic('trash')}</button></div>`; }).join('')}</div>` : ''}
  </div>`;
}

R.jard = renderJard; R.porders = renderOrders; R.wh = renderWh; R.schedule = renderSchedule;

H.click.push(async (t, ds, id, e) => {
    if (ds.shift) { S.shift = ds.shift; return render(); }
    if (ds.of) { S.ofilter = ds.of; return render(); }
    if (ds.wf) { S.wfilter = ds.wf; return render(); }
    if (ds.issue) return openIssue(S.whs.find(w => w.id === ds.issue));
    /* الجرد */
    if (id === 'closeShift') {
      const rec = getRec(S.date, S.shift, true); const miss = jardItems().filter(it => rec.rows[it.id]?.close == null).length;
      if (!(await confirmBox(miss ? `${miss} صنف بدون متبقي. إغلاق الشفت؟` : `إغلاق الشفت ال${SHIFT[S.shift]}؟ لن يمكن التعديل بعدها.`, 'إغلاق الشفت'))) return;
      rec.closed = true; rec.closed_at = new Date().toISOString(); rec.employee_id = rec.employee_id || S.me.id; rec.employee_name = rec.employee_name || S.me.full_name;
      await saveShiftNow(S.date, S.shift); toast('تم إغلاق الشفت'); return render();
    }
    if (id === 'reopen') { const rec = getRec(S.date, S.shift); rec.closed = false; saveShift(S.date, S.shift); return render(); }
    if (id === 'confirmOpen' || id === 'usePrev') {
      const rec = getRec(S.date, S.shift, true); const its = jardItems(); const k = recKey(S.date, S.shift);
      if (id === 'confirmOpen') {
        const miss = its.filter(it => num(S.hdraft[k + it.id]) == null).length;
        if (miss && !(await confirmBox(`${miss} صنف بدون عدد. اعتبارها صفر؟`, 'نعم، متابعة'))) return;
        its.forEach(it => { rec.rows[it.id] = rec.rows[it.id] || {}; rec.rows[it.id].open = num(S.hdraft[k + it.id]) ?? 0; });
      } else { const [pd, ps] = prevOf(S.date, S.shift); its.forEach(it => { rec.rows[it.id] = rec.rows[it.id] || {}; rec.rows[it.id].open = getRec(pd, ps)?.rows?.[it.id]?.close ?? 0; }); }
      Object.assign(rec, { opened: true, opened_at: new Date().toISOString(), opened_by_name: S.me.full_name });
      if (!rec.employee_id || !P('jard_any')) { rec.employee_id = S.me.id; rec.employee_name = S.me.full_name; }
      await saveShiftNow(S.date, S.shift); render();
      const n = its.filter(it => handoverDiff(S.date, S.shift, it.id)).length;
      return toast(n ? `تم استلام الشفت · ${n} فرق بالتسليم` : 'تم استلام الشفت · العد مطابق');
    }
    if (id === 'kitchenRecv') return pickOrder();
    if (id === 'manualRecv') return openReceive(null, S.page === 'jard' ? { date: S.date, shift: S.shift } : null);
    if (ds.pick) return openReceive(S.porders.find(o => o.id === ds.pick), S.page === 'jard' ? { date: S.date, shift: S.shift } : null);
    if (id === 'doReceive') { t.disabled = true; return doReceive(); }
    if (ds.waste) return openWaste(ds.waste);
    if (id === 'wasteSave') {
      const rec = getRec(S.date, S.shift, true); const r = rec.rows[ds.id] = rec.rows[ds.id] || {}; r.wasteBy = {};
      $$('[data-wr]').forEach(i => { const n = num(i.value); if (n) r.wasteBy[i.dataset.wr] = n; });
      r.waste = r3(Object.values(r.wasteBy).reduce((a, b) => a + b, 0)) || null;
      saveShift(S.date, S.shift); closeModal(); return render();
    }
    /* جدول الدوام */
    if (id === 'saveTimes') {
      const st = { am: { start: $('#amS').value, end: $('#amE').value }, pm: { start: $('#pmS').value, end: $('#pmE').value }, remind: num($('#remind').value) || 15 };
      if (!(st.am.start < st.am.end)) return toast('وقت نهاية الصباحي يجب أن يكون بعد بدايته');
      S.settings.shift_times = st; await DB.upsert('settings', { id: 'shift_times', value: st }); return toast('تم حفظ الأوقات');
    }
    if (id === 'saveWeek') {
      const w = {}; $$('[data-wk]').forEach(sel => { const [uidd, d] = sel.dataset.wk.split('|'); w[uidd] = w[uidd] || [null, null, null, null, null, null, null]; w[uidd][+d] = sel.value || null; });
      S.settings.schedule.weekly = w; await DB.upsert('settings', { id: 'schedule', value: S.settings.schedule }); render(); return toast('تم حفظ الجدول');
    }
    if (id === 'addOv') {
      const d = $('#ovD').value, sh = $('#ovS').value, u = $('#ovU').value; if (!d || !u) return toast('اختر اليوم والموظف');
      S.settings.schedule.overrides[recKey(d, sh)] = u; await DB.upsert('settings', { id: 'schedule', value: S.settings.schedule }); render(); return toast('تم تسجيل التبديل');
    }
    if (ds.delov) { delete S.settings.schedule.overrides[ds.delov]; await DB.upsert('settings', { id: 'schedule', value: S.settings.schedule }); return render(); }
    /* الطلبيات */
    if (id === 'newOrder') return openOrderForm();
    if (id === 'oSug') { readDraft(); S.draft.sug = await suggest(S.draft.for_date); for (const [k, q] of Object.entries(S.draft.sug)) if (q && !S.draft.lines[k]) S.draft.lines[k] = q; drawOrderForm(); if (Object.values(S.draft.sug).every(v => v === '')) toast('ماكو جرد كافي للاقتراح بعد'); return; }
    if (id === 'oSave') return saveOrderDraft(t);
    const oc = t.closest('[data-oid]');
    if (oc && ds.act) {
      const o = S.porders.find(x => x.id === oc.dataset.oid);
      if (ds.act === 'share') return shareModal(orderText(o));
      if (ds.act === 'edit') return openOrderForm(o);
      if (ds.act === 'del') { if (!(await confirmBox('حذف هذه الطلبية؟', 'حذف', true))) return; await DB.remove('kitchen_orders', o.id); S.porders = S.porders.filter(x => x !== o); logAdd('حذف طلبية مطبخ ليوم ' + o.for_date, 'po'); return render(); }
      if (ds.act === 'done') return openReceive(o);
      if (ds.act === 'prod') { o.status = 'prod'; o.prod_at = new Date().toISOString(); const saved = await DB.upsert('kitchen_orders', o); Object.assign(o, saved); toast('بدأ الإنتاج'); return render(); }
    }
    /* المستودع */
    if (id === 'newWh') return openWhForm();
    if (id === 'wSave') {
      const d = S.wdraft; if ($('#wChef')) { d.chef_id = $('#wChef').value; d.chef_name = userOf(d.chef_id)?.full_name || ''; }
      d.date = $('#wDate').value || d.date; d.notes = $('#wNotes').value.trim(); d.lines = {};
      $$('[data-wline]').forEach(i => { const n = num(i.value); if (n) d.lines[i.dataset.wline] = n; });
      if (!d.chef_id) return toast('اختر الشيف'); if (!Object.keys(d.lines).length) return toast('أدخل كمية لمادة واحدة على الأقل');
      t.disabled = true; const saved = await DB.upsert('wh_requests', d);
      const i = S.whs.findIndex(x => x.id === saved.id); if (i >= 0) S.whs[i] = saved; else S.whs.push(saved);
      closeModal(); S.wfilter = 'new'; render(); return toast('تم إرسال الطلب للمستودع');
    }
    if (id === 'doIssue') {
      const w = S.wdraft; const iss = {}; $$('[data-iss]').forEach(i => iss[i.dataset.iss] = num(i.value) || 0);
      t.disabled = true; const saved = await DB.upsert('wh_requests', { ...w, issued: iss, status: 'issued', issued_by_name: S.me.full_name, issued_at: new Date().toISOString() });
      Object.assign(w, saved); closeModal(); render(); return toast('تم الصرف');
    }
    const wc = t.closest('[data-wid]');
    if (wc && ds.wact) {
      const w = S.whs.find(x => x.id === wc.dataset.wid);
      if (ds.wact === 'issue') return openIssue(w);
      if (ds.wact === 'share') return shareModal(whText(w));
      if (ds.wact === 'edit') return openWhForm(w);
      if (ds.wact === 'del') { if (!(await confirmBox('حذف هذا الطلب؟', 'حذف', true))) return; await DB.remove('wh_requests', w.id); S.whs = S.whs.filter(x => x !== w); return render(); }
    }
});
H.input.push((t) => {
  if (t.id === 'mFilter') { const q = t.value.trim(); $$('[data-name]').forEach(r => r.style.display = r.dataset.name.includes(q) ? '' : 'none'); return; }
  if (t.dataset.h) { S.hdraft[recKey(S.date, S.shift) + t.dataset.h] = t.value; return; }
  if (S.page === 'jard' && t.dataset.f) {
    const rec = getRec(S.date, S.shift, true); const id = t.closest('[data-id]').dataset.id, f = t.dataset.f;
    rec.rows[id] = rec.rows[id] || {}; rec.rows[id][f] = num(t.value);
    if (!rec.employee_id) { rec.employee_id = S.me.id; rec.employee_name = S.me.full_name; }
    saveShift(S.date, S.shift); updateSold();
  }
});
H.change.push(async (t) => {
  if (t.id === 'pDept') { S.pdept = t.value; return render(); }
  if (t.id === 'jDate') { if (t.value) { S.date = t.value; render(); } return; }
  if (t.id === 'rFrom' || t.id === 'rTo') { if (t.value) { S[t.id === 'rFrom' ? 'rfrom' : 'rto'] = t.value; if (S.rfrom > S.rto) [S.rfrom, S.rto] = [S.rto, S.rfrom]; render(); } return; }
  if (t.id === 'mine') { S.mine = t.checked; return render(); }
  if (t.dataset.wk) { t.className = 'cell ' + t.value; return; }

});

/* تقرير الصالة والمستودع */
async function renderReportsHall() {
  const { rfrom, rto } = S; await ensureShifts(addDays(rfrom, -1));
  const days = []; for (let d = rfrom; d <= rto; d = addDays(d, 1)) days.push(d);
  const its = jardItems();
  const rows = its.map(it => {
    let a = 0, p = 0, w = 0;
    days.forEach(d => { a += Math.max(soldOf(d, 'am', it.id) || 0, 0); p += Math.max(soldOf(d, 'pm', it.id) || 0, 0); w += dayWaste(d, it.id); });
    return { it, a: r3(a), p: r3(p), t: r3(a + p), w: r3(w) };
  });
  const T = k => byUnit(rows.map(r => [r.it.unit, r[k]]));
  const wr = {}; days.forEach(d => ['am', 'pm'].forEach(s => its.forEach(it => { const wb = getRec(d, s)?.rows?.[it.id]?.wasteBy || {};
    Object.entries(wb).forEach(([k, q]) => { wr[k] = wr[k] || []; wr[k].push([it.unit, q]); }); })));
  const hds = []; days.forEach(d => ['am', 'pm'].forEach(s => its.forEach(it => { const x = handoverDiff(d, s, it.id); if (x) { const [pd, ps] = prevOf(d, s);
    hds.push({ d, s, it, x, from: getRec(pd, ps)?.employee_name || '', to: getRec(d, s)?.employee_name || '' }); } })));
  const issued = S.whs.filter(w => w.status === 'issued' && w.date >= rfrom && w.date <= rto);
  const chefIds = [...new Set(issued.map(w => w.chef_id))];
  const mt = {}; issued.forEach(w => Object.entries(w.issued || {}).forEach(([id, q]) => { mt[id] = mt[id] || {}; mt[id][w.chef_id] = (mt[id][w.chef_id] || 0) + q; }));
  const cName = id => issued.find(w => w.chef_id === id)?.chef_name || userOf(id)?.full_name || '';
  S._csv = [['الصنف', 'الوحدة', 'صباحي', 'مسائي', 'المجموع', 'التالف'], ...rows.map(r => [r.it.name, r.it.unit, r.a, r.p, r.t, r.w]), [],
    ['سبب التالف', 'الكمية'], ...WASTE_REASONS.filter(k => wr[k]).map(k => [k, byUnit(wr[k])]), [],
    ['اليوم', 'الشفت', 'الصنف', 'فرق التسليم', 'من', 'إلى'], ...hds.map(h => [h.d, SHIFT[h.s], h.it.name, h.x, h.from, h.to]), [],
    ['المادة', 'الوحدة', ...chefIds.map(cName), 'المجموع'], ...Object.entries(mt).map(([id, c]) => [matOf(id)?.name, matOf(id)?.unit, ...chefIds.map(x => r3(c[x] || 0)), r3(Object.values(c).reduce((a, b) => a + b, 0))])];
  $('#view').innerHTML = `
  <div class="grid g3"><div class="card kpi"><div class="ic">${ic('cash')}</div><span class="lbl">إجمالي المبيع</span><span class="val" style="font-size:19px">${T('t')}</span></div>
  <div class="card kpi red"><div class="ic">${ic('trash')}</div><span class="lbl">إجمالي التالف</span><span class="val" style="font-size:19px">${T('w')}</span></div>
  <div class="card kpi green"><div class="ic">${ic('box')}</div><span class="lbl">طلبات مستودع مصروفة</span><span class="val" style="font-size:19px">${issued.length}</span></div></div>
  <div class="sec">المبيعات حسب الصنف</div>
  <div class="card tw"><table class="t"><thead><tr><th>الصنف</th><th>صباحي</th><th>مسائي</th><th>المجموع</th><th>التالف</th></tr></thead>
    <tbody>${rows.map(r => `<tr><td>${esc(r.it.name)} <span class="unit">${esc(r.it.unit)}</span></td><td>${r.a}</td><td>${r.p}</td><td><b>${r.t}</b></td><td>${r.w || ''}</td></tr>`).join('')}</tbody>
    <tfoot><tr><td>الإجمالي</td><td>${T('a')}</td><td>${T('p')}</td><td>${T('t')}</td><td>${T('w')}</td></tr></tfoot></table></div>
  <div class="grid g2" style="align-items:start">
  <div><div class="sec">التالف حسب السبب</div>
  ${Object.keys(wr).length ? `<div class="card tw"><table class="t"><thead><tr><th>السبب</th><th>الكمية</th></tr></thead><tbody>${WASTE_REASONS.filter(k => wr[k]).map(k => `<tr><td>${k}</td><td>${byUnit(wr[k])}</td></tr>`).join('')}</tbody></table></div>` : `<div class="card">${empty('trash', 'لا يوجد تالف مسجل بالأسباب')}</div>`}</div>
  <div><div class="sec">فروقات التسليم بين الشفتات</div>
  ${hds.length ? `<div class="card tw"><table class="t"><thead><tr><th>اليوم</th><th>الصنف</th><th>الفرق</th><th>من ← إلى</th></tr></thead><tbody>${hds.map(h => `<tr><td>${dayShort(h.d)} ${SHIFT[h.s]}</td><td>${esc(h.it.name)}</td><td dir="ltr" style="color:var(--red)">${h.x > 0 ? '+' : ''}${h.x}</td><td class="small">${esc(h.from)} ← ${esc(h.to)}</td></tr>`).join('')}</tbody></table></div>` : `<div class="card">${empty('check', 'لا توجد فروقات تسليم')}</div>`}</div>
  </div>
  <div class="sec">صرف المستودع حسب الشيف</div>
  ${issued.length ? `<div class="card tw"><table class="t"><thead><tr><th>المادة</th>${chefIds.map(c => `<th>${esc(cName(c))}</th>`).join('')}<th>المجموع</th></tr></thead>
    <tbody>${Object.entries(mt).map(([id, c]) => `<tr><td>${esc(matOf(id)?.name || '')} <span class="unit">${esc(matOf(id)?.unit || '')}</span></td>${chefIds.map(x => `<td>${c[x] ? r3(c[x]) : ''}</td>`).join('')}<td><b>${r3(Object.values(c).reduce((a, b) => a + b, 0))}</b></td></tr>`).join('')}</tbody></table></div>`
    : `<div class="card">${empty('box', 'لا يوجد صرف في هذه الفترة')}</div>`}`;
}
