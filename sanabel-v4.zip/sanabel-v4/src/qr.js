/* A small QR code generator (byte mode, error level M, versions 1-15) */
const QR=(function(){
var ECC=[-1,10,16,26,18,24,16,18,22,22,26,30,22,22,24,24],NB=[-1,1,1,1,2,2,4,4,4,5,5,5,8,9,9,10];
function raw(v){var r=(16*v+128)*v+64;if(v>=2){var n=Math.floor(v/7)+2;r-=(25*n-10)*n-55;if(v>=7)r-=36}return r}
function dataCW(v){return Math.floor(raw(v)/8)-ECC[v]*NB[v]}
function mul(x,y){var z=0;for(var i=7;i>=0;i--){z=(z<<1)^((z>>>7)*0x11D);z^=((y>>>i)&1)*x}return z}
function div(d){var r=[];for(var i=0;i<d;i++)r.push(0);r[d-1]=1;var root=1;for(i=0;i<d;i++){for(var j=0;j<r.length;j++){r[j]=mul(r[j],root);if(j+1<r.length)r[j]^=r[j+1]}root=mul(root,2)}return r}
function rem(data,dv){var r=dv.map(function(){return 0});data.forEach(function(b){var f=b^r.shift();r.push(0);dv.forEach(function(c,i){r[i]^=mul(c,f)})});return r}
function utf8(s){var b=[],e=unescape(encodeURIComponent(s));for(var i=0;i<e.length;i++)b.push(e.charCodeAt(i));return b}
function make(text){var bytes=utf8(text),v,bits=[];
for(v=1;v<=15;v++){var cc=v<=9?8:16;if(4+cc+bytes.length*8<=dataCW(v)*8)break}if(v>15)throw new Error('long');
function put(val,n){for(var i=n-1;i>=0;i--)bits.push((val>>>i)&1)}
put(4,4);put(bytes.length,v<=9?8:16);bytes.forEach(function(b){put(b,8)});var cap=dataCW(v)*8;put(0,Math.min(4,cap-bits.length));put(0,(8-bits.length%8)%8);
for(var pb=0xEC;bits.length<cap;pb^=0xEC^0x11)put(pb,8);
var data=[];for(var i=0;i<bits.length;i+=8){var x=0;for(var j=0;j<8;j++)x=(x<<1)|bits[i+j];data.push(x)}
var nb=NB[v],el=ECC[v],rc=Math.floor(raw(v)/8),ns=nb-rc%nb,sl=Math.floor(rc/nb),dv=div(el),blocks=[],k=0;
for(i=0;i<nb;i++){var dat=data.slice(k,k+sl-el+(i<ns?0:1));k+=dat.length;var ec=rem(dat,dv);if(i<ns)dat.push(0);blocks.push(dat.concat(ec))}
var all=[];for(i=0;i<blocks[0].length;i++)for(j=0;j<blocks.length;j++)if(i!==sl-el||j>=ns)all.push(blocks[j][i]);
var size=v*4+17,M=[],F=[];for(i=0;i<size;i++){M.push([]);F.push([]);for(j=0;j<size;j++){M[i].push(false);F[i].push(false)}}
function set(x,y,d){M[y][x]=d;F[y][x]=true}
for(i=0;i<size;i++){set(6,i,i%2===0);set(i,6,i%2===0)}
[[3,3],[size-4,3],[3,size-4]].forEach(function(p){for(var dy=-4;dy<=4;dy++)for(var dx=-4;dx<=4;dx++){var d=Math.max(Math.abs(dx),Math.abs(dy)),xx=p[0]+dx,yy=p[1]+dy;if(xx>=0&&xx<size&&yy>=0&&yy<size)set(xx,yy,d!==2&&d!==4)}});
var al=[];if(v>1){var na=Math.floor(v/7)+2,st=Math.ceil((v*4+4)/(na*2-2))*2;al=[6];for(var pos=size-7;al.length<na;pos-=st)al.splice(1,0,pos)}
for(i=0;i<al.length;i++)for(j=0;j<al.length;j++){if((i===0&&j===0)||(i===0&&j===al.length-1)||(i===al.length-1&&j===0))continue;for(var dy2=-2;dy2<=2;dy2++)for(var dx2=-2;dx2<=2;dx2++)set(al[i]+dx2,al[j]+dy2,Math.max(Math.abs(dx2),Math.abs(dy2))!==1)}
function fmt(mask){var d=(0<<3)|mask,r=d;for(var t=0;t<10;t++)r=(r<<1)^((r>>>9)*0x537);var b=((d<<10)|r)^0x5412;function g(n){return((b>>>n)&1)!==0}
for(var t2=0;t2<=5;t2++)set(8,t2,g(t2));set(8,7,g(6));set(8,8,g(7));set(7,8,g(8));for(t2=9;t2<15;t2++)set(14-t2,8,g(t2));
for(t2=0;t2<8;t2++)set(size-1-t2,8,g(t2));for(t2=8;t2<15;t2++)set(8,size-15+t2,g(t2));set(8,size-8,true)}
fmt(0);
if(v>=7){var r2=v;for(i=0;i<12;i++)r2=(r2<<1)^((r2>>>11)*0x1F25);var vb=(v<<12)|r2;for(i=0;i<18;i++){var bt=((vb>>>i)&1)!==0,a=size-11+i%3,b2=Math.floor(i/3);set(a,b2,bt);set(b2,a,bt)}}
var bi=0;for(var right=size-1;right>=1;right-=2){if(right===6)right=5;for(var vt=0;vt<size;vt++)for(j=0;j<2;j++){var xx=right-j,up=((right+1)&2)===0,yy=up?size-1-vt:vt;if(!F[yy][xx]&&bi<all.length*8){M[yy][xx]=((all[bi>>>3]>>>(7-(bi&7)))&1)!==0;bi++}}}
function mask(m){for(var y=0;y<size;y++)for(var x=0;x<size;x++){var inv;switch(m){case 0:inv=(x+y)%2===0;break;case 1:inv=y%2===0;break;case 2:inv=x%3===0;break;case 3:inv=(x+y)%3===0;break;case 4:inv=(Math.floor(x/3)+Math.floor(y/2))%2===0;break;case 5:inv=x*y%2+x*y%3===0;break;case 6:inv=(x*y%2+x*y%3)%2===0;break;default:inv=((x+y)%2+x*y%3)%2===0}if(!F[y][x]&&inv)M[y][x]=!M[y][x]}}
function pen(){var p=0,dark=0,x,y;for(y=0;y<size;y++){var run=1;for(x=1;x<size;x++){if(M[y][x]===M[y][x-1]){run++;if(run===5)p+=3;else if(run>5)p++}else run=1}}
for(x=0;x<size;x++){run=1;for(y=1;y<size;y++){if(M[y][x]===M[y-1][x]){run++;if(run===5)p+=3;else if(run>5)p++}else run=1}}
for(y=0;y<size-1;y++)for(x=0;x<size-1;x++){var c=M[y][x];if(c===M[y][x+1]&&c===M[y+1][x]&&c===M[y+1][x+1])p+=3}
for(y=0;y<size;y++)for(x=0;x<size;x++)if(M[y][x])dark++;var tot=size*size;p+=Math.floor(Math.abs(dark*20-tot*10)/tot)*10;return p}
var best=0,bp=1e9;for(var m=0;m<8;m++){mask(m);fmt(m);var pp=pen();if(pp<bp){bp=pp;best=m}mask(m)}mask(best);fmt(best);return M}
function svg(text,px){var M=make(text),n=M.length,q=4,s=n+q*2,d='';for(var y=0;y<n;y++)for(var x=0;x<n;x++)if(M[y][x])d+='M'+(x+q)+' '+(y+q)+'h1v1h-1z';
return'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+s+' '+s+'" width="'+(px||240)+'" height="'+(px||240)+'" shape-rendering="crispEdges"><rect width="'+s+'" height="'+s+'" fill="#fff"/><path d="'+d+'" fill="#000"/></svg>'}
return{make:make,svg:svg}})();


