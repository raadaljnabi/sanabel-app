/* ===== سنابل الطاحونة: تطبيق واحد للكيك والمخبز والصالة والمستودع ===== */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = v => { if (v === '' || v == null) return null; const n = Number(String(v).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[٫,]/g, '.')); return isNaN(n) ? null : n; };
const r3 = n => Math.round((n || 0) * 1000) / 1000;
const dayName = s => new Date(s + 'T12:00').toLocaleDateString('ar-IQ', { weekday: 'long' });
const dayShort = s => new Date(s + 'T12:00').toLocaleDateString('ar-IQ', { weekday: 'short' });
const fD = d => { try { return d.toLocaleDateString('ar-IQ-u-nu-latn', { weekday: 'long', day: 'numeric', month: 'long' }); } catch (e) { return fmtD(d); } };
const fT = d => { try { return d.toLocaleTimeString('ar-IQ-u-nu-latn', { hour: 'numeric', minute: '2-digit' }); } catch (e) { return pad2(d.getHours()) + ':' + pad2(d.getMinutes()); } };
const timeAgo = iso => { if (!iso) return ''; const m = Math.round((Date.now() - new Date(iso)) / 60000); if (m < 1) return 'هسه'; if (m < 60) return `قبل ${m} دقيقة`; const h = Math.round(m / 60); if (h < 24) return `قبل ${h} ساعة`; return `قبل ${Math.round(h / 24)} يوم`; };
const isW = u => ['كغم', 'غرام', 'لتر'].includes(u);
const im = u => isW(u) ? 'decimal' : 'numeric';
const fmt = n => Number(n || 0).toLocaleString('en-US');
const cur = () => esc((S.cfg.shop && S.cfg.shop.cur) || 'د.ع');
const money = n => fmt(n) + ' ' + ((S.cfg.shop && S.cfg.shop.cur) || 'د.ع');
const ITEM_UNITS = ['قطعة', 'كغم', 'علبة', 'صينية'];
const MAT_UNITS = ['كغم', 'غرام', 'لتر', 'قطعة', 'كيس', 'كارتونة', 'علبة', 'طبقة'];
const SHIFT = { am: 'صباحي', pm: 'مسائي' };
const OST = { new: 'جديدة', prod: 'قيد الإنتاج', done: 'مستلمة' };
const WST = { new: 'بانتظار الصرف', issued: 'مصروف' };
const CST = { new: 'جديد', prep: 'بالمطبخ', ready: 'جاهز للتسليم', done: 'تم التسليم', cancel: 'ملغي' };
const SHOP = 'سنابل الطاحونة', WA = '9647709821240', WAT = '0770 982 1240';
const initials = n => String(n || '؟').replace(/^الشيف\s+/, '').replace(/^ال(?=\S{2})/, '').trim().charAt(0) || '؟';
function byUnit(pairs) { const m = {}; pairs.forEach(([u, q]) => { if (q) m[u] = (m[u] || 0) + q; }); const s = Object.entries(m).map(([u, q]) => `${r3(q)} ${u}`).join('، '); return s || '0'; }
function toast(t) { const el = document.createElement('div'); el.className = 'toast'; el.textContent = t; document.body.appendChild(el); setTimeout(() => el.remove(), 2800); }
function openURL(u) { const a = document.createElement('a'); a.href = u; a.target = '_blank'; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove(); }
function waNum(p) { p = String(p || '').replace(/\D/g, ''); if (p.indexOf('00964') === 0) p = p.slice(2); if (p.indexOf('964') === 0) return p; if (p.charAt(0) === '0') return '964' + p.slice(1); if (p.length === 10) return '964' + p; return p; }
function shrink(f, mx, ty) { return new Promise(ok => { const r = new FileReader(); r.onload = () => { const img = new Image(); img.onload = () => { const m = mx || 1000, s = Math.min(1, m / Math.max(img.width, img.height)), c = document.createElement('canvas'); c.width = img.width * s; c.height = img.height * s; c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); ok(c.toDataURL(ty || 'image/jpeg', .8)); }; img.src = r.result; }; r.readAsDataURL(f); }); }

/* ---------- أيقونات ---------- */
const IC = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.6"/><rect x="14" y="3" width="7" height="7" rx="1.6"/><rect x="3" y="14" width="7" height="7" rx="1.6"/><rect x="14" y="14" width="7" height="7" rx="1.6"/>',
  clip: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 3h6v3H9zM9 11h6M9 15h4"/>',
  chef: '<path d="M6 14a4 4 0 1 1 1.6-7.7A4.5 4.5 0 0 1 16.4 6.3 4 4 0 1 1 18 14v6H6z"/><path d="M6 17h12"/>',
  box: '<path d="M3 7.5 12 3l9 4.5-9 4.5-9-4.5z"/><path d="M3 7.5v9L12 21l9-4.5v-9M12 12v9"/>',
  chart: '<path d="M4 20V11M10 20V5M16 20v-6M21 20H3"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.2a6.5 6.5 0 0 1 3.5 5.8"/>',
  set: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  home: '<path d="M3 11 12 3l9 8M5 9.5V20h5v-6h4v6h5V9.5"/>',
  more: '<circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/>',
  out: '<path d="M9 4H5v16h4M14 8l-4 4 4 4M10 12h11"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  share: '<path d="M4 12v7h16v-7M12 3v12M8 7l4-4 4 4"/>',
  check: '<path d="M5 12.5 10 17 19 7"/>',
  alert: '<path d="M12 4 2.5 20h19L12 4zM12 10v4M12 17h0"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  cash: '<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16v4z"/>',
  dl: '<path d="M12 4v11M7 10l5 5 5-5M4 20h16"/>',
  up: '<path d="M12 20V9M7 14l5-5 5 5M4 4h16"/>',
  print: '<path d="M7 9V3h10v6M7 17H4v-7h16v7h-3M7 14h10v7H7z"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  play: '<path d="M7 5v14l11-7z"/>',
  chev: '<path d="m6 9 6 6 6-6"/>',
  send: '<path d="M21 3 10 14M21 3l-7 18-4-7-7-4z"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3"/>',
  cake: '<path d="M4 21h16M5 21v-7h14v7M5 14c1.5 1 3 1 4.5 0s3-1 4.5 0 3 1 4.5 0M8 14v-3h8v3M12 11V8M12 5.5a1.3 1.3 0 0 1-1-2.1L12 2l1 1.4a1.3 1.3 0 0 1-1 2.1z"/>',
  cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  tv: '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>',
  bag: '<path d="M5 8h14l-1 13H6L5 8zM9 8V6a3 3 0 0 1 6 0v2"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5 9-5zM3 13l9 5 9-5"/>',
  log: '<path d="M12 8v4l3 2M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5"/>',
  shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3z"/>',
  wa: '<path d="M4 20l1.4-4.2A8 8 0 1 1 8.4 19z"/>',
  img: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 16l5-5 4 4 3-3 6 6M15.5 8.5h.01"/>',
  store: '<path d="M3 9l1.5-5h15L21 9M3 9v11h18V9M3 9h18M9 20v-6h6v6"/>',
  slider: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M8 21h8"/>',
  list: '<path d="M3 4h6v6H3zM3 14h6v6H3zM12 6h9M12 9h6M12 16h9M12 19h6"/>',
};
const ic = (n, cls = '') => `<svg class="i ${cls}" viewBox="0 0 24 24">${IC[n] || ''}</svg>`;

/* ---------- واجهات عامة ---------- */
function modal(html, wide) { $('#modalRoot').innerHTML = `<div class="modal"><div class="sheet${wide ? ' wide' : ''}" role="dialog" aria-modal="true">${html}</div></div>`; }
function closeModal() { $('#modalRoot').innerHTML = ''; }
function shareModal(text, phone) {
  modal(`<h2>مشاركة<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
  <textarea class="inp" id="shareTxt" rows="12" readonly>${esc(text)}</textarea>
  <div class="mact"><button class="btn p" id="doCopy">${ic('check')} نسخ النص</button>
  <a class="btn g" target="_blank" rel="noopener" href="https://wa.me/${phone ? waNum(phone) : ''}?text=${encodeURIComponent(text)}">${ic('share')} واتساب</a></div>`);
}
function dateCtl(id, val) { return `<div class="datectl"><button data-dstep="-1" data-dt="${id}" aria-label="السابق">›</button><input type="date" id="${id}" value="${val}"><button data-dstep="1" data-dt="${id}" aria-label="التالي">‹</button></div>`; }
const empty = (icn, t) => `<div class="empty">${ic(icn)}<div>${t}</div></div>`;
function confirmBox(text, okLabel = 'تأكيد', danger = false) {
  return new Promise(res => {
    modal(`<h2>${esc(text)}</h2><div class="mact"><button class="btn ${danger ? 'x' : 'p'}" id="cfOk" style="flex:1">${okLabel}</button><button class="btn" id="cfNo">إلغاء</button></div>`);
    $('#cfOk').onclick = () => { closeModal(); res(true); };
    $('#cfNo').onclick = () => { closeModal(); res(false); };
  });
}
const seg = (attr, list, val) => `<div class="seg">${list.map(([k, l]) => `<button ${attr}="${k}" class="${String(k) === String(val) ? 'on' : ''}">${l}</button>`).join('')}</div>`;

/* ---------- الحالة ---------- */
const S = {
  me: null, roles: [], depts: [], items: [], cats: [], mats: [], users: [], porders: [], whs: [], corders: [], shifts: {}, loadedFrom: null, hdraft: {},
  settings: { shift_times: { am: { start: '07:00', end: '15:00' }, pm: { start: '15:00', end: '23:00' }, remind: 15 }, schedule: { weekly: {}, overrides: {} } },
  cfg: { cake: defaultCakeCfg(), shop: { cur: 'د.ع' }, print: {} },
  page: '', date: todayStr(), shift: new Date().getHours() < 15 ? 'am' : 'pm',
  rfrom: addDays(todayStr(), -6), rto: todayStr(), rtab: 'sales', setTab: 'items', ofilter: 'open', wfilter: 'new', cf: 'act', cq: '', pdept: '', mine: true,
  timers: {}, draft: null,
};
const act = a => a.filter(x => x.active !== false).sort((a, b) => (a.sort || 0) - (b.sort || 0));
const itemOf = id => S.items.find(i => i.id === id);
const matOf = id => S.mats.find(i => i.id === id);
const userOf = id => S.users.find(u => u.id === id);
const deptOf = id => S.depts.find(d => d.id === id);
const deptName = id => deptOf(id)?.name || 'بدون قسم';
const deptDot = id => `<span class="ddot" style="background:${esc(deptOf(id)?.color || '#999')}"></span>`;
const jardItems = () => act(S.items).filter(i => i.jard !== false);
const sellItems = () => act(S.items).filter(i => !i.book && i.sell !== false);
const bookItems = () => act(S.items).filter(i => i.book);

/* ---------- الصلاحيات ---------- */
const isOwner = () => !!S.me && S.me.role === OWNER;
const roleOf = id => S.roles.find(r => r.id === id);
const roleName = id => id === OWNER ? 'المدير الرئيسي' : (roleOf(id)?.name || 'بدون دور');
const roleHas = (id, k) => id === OWNER || !!(roleOf(id)?.perms || {})[k];
const P = k => isOwner() || roleHas(S.me && S.me.role, k);
const PA = (...ks) => ks.some(P);
/* الشيفات: دورهم بيه «prod» ومربوطين بالقسم */
const chefsOf = dept => S.users.filter(u => u.active && roleHas(u.role, 'prod') && u.role !== OWNER && (u.depts || []).includes(dept));
const myDepts = () => S.me ? (S.me.depts || []) : [];
const hallStaff = () => S.users.filter(u => u.active && u.role !== OWNER && roleHas(u.role, 'jard'));

/* ---------- الصفحات والقائمة ---------- */
/* المجموعات بالقائمة الجانبية (تنفتح وتنسد) */
const NAVG = [['', '', ''], ['cake', 'الكيك', 'cake'], ['hall', 'الصالة', 'store'], ['prod', 'المطبخ', 'chef'], ['wh', 'المستودع', 'box'], ['admin', 'الإدارة', 'set']];
const PAGES = {
  home: { t: 'الرئيسية', i: 'home', g: '', ok: () => true },
  dashboard: { t: 'لوحة التحكم', i: 'grid', g: '', ok: () => P('dash') },
  /* الكيك */
  k_show: { t: 'شاشة العرض', i: 'tv', g: 'cake', ok: () => P('c_show') },
  k_ord: { t: 'طلبات الكيك', s: 'الكيك', i: 'bag', g: 'cake', ok: () => PA('c_orders', 'c_book') },
  k_cal: { t: 'تقويم الكيك', s: 'التقويم', i: 'cal', g: 'cake', ok: () => P('c_cal') },
  k_cash: { t: 'صندوق الكيك', i: 'cash', g: 'cake', ok: () => PA('c_cash', 'c_cash_all') },
  k_cus: { t: 'الزبائن', i: 'users', g: 'cake', ok: () => P('c_cus') },
  k_kit: { t: 'مطبخ الكيك', i: 'chef', g: 'cake', ok: () => PA('c_kitchen', 'prod_all') },
  k_rep: { t: 'تقارير الكيك', i: 'chart', g: 'cake', ok: () => P('c_rep') },
  k_cats: { t: 'المناسبات', i: 'grid', g: 'cake', ok: () => PA('c_cat_view', 'c_cat_edit') },
  k_imgs: { t: 'التصاميم والأسعار', i: 'img', g: 'cake', ok: () => PA('c_cat_view', 'c_cat_edit') },
  k_add: { t: 'الإضافات والحشوات', i: 'plus', g: 'cake', ok: () => PA('c_cat_view', 'c_cat_edit') },
  /* الصالة */
  jard: { t: 'جرد الصالة', s: 'الجرد', i: 'clip', g: 'hall', ok: () => PA('jard', 'jard_any', 'reopen') },
  porders: { t: 'طلبيات الصالة للمطبخ', s: 'طلبيات', i: 'layers', g: 'hall', ok: () => PA('po_new', 'prod', 'prod_all') },
  corders: { t: 'الطلبات الخاصة', s: 'طلبات خاصة', i: 'bag', g: 'hall', ok: () => PA('o_view', 'o_book') },
  cash: { t: 'صندوق الطلبات الخاصة', s: 'الصندوق', i: 'cash', g: 'hall', ok: () => PA('cash', 'cash_all') },
  schedule: { t: 'جدول الدوام', s: 'الدوام', i: 'clock', g: 'hall', ok: () => P('sched') },
  /* المطبخ والمستودع */
  production: { t: 'الإنتاج', i: 'chef', g: 'prod', ok: () => PA('prod', 'prod_all') },
  wh: { t: 'المستودع', i: 'box', g: 'wh', ok: () => PA('wh_req', 'wh_issue') },
  /* الإدارة */
  reports: { t: 'التقارير', i: 'chart', g: 'admin', ok: () => P('reports') },
  catalog: { t: 'منتجات الصالة والمواد', s: 'المنتجات', i: 'box', g: 'admin', ok: () => P('catalog') },
  depts: { t: 'أقسام الإنتاج والشيفات', s: 'الأقسام', i: 'layers', g: 'admin', ok: () => P('depts') },
  users: { t: 'المستخدمين', i: 'users', g: 'admin', ok: () => P('users') },
  roles: { t: 'الأدوار والصلاحيات', s: 'الصلاحيات', i: 'shield', g: 'admin', ok: () => P('roles') },
  look: { t: 'المظهر', i: 'edit', g: 'admin', ok: () => P('look') },
  settings: { t: 'الإعدادات والطباعة', s: 'الإعدادات', i: 'set', g: 'admin', ok: () => P('settings') },
  log: { t: 'سجل النشاط', s: 'السجل', i: 'log', g: 'admin', ok: () => P('log') },
  account: { t: 'حسابي', i: 'user', g: '', ok: () => true },
};
const R = {}; // كل صفحة تسجّل دالة العرض مالتها هنا
const myPages = () => Object.keys(PAGES).filter(k => PAGES[k].ok());

/* ---------- تحميل البيانات ---------- */
function applySettings(rows) {
  (rows || []).forEach(r => { if (!r || !r.id || !r.value) return; if (r.id === 'shift_times' || r.id === 'schedule') S.settings[r.id] = r.value; else S.cfg[r.id] = r.value; });
  if (!S.settings.schedule.overrides) S.settings.schedule.overrides = {}; if (!S.settings.schedule.weekly) S.settings.schedule.weekly = {};
  S.cfg.cake = Object.assign(defaultCakeCfg(), S.cfg.cake || {}); S.cfg.shop = Object.assign({ cur: 'د.ع' }, S.cfg.shop || {}); S.cfg.print = S.cfg.print || {}; S.cfg.look = Object.assign(lookCfg(), S.cfg.look || {}); applyLook();
}
const sortR = a => a.sort((x, y) => (x.sort || 0) - (y.sort || 0));
async function loadBase() {
  const from = addDays(todayStr(), -45);
  const [roles, depts, items, cats, mats, users, porders, whs, shifts, corders, settings] = await Promise.all([
    DB.list('roles'), DB.list('depts'), DB.list('items'), DB.list('show_cats'), DB.list('materials'), DB.list('profiles'),
    DB.list('kitchen_orders', { field: 'for_date', from }), DB.list('wh_requests', { field: 'date', from }), DB.list('shifts', { field: 'date', from }), DB.list('orders'), DB.list('settings')]);
  Object.assign(S, { roles: sortR(roles), depts: sortR(depts), items, cats: sortR(cats), mats, users, porders, whs, corders });
  applySettings(settings);
  S.shifts = {}; shifts.forEach(s => S.shifts[s.date + '|' + s.shift] = s); S.loadedFrom = from;
  const me = users.find(u => u.id === S.me.id); if (me) S.me = me;
}
/* أول دخول للمدير: الأدوار والأقسام الجاهزة */
async function seedDefaults() {
  if (!isOwner()) return;
  if (!S.roles.length) { for (const r of defaultRoles()) await DB.upsert('roles', r); S.roles = sortR(await DB.list('roles')); }
  else {
    const MAP = PERM_MAP;
    let ch = false;
    for (const r of S.roles) { const p = r.perms || {}, keys = Object.keys(p); if (!keys.some(k => !PERM_KEYS.includes(k))) continue;
      const np = {}; keys.forEach(k => { if (!p[k]) return; if (PERM_KEYS.includes(k)) np[k] = true; else if (MAP[k]) np[MAP[k]] = true; }); r.perms = np; await DB.upsert('roles', r); ch = true; }
    for (const r of defaultRoles()) if (!S.roles.some(x => x.id === r.id)) { await DB.upsert('roles', r); ch = true; }
    if (ch) S.roles = sortR(await DB.list('roles'));
  }
  if (!S.depts.length) { for (const d of DEFAULT_DEPTS) await DB.upsert('depts', { ...d, active: true }); S.depts = sortR(await DB.list('depts')); }
  if (!S.items.some(i => i.book) && !S.cats.length) { const cd = S.depts.find(d => /كيك/.test(d.name)) || S.depts[0], CD = defaultCakeDesigns(cd ? cd.id : '');
    for (const c of CD.cats) await DB.upsert('show_cats', c); for (const it of CD.items) await DB.upsert('items', it); S.cats = sortR(await DB.list('show_cats')); S.items = await DB.list('items'); toast('انضافت تصاميم كيك افتراضية، تگدر تعدّلها من «التصاميم والأسعار»'); }
  if (!S.cfg.cake || !(await DB.list('settings')).some(x => x.id === 'cake')) { await DB.upsert('settings', { id: 'cake', value: S.cfg.cake }); }
}
async function ensureShifts(from) {
  if (S.loadedFrom && from >= S.loadedFrom) return;
  const rows = await DB.list('shifts', { field: 'date', from, to: addDays(S.loadedFrom || todayStr(), -1) });
  rows.forEach(s => { const k = s.date + '|' + s.shift; if (!S.shifts[k]) S.shifts[k] = s; });
  S.loadedFrom = from;
}
async function refresh(table, rows) {
  const from = addDays(todayStr(), -45);
  const before = { po: S.porders.filter(o => o.status === 'new').map(o => o.id), wh: S.whs.filter(w => w.status === 'new').map(w => w.id), co: S.corders.map(o => o.id) };
  const sig = permSig();
  try {
    const set = async (t, r) => {
      if (t === 'kitchen_orders') S.porders = r; else if (t === 'wh_requests') S.whs = r; else if (t === 'orders') S.corders = r;
      else if (t === 'shifts') r.forEach(s => { const k = s.date + '|' + s.shift; if (!S.timers[k]) S.shifts[k] = s; });
      else if (t === 'profiles') { S.users = r; const me = r.find(u => u.id === S.me.id); if (!me || !me.active) { toast('حسابك انوقف، راجع المدير'); return doLogout(); } S.me = me; }
      else if (t === 'roles') S.roles = sortR(r); else if (t === 'depts') S.depts = sortR(r); else if (t === 'items') S.items = r; else if (t === 'show_cats') S.cats = sortR(r);
      else if (t === 'materials') S.mats = r; else if (t === 'settings') applySettings(r);
    };
    if (rows) await set(table, rows);
    else for (const t of (table === '*' ? ['kitchen_orders', 'wh_requests', 'orders', 'shifts', 'profiles', 'roles', 'depts', 'items', 'show_cats', 'materials', 'settings'] : [table])) {
      const f = { kitchen_orders: { field: 'for_date', from }, wh_requests: { field: 'date', from }, shifts: { field: 'date', from } }[t] || {};
      await set(t, await DB.list(t === 'show_cats' ? 'show_cats' : t, f));
    }
  } catch (e) { return; }
  if (!S.me) return;
  if (sig !== permSig()) { toast('تحدّثت صلاحياتك'); if (!myPages().includes(S.page)) S.page = myPages()[0]; }
  // تنبيهات الشغل الجديد
  const newPO = S.porders.filter(o => o.status === 'new' && !before.po.includes(o.id) && o.chef_id === S.me.id);
  const newWH = S.whs.filter(w => w.status === 'new' && !before.wh.includes(w.id));
  const newCO = S.corders.filter(o => !before.co.includes(o.id));
  if (newPO.length) notify('وصلت طلبية جديدة من الصالة 👨‍🍳');
  if (newWH.length && P('wh_issue')) notify('وصل طلب مواد جديد للمستودع 📦');
  newCO.forEach(o => { if (Object.values(o.chefs || {}).includes(S.me.id)) notify(`طلب زبون جديد #${o.no} إلك 🎂`); else if (P('o_view') && o.by_id !== S.me.id) notify(`طلب زبون جديد #${o.no}`); });
  const a = document.activeElement;
  if (!(a && a.closest && a.closest('#view') && a.matches('input,textarea,select')) && !$('.modal') && $('#pd').hidden && !$('#lb')) render(); else renderNav();
}
const permSig = () => S.me ? JSON.stringify([S.me.role, S.me.depts, isOwner() ? 1 : (roleOf(S.me.role) || {}).perms]) : '';
let actx = null;
function notify(t) {
  toast(t);
  try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); const tm = actx.currentTime;
    [784, 1047].forEach((f, i) => { const o = actx.createOscillator(), g = actx.createGain(); o.frequency.value = f; o.connect(g); g.connect(actx.destination); const s = tm + i * .18; g.gain.setValueAtTime(0, s); g.gain.linearRampToValueAtTime(.2, s + .02); g.gain.exponentialRampToValueAtTime(.001, s + .35); o.start(s); o.stop(s + .4); }); } catch (e) {}
}

/* ---------- سجل النشاط ---------- */
function logAdd(a, k) { if (!S.me) return; DB.upsert('logs', { id: uid(), at: new Date().toISOString(), u: S.me.full_name, uid: S.me.id, a, k: k || '' }).catch(() => {}); }

/* ---------- تسجيل الدخول ---------- */
function renderOffline() {
  $('#root').innerHTML = `<div class="applogin"><div class="alhero"><img src="logo.png" alt=""><b>يحتاج اتصال بالإنترنت</b><span>أول تشغيل على هذا الجهاز يحتاج إنترنت حتى يتحمّل التطبيق</span></div>
    <div class="alform"><button class="btn p w big" onclick="location.reload()">إعادة المحاولة</button></div></div>`;
}
async function renderLogin(err = '') {
  if (MODE === 'cloud' && !err && !S._setupChecked) { S._setupChecked = true; if (await DB.needsSetup()) return renderSetup(); }
  const accs = [['admin', 'المدير'], ['sara', 'كاشير'], ['ahmed', 'صالة'], ['rana', 'شيف كيك'], ['ali', 'شيف كيك وحلويات'], ['haider', 'شيف معجنات'], ['abbas', 'مستودع'], ['noor', 'مشرف']];
  $('#root').innerHTML = `<div class="applogin"><div class="alhero"><img src="logo.png" alt="${SHOP}"><b>${SHOP}</b><span>الكيك · المخبز · الصالة · المستودع</span></div>
    <div class="alform">${err ? `<div class="err">${esc(err)}</div>` : ''}
      <label class="field"><span>اسم المستخدم</span><input class="inp big" id="lu" autocomplete="username" autocapitalize="none" dir="ltr"></label>
      <label class="field"><span>كلمة المرور</span><input class="inp big" id="lp" type="password" autocomplete="current-password" dir="ltr"></label>
      <button type="button" class="btn p w big" id="lbtn">دخول</button>
      ${MODE === 'demo' ? `<div class="demo"><b>نسخة تجريبية:</b> <span class="muted small">اضغط على حساب (كلمة المرور 1234)</span>
        <div class="acc">${accs.map(([u, r]) => `<button type="button" data-demo="${u}">${u}<small>${r}</small></button>`).join('')}</div></div>` : ''}
      <p class="muted small" style="text-align:center;margin-top:18px">تصميم وتطوير <b>Meras Tech</b> · <b dir="ltr">${WAT}</b></p></div></div>`;
  const doLogin = async () => {
    const b = $('#lbtn'); if (b.disabled) return;
    if (!$('#lu').value.trim() || !$('#lp').value) return renderLogin('اكتب اسم المستخدم وكلمة المرور');
    b.disabled = true; b.textContent = 'جاري الدخول…';
    try { S.me = await DB.login($('#lu').value, $('#lp').value); } catch (er) { return renderLogin(er.message); }
    try { await startApp(); } catch (er) { console.error(er); renderLogin('ما گدر يفتح التطبيق: ' + er.message); }
  };
  $('#lbtn').onclick = doLogin;
  ['#lu', '#lp'].forEach(id => $(id).onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); doLogin(); } });
  $$('[data-demo]').forEach(b => b.onclick = () => { $('#lu').value = b.dataset.demo; $('#lp').value = '1234'; doLogin(); });
}
function renderSetup(err = '') {
  $('#root').innerHTML = `<div class="applogin"><div class="alhero"><img src="logo.png" alt=""><b>إعداد أول مرة</b><span>سوّي حساب المدير الرئيسي، وبعدها تضيف الموظفين والشيفات</span></div>
    <div class="alform">${err ? `<div class="err">${esc(err)}</div>` : ''}
      <label class="field"><span>الاسم الكامل</span><input class="inp" id="suName" value="مدير النظام"></label>
      <label class="field"><span>اسم المستخدم (بالإنجليزي)</span><input class="inp" id="suUser" dir="ltr" autocapitalize="none" value="admin"></label>
      <label class="field"><span>كلمة المرور (6 أحرف على الأقل)</span><input class="inp" id="suPass" type="password" dir="ltr"></label>
      <label class="field"><span>أعد كتابتها</span><input class="inp" id="suPass2" type="password" dir="ltr"></label>
      <button type="button" class="btn p w big" id="suBtn">إنشاء الحساب والدخول</button></div></div>`;
  $('#suBtn').onclick = async () => {
    const n = $('#suName').value.trim(), u = $('#suUser').value.trim().toLowerCase(), p = $('#suPass').value;
    if (!n) return renderSetup('اكتب الاسم'); if (!/^[a-z0-9._-]{3,}$/.test(u)) return renderSetup('اسم المستخدم بالإنجليزي، 3 أحرف على الأقل، بدون مسافات');
    if (p.length < 6) return renderSetup('كلمة المرور 6 أحرف على الأقل'); if (p !== $('#suPass2').value) return renderSetup('كلمتين المرور مو نفس الشي');
    const b = $('#suBtn'); b.disabled = true; b.textContent = 'جاري الإعداد…';
    try { S.me = await DB.setupFirstAdmin({ username: u, password: p, full_name: n }); await startApp(); } catch (e) { renderSetup(e.message); }
  };
}
async function doLogout() { try { await DB.logout(); } catch (e) {} S._live = false; S.me = null; S.page = ''; S.shifts = {}; S.loadedFrom = null; try { history.replaceState(null, '', '#/'); } catch (e) {} closeModal(); renderLogin(); }

/* ---------- الهيكل ---------- */
async function startApp() {
  $('#root').innerHTML = `<div class="loading">جاري تحميل البيانات…</div>`;
  try { await loadBase(); await seedDefaults(); } catch (e) { $('#root').innerHTML = `<div class="loading">ما گدر يحمّل البيانات: ${esc(e.message)}<br><button class="btn" onclick="location.reload()" style="margin-top:12px">إعادة المحاولة</button></div>`; return; }
  $('#root').innerHTML = `<div class="shell">
    <aside class="side"><img class="logo" src="logo.png" alt=""><nav id="sideNav"></nav>
      <div class="me"><div class="av">${esc(initials(S.me.full_name))}</div><div class="nm"><b>${esc(S.me.full_name)}</b><small id="meRole"></small></div>
      <button class="iconbtn" data-logout title="تسجيل الخروج">${ic('out')}</button></div></aside>
    <div class="main"><header class="topbar"><img class="mlogo" src="logo.png" alt=""><h1 id="ptitle"></h1>${MODE === 'demo' ? '<span class="demo-pill">نسخة تجريبية</span>' : ''}<span class="sp"></span><span id="licbar"></span></header>
    <main class="view" id="view"></main></div>
    <nav class="bnav" id="bNav"></nav></div>`;
  const pages = myPages(); if (!pages.includes(S.page)) S.page = pages.includes('home') ? 'home' : pages[0];
  { const c = currentCtx(); S.date = c.date; S.shift = c.shift; }
  if (PA('wh_req') && !P('wh_issue')) S.wfilter = 'all';
  bindShell();
  let h = ''; try { h = location.hash.slice(2); } catch (e) {} go(h && pages.includes(h) ? h : S.page, true);
  if (!S._live) { S._live = true; DB.onChange((t, rows) => refresh(t, rows)); }
  if (!S._timers) { S._timers = true; if (MODE === 'demo') setInterval(() => S.me && refresh('*'), 60000); setInterval(() => { remindTick(); if (S.me && ['home', 'production', 'dashboard'].includes(S.page) && !$('.modal')) render(); }, 60000); setTimeout(remindTick, 3000); }
  if (window.licBar) licBar();
}
function remindTick() {
  if (!S.me || !P('jard') || P('jard_any')) return;
  const c = currentCtx(); if (!canEditShift(c.date, c.shift) || scheduleEmpty()) return;
  const r = getRec(c.date, c.shift); const m = Math.round((shiftEnd(c.date, c.shift) - Date.now()) / 60000), k = 'rem' + recKey(c.date, c.shift);
  if (r && r.opened && !r.closed && m <= S.settings.shift_times.remind && m > 0 && !S[k]) { S[k] = 1; notify(`باقي ${m} دقيقة على نهاية شفتك. سجّل الجرد وسكّر الشفت.`); }
  const sk = 'start' + recKey(c.date, c.shift);
  if ((!r || !r.opened) && !S[sk]) { S[sk] = 1; toast('بداية شفتك: استلم الشفت وعدّ الموجود'); }
}
function badgeFor(k) {
  const me = S.me.id;
  if (k === 'jard' && P('jard') && !P('jard_any')) { const c = currentCtx(); const r = getRec(c.date, c.shift); return canEditShift(c.date, c.shift) && (!r || !r.opened) ? '!' : 0; }
  if (k === 'wh' && P('wh_issue')) return S.whs.filter(w => w.status === 'new').length;
  if (k === 'production') return S.porders.filter(o => o.status === 'new' && o.chef_id === me).length + S.corders.filter(o => !['done', 'cancel'].includes(o.st) && Object.entries(o.chefs || {}).some(([d, c]) => c === me && (o.prod || {})[d] === 'new')).length;
  if (k === 'corders' && P('o_deliver')) return S.corders.filter(o => o.st === 'ready').length;
  return 0;
}
let navOpen = (() => { try { return JSON.parse(localStorage.getItem('san_nav') || '{}'); } catch (e) { return {}; } })();
function renderNav() {
  const pages = myPages(), b = k => { const n = badgeFor(k); return n ? `<span class="badge">${n}</span>` : ''; }, cg = PAGES[S.page] && PAGES[S.page].g;
  let h = '';
  NAVG.forEach(([g, t, gi]) => { const L = pages.filter(k => k !== 'account' && PAGES[k].g === g); if (!L.length) return;
    const item = k => `<button class="navi ${k === S.page ? 'on' : ''}" data-go="${k}">${ic(PAGES[k].i)}<span>${PAGES[k].t}</span>${b(k)}</button>`;
    if (!g) { h += L.map(item).join(''); return; }
    const open = navOpen[g] === true || (navOpen[g] == null && g === cg), cnt = L.reduce((s, k) => s + (+badgeFor(k) || 0), 0);
    h += `<button class="navgh ${open ? 'open' : ''}" data-navg="${g}">${ic(gi)}<span>${t}</span>${!open && cnt ? `<span class="badge">${cnt}</span>` : ''}<i>${ic('chev')}</i></button><div class="navgb" ${open ? '' : 'hidden'}>${L.map(item).join('')}</div>`; });
  $('#sideNav').innerHTML = h + `<div style="flex:1;min-height:10px"></div><button class="navi ${S.page === 'account' ? 'on' : ''}" data-go="account">${ic('user')}<span>حسابي</span></button>`;
  $('#meRole').textContent = roleName(S.me.role);
  const pri = ['home', 'k_show', 'k_ord', 'production', 'k_kit', 'jard', 'corders', 'wh', 'dashboard'].filter(k => pages.includes(k));
  const main = pri.slice(0, 4), extra = pages.filter(k => !main.includes(k));
  $('#bNav').innerHTML = main.map(k => `<button class="${k === S.page ? 'on' : ''}" data-go="${k}">${ic(PAGES[k].i)}<span>${PAGES[k].s || PAGES[k].t}</span>${b(k)}</button>`).join('')
    + (extra.length ? `<button class="${extra.includes(S.page) ? 'on' : ''}" data-more>${ic('more')}<span>المزيد</span></button>` : '');
  S._extra = extra;
}
/* المظهر: يتحكم بكل التطبيق (الإدارة ← المظهر) */
const THEMES = [{ n: 'سنابل', ac: '#FC8312', bg: '#F6F2ED' }, { n: 'سنابل ذهبي', ac: '#b9792b', bg: '#fbf3e4' }, { n: 'وردي', ac: '#d9467a', bg: '#fff6f1' }, { n: 'بنفسجي', ac: '#7b6cf6', bg: '#f4f6fb' },
  { n: 'أخضر', ac: '#2f9e6f', bg: '#f3faf5' }, { n: 'شوكولاتة', ac: '#8a5a44', bg: '#fbf3ec' }, { n: 'ذهبي غامق', ac: '#e0b04a', bg: '#1b1416' }, { n: 'أزرق ليلي', ac: '#2b7de9', bg: '#12161f' }];
const lum = h => { const n = parseInt(String(h || '#fff').slice(1), 16); return (.299 * (n >> 16) + .587 * (n >> 8 & 255) + .114 * (n & 255)) / 255; };
const shade = (h, f) => { const n = parseInt(h.slice(1), 16), c = x => Math.max(0, Math.min(255, Math.round(x * f))); return '#' + [n >> 16, n >> 8 & 255, n & 255].map(c).map(x => x.toString(16).padStart(2, '0')).join(''); };
function lookCfg() { let L = S.cfg && S.cfg.look; if (!L) { try { L = JSON.parse(localStorage.getItem('san_look') || 'null'); } catch (e) {} } return Object.assign({ font: 'Tajawal', view: 'slider', ratio: '4/5', fit: 'cover', rad: 22, lh: 44, auto: false, sec: 4 }, L || {}); }
function applyLook() {
  const L = lookCfg(), st = document.documentElement.style;
  ['--accent', '--accent-d', '--accent-soft', '--accent-ink', '--bg', '--surface', '--ink', '--muted', '--line', '--field', '--brand'].forEach(k => st.removeProperty(k));
  st.setProperty('--ff', "'" + (L.font || 'Tajawal') + "'"); st.setProperty('--rad', (L.rad ?? 22) + 'px'); st.setProperty('--lh', (L.lh || 44) + 'px');
  const q = (L.ratio || '4/5').split('/'); st.setProperty('--rw', q[0]); st.setProperty('--rh', q[1]); st.setProperty('--fit', L.fit || 'cover');
  if (L.ac) { st.setProperty('--accent', L.ac); st.setProperty('--accent-d', shade(L.ac, .86)); st.setProperty('--accent-soft', `color-mix(in srgb, ${L.ac} 14%, #fff)`); st.setProperty('--accent-ink', lum(L.ac) > .65 ? '#222' : '#fff'); }
  if (L.bg) { const dk = lum(L.bg) < .4; st.setProperty('--bg', L.bg);
    if (dk) { st.setProperty('--surface', '#241a1d'); st.setProperty('--ink', '#f6e9e6'); st.setProperty('--muted', '#b49c9c'); st.setProperty('--line', '#41302f'); st.setProperty('--field', '#2e2226'); st.setProperty('--brand', '#120c0e'); if (L.ac) st.setProperty('--accent-soft', `color-mix(in srgb, ${L.ac} 22%, #241a1d)`); } }
  try { localStorage.setItem('san_look', JSON.stringify(L)); } catch (e) {}
}
const applyFont = applyLook;
function go(p, replace) {
  if (!myPages().includes(p)) p = myPages()[0];
  S.page = p; if (PAGES[p].g) navOpen[PAGES[p].g] = true;
  try { if (replace) history.replaceState(null, '', '#/' + p); else history.pushState(null, '', '#/' + p); } catch (e) {}
  closeModal(); render(); window.scrollTo(0, 0);
}
async function render() {
  if (!S.me || !$('#view')) return;
  renderNav();
  $('#ptitle').textContent = S.page === 'home' ? SHOP : PAGES[S.page].t;
  document.title = PAGES[S.page].t + ' · ' + SHOP;
  try { await R[S.page](); } catch (e) { console.error(e); $('#view').innerHTML = `<div class="alert">${ic('alert')}<div>صار خطأ بهاي الصفحة: ${esc(e.message)}</div></div>`; }
}

/* ---------- الأحداث: كل قسم يسجّل معالجاته ---------- */
const H = { click: [], input: [], change: [] };
function bindShell() {
  if (S._bound) return; S._bound = true;
  document.addEventListener('click', onClick);
  document.addEventListener('input', e => { for (const f of H.input) if (f(e.target, e) === true) return; });
  document.addEventListener('change', async e => { for (const f of H.change) if ((await f(e.target, e)) === true) return; });
  window.addEventListener('popstate', () => { const p = location.hash.slice(2); if (S.me && p && p !== S.page) { S.page = myPages().includes(p) ? p : S.page; closeModal(); render(); } });
}
async function onClick(e) {
  const t = e.target.closest('button,[data-go],a,[data-a]'); if (!t) { if (e.target.classList.contains('modal')) closeModal(); return; }
  const ds = t.dataset;
  try {
    if (ds.go) return go(ds.go);
    if (ds.more !== undefined) return modal(`<h2>المزيد<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2><div style="display:flex;flex-direction:column;gap:4px">${S._extra.map(k => `<button class="navi" data-go="${k}">${ic(PAGES[k].i)}${PAGES[k].t}</button>`).join('')}<button class="navi" data-logout style="color:var(--red)">${ic('out')}تسجيل الخروج</button></div>`);
    if (ds.close !== undefined) return closeModal();
    if (ds.navg) { const g = ds.navg, was = navOpen[g] === true || (navOpen[g] == null && PAGES[S.page].g === g); navOpen[g] = !was; try { localStorage.setItem('san_nav', JSON.stringify(navOpen)); } catch (e) {} return renderNav(); }
    if (ds.logout !== undefined) { if (await confirmBox('تسجيل خروج ' + S.me.full_name + '؟', 'خروج', true)) doLogout(); return; }
    if (ds.dstep) { const inp = $('#' + ds.dt); inp.value = addDays(inp.value, +ds.dstep); inp.dispatchEvent(new Event('change', { bubbles: true })); return; }
    if (t.id === 'doCopy') { const ta = $('#shareTxt'); ta.select(); try { await navigator.clipboard.writeText(ta.value); } catch (_) { document.execCommand('copy'); } return toast('تم النسخ'); }
    for (const f of H.click) if ((await f(t, ds, t.id, e)) === true) return;
  } catch (er) { console.error(er); t.disabled = false; toast('صار خطأ: ' + er.message); }
}

/* ---------- البدء ---------- */
async function boot() {
  applyFont();
  try { const m = /[#&]lic=([^&]+)/.exec(location.hash); if (m) { if (!localStorage.getItem('sanabel_lic')) localStorage.setItem('sanabel_lic', decodeURIComponent(m[1])); history.replaceState(null, '', location.pathname + location.search); } } catch (e) {}
  const t0 = Date.now(), hideSplash = () => { const sp = $('#splash'); if (!sp) return; setTimeout(() => { sp.classList.add('out'); setTimeout(() => sp.remove(), 700); }, Math.max(0, 1400 - (Date.now() - t0))); };
  if (MODE === 'offline') { hideSplash(); return renderOffline(); }
  if (window.Android && window.licCheck) { await licCheck(); if (!licOK()) { hideSplash(); return renderLic(); } }
  try { S.me = await DB.session(); } catch (e) { S.me = null; }
  if (S.me) await startApp(); else await renderLogin();
  hideSplash();
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});
}
