/* ===== قائمة الصلاحيات: هنا تنضاف أي صلاحية جديدة =====
   الدور «manager» = المدير الرئيسي: عنده كل الصلاحيات، وما ينحذف ولا يتعدّل */
const OWNER = 'manager';
const PERMS = [
  { g: 'cake', t: 'الكيك', ic: '🎂', items: [
    ['c_show', 'شاشة العرض (الكيك والأسعار)'],
    ['c_book', 'حجز طلب كيك'],
    ['c_orders', 'طلبات الكيك: مشاهدة وتغيير الحالة'],
    ['c_deliver', 'تسليم الكيك واستلام الفلوس وتسديد الديون'],
    ['c_cancel', 'إلغاء طلب كيك'],
    ['c_delete', 'حذف طلب كيك نهائياً'],
    ['c_kitchen', 'مطبخ الكيك (يشوف طلبات الكيك ويجهزها)'],
    ['c_cal', 'تقويم الكيك'],
    ['c_overcap', 'الحجز فوق الحد اليومي'],
    ['c_cash', 'صندوق الكيك (صندوقه هو)'],
    ['c_cash_all', 'صندوق الكيك لكل الموظفين'],
    ['c_cus', 'زبائن الكيك والمناسبات'],
    ['c_rep', 'تقارير الكيك'],
    ['c_cat_view', 'مشاهدة المناسبات والتصاميم والأسعار'],
    ['c_cat_edit', 'تعديل المناسبات والتصاميم والأسعار والإضافات'],
  ] },
  { g: 'hall', t: 'الصالة', ic: '🧾', items: [
    ['jard', 'تسجيل جرد الشفت (يطلع بجدول الدوام)'],
    ['jard_any', 'تعديل جرد أي شفت وتعديل البداية والوارد'],
    ['reopen', 'إعادة فتح شفت مغلق'],
    ['po_new', 'طلبيات الصالة للمطبخ: إنشاء واستلام'],
    ['o_book', 'تسجيل طلب خاص لزبون (معمول وغيره)'],
    ['o_view', 'مشاهدة الطلبات الخاصة'],
    ['o_deliver', 'تسليم الطلب الخاص واستلام الفلوس'],
    ['o_cancel', 'إلغاء طلب خاص'],
    ['o_delete', 'حذف طلب خاص'],
    ['o_overcap', 'طلب خاص فوق الحد اليومي'],
    ['cash', 'صندوق الطلبات الخاصة (صندوقه هو)'],
    ['cash_all', 'صندوق الطلبات الخاصة لكل الموظفين'],
    ['sched', 'جدول الدوام وأوقات الشفتات'],
  ] },
  { g: 'prod', t: 'المطبخ', ic: '👨‍🍳', items: [
    ['prod', 'شيف: يستلم وينتج الطلبيات (يطلع باختيار الشيف بأقسامه)'],
    ['prod_all', 'مشاهدة إنتاج كل الأقسام ومتابعته'],
  ] },
  { g: 'wh', t: 'المستودع', ic: '📦', items: [
    ['wh_req', 'طلب مواد أولية من المستودع'],
    ['wh_issue', 'صرف المواد من المستودع'],
  ] },
  { g: 'admin', t: 'الإدارة', ic: '⚙️', items: [
    ['dash', 'لوحة التحكم (ملخص المحل)'],
    ['reports', 'تقارير الصالة والمطبخ'],
    ['catalog', 'منتجات الصالة والأسعار والمواد'],
    ['depts', 'أقسام الإنتاج وربط الشيفات'],
    ['users', 'المستخدمين'],
    ['roles', 'الأدوار والصلاحيات (حساسة: تگدر تنطي أي صلاحية)'],
    ['look', 'المظهر (الألوان والخط وطريقة العرض والشعار)'],
    ['settings', 'إعدادات المحل والطباعة والنسخ الاحتياطي'],
    ['log', 'سجل النشاط'],
  ] },
];
const PERM_KEYS = [].concat(...PERMS.map(g => g.items.map(x => x[0])));
/* صلاحيات قديمة تتحوّل للجديدة */
const PERM_MAP = { c_look: 'look', c_print: 'settings', c_backup: 'settings', display: 'c_show', calendar: 'c_cal', customers: 'c_cus', b_dash: 'dash', b_jard: 'jard', b_jard_any: 'jard_any', b_reopen: 'reopen', b_order_new: 'po_new', b_produce: 'prod',
  b_wh_req: 'wh_req', b_wh_issue: 'wh_issue', b_sched: 'sched', b_items: 'catalog', b_rep: 'reports', s_users: 'users', s_roles: 'roles', s_log: 'log' };

/* أدوار جاهزة (تگدر تعدّلها أو تحذفها). hall/chef/store نفس أدوار تطبيق الجرد القديم */
const CAKE_SELL = ['c_show', 'c_book', 'c_orders', 'c_deliver', 'c_cal', 'c_cash', 'c_cus'];
const DEFAULT_ROLES = [
  { id: 'hall', name: 'موظف صالة', sort: 1, perms: ['jard', 'po_new', 'o_book', 'o_view', 'o_deliver', 'cash', ...CAKE_SELL] },
  { id: 'cashier', name: 'كاشير', sort: 2, perms: ['o_book', 'o_view', 'o_deliver', 'cash', ...CAKE_SELL] },
  { id: 'chef', name: 'شيف', sort: 3, perms: ['prod', 'wh_req'] },
  { id: 'cake_chef', name: 'شيف كيك', sort: 4, perms: ['prod', 'wh_req', 'c_kitchen', 'c_orders'] },
  { id: 'head_chef', name: 'رئيس الشيفات', sort: 5, perms: ['prod', 'prod_all', 'wh_req', 'po_new', 'c_kitchen', 'c_orders'] },
  { id: 'store', name: 'أمين مستودع', sort: 6, perms: ['wh_issue'] },
  { id: 'supervisor', name: 'مشرف', sort: 7, perms: [...CAKE_SELL, 'c_cancel', 'c_kitchen', 'c_overcap', 'c_cash_all', 'c_rep', 'c_cat_view', 'jard', 'jard_any', 'reopen', 'po_new', 'o_book', 'o_view', 'o_deliver', 'o_cancel', 'o_overcap', 'cash', 'cash_all', 'sched', 'prod_all', 'dash', 'reports'] },
  { id: 'display', name: 'شاشة عرض للزبائن', sort: 8, perms: ['c_show'] },
];
const DEFAULT_DEPTS = [
  { id: 'd_cake', name: 'الكيك', color: '#D9467A', sort: 1 },
  { id: 'd_pastry', name: 'المعجنات والفطائر', color: '#E8833A', sort: 2 },
  { id: 'd_sweets', name: 'الحلويات والكليجة والمعمول', color: '#8A5A44', sort: 3 },
];
