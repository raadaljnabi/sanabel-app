/* ===== المبيعات: شاشة العرض + طلبات الزبائن (كيك مخصص أو منتجات) + التقويم + الصندوق + الزبائن ===== */
const CK = () => S.cfg.cake;
/* نوع الطلب: cake = طلبات الكيك · special = الطلبات الخاصة بالصالة */
const kindOf = o => o.kind || ((o.lines || []).some(l => l.size || l.fill || l.txt) ? 'cake' : 'special');
const PKM = { cake: { book: 'c_book', view: 'c_orders', deliver: 'c_deliver', cancel: 'c_cancel', del: 'c_delete', overcap: 'c_overcap', cash: 'c_cash', cash_all: 'c_cash_all' },
  special: { book: 'o_book', view: 'o_view', deliver: 'o_deliver', cancel: 'o_cancel', del: 'o_delete', overcap: 'o_overcap', cash: 'cash', cash_all: 'cash_all' } };
const PK = (k, op) => P(PKM[k || 'special'][op]);
const KL = { cake: 'طلبات الكيك', special: 'الطلبات الخاصة' };
/* ---- حسابات الطلب ---- */
function lineTotal(l) { let per = (+l.price || 0) + (l.fill ? +l.fill.p || 0 : 0), one = 0; (l.adds || []).forEach(a => { if (a.c) one += (+a.p || 0) * a.c; else per += +a.p || 0; }); return per * (+l.qty || 0) + one; }
const orderTotal = o => (o.lines || []).reduce((s, l) => s + lineTotal(l), 0);
const remOf = o => Math.max(0, (o.total || 0) - (o.dep || 0));
const netTotal = o => (o.total || 0) - (o.disc || 0);
const dueD = o => new Date(o.due);
const oDepts = o => [...new Set((o.lines || []).map(l => l.dept || ''))];
const fromP = it => { const ps = (it.sizes || []).map(s => +s.p || 0).filter(Boolean); if (!ps.length && it.price) ps.push(+it.price); if (!ps.length) return ''; return `<div class="gfrom">${ps.length > 1 ? '<span>يبدأ من</span> ' : ''}<b>${fmt(Math.min(...ps))}</b> <small>${cur()}</small></div>`; };
/* الحالة العامة من حالة كل قسم */
function syncSt(o) { if (o.st === 'done' || o.st === 'cancel') return; const v = oDepts(o).map(d => (o.prod || {})[d] || 'new'); o.st = v.length && v.every(x => x === 'sent') ? 'ready' : v.some(x => x !== 'new') ? 'prep' : 'new'; }
const lineDesc = l => [l.size, l.fill ? 'حشوة ' + l.fill.n : '', (l.adds || []).map(a => a.n + (a.c ? ' × ' + a.c : '')).join('، '), l.txt ? '«' + l.txt + '»' : ''].filter(Boolean).join(' · ');
const qtyTxt = l => `${r3(l.qty)} ${l.unit && l.unit !== 'قطعة' ? l.unit : (l.qty > 1 || !l.size ? 'قطعة' : '')}`.trim();
const findCO = id => S.corders.find(o => o.id === id);
async function saveCO(o, msg) { o.upd = Date.now(); const saved = await DB.upsert('orders', o); const i = S.corders.findIndex(x => x.id === saved.id); if (i >= 0) S.corders[i] = saved; else S.corders.unshift(saved); if (msg) logAdd(msg, 'co'); return saved; }

/* ---------- شاشة العرض (سلايدر · شبكة · قائمة) ---------- */
let dTimer = null;
R.k_show = function () {
  clearInterval(dTimer);
  const L = lookCfg(), cats = S.cats.filter(c => bookItems().some(i => i.cat === c.id)), other = bookItems().filter(i => !cats.some(c => c.id === i.cat));
  const c = S.dcat && (S.dcat === '_other' || cats.some(x => x.id === S.dcat)) ? S.dcat : '';
  const head = `<div class="toolbar dhead"><div class="dbrand"><img src="${lg()}" alt="" style="height:var(--lh)"><div><b>${SHOP}</b>${S.cfg.shop.slogan ? `<small>${esc(S.cfg.shop.slogan)}</small>` : ''}</div></div><span class="sp"></span>${P('c_book') ? `<button class="btn p" data-a="newCO" data-k="cake">${ic('plus')} حجز جديد</button>` : ''}</div>`;
  if (!c) {
    $('#view').innerHTML = head + `<div class="tiles2">${cats.map(x => { const its = bookItems().filter(i => i.cat === x.id), src = x.cover || (its[0] && its[0].img); return `<button class="tile2" data-dcat="${x.id}">${src ? `<img src="${src}" alt="">` : ''}<span>${esc(x.name)}<small>${its.length} تصميم</small></span></button>`; }).join('')}
    ${other.length ? `<button class="tile2" data-dcat="_other">${other[0].img ? `<img src="${other[0].img}" alt="">` : ''}<span>تصاميم أخرى<small>${other.length} تصميم</small></span></button>` : ''}</div>
    ${!cats.length && !other.length ? empty('cake', 'ماكو تصاميم كيك بعد. ضيفها من «التصاميم والأسعار»') : ''}`;
    return;
  }
  const list = c === '_other' ? other : bookItems().filter(i => i.cat === c); S.dlist = list.map(i => i.id);
  const nav = `<div class="toolbar"><button class="btn" data-dcat="">→ المناسبات</button><div class="filters chn">${cats.map(x => `<button data-dcat="${x.id}" class="${x.id === c ? 'on' : ''}">${esc(x.name)}</button>`).join('')}</div></div>`;
  if (L.view === 'slider') {
    S.di = Math.min(S.di || 0, list.length - 1);
    $('#view').innerHTML = nav + `<div class="sbody"><div class="stage" id="stage"><div class="track" id="track">${list.map(it => `<div class="slide">${it.img ? `<img src="${it.img}" alt="">` : ''}</div>`).join('')}</div>
      ${list.length > 1 ? `<button class="arr l" data-a="sprev">‹</button><button class="arr r" data-a="snext">›</button>` : ''}<div class="dots">${list.map((_, k) => `<button class="dot" data-sdot="${k}"></button>`).join('')}</div><span class="hint2">اضغط للتكبير</span></div>
      <div class="sinfo card" id="sinfo"></div></div>`;
    slideGo(S.di); slideBind(); if (L.auto && list.length > 1) dTimer = setInterval(() => { if (S.page !== 'k_show' || !$('#track')) return clearInterval(dTimer); slideGo(S.di + 1); }, Math.max(2, +L.sec || 4) * 1000);
    return;
  }
  $('#view').innerHTML = nav + `<div class="gal ${L.view === 'list' ? 'lv' : ''}">${list.map(it => `<button class="gi" data-ditem="${it.id}">${it.img ? `<img src="${it.img}" alt="" loading="lazy">` : `<div class="noimg">${ic('cake')}</div>`}<div class="gc"><b>${esc(it.name)}</b>${it.desc ? `<div class="gd">${esc(it.desc)}</div>` : ''}${fromP(it)}${L.view === 'list' && (it.sizes || []).length > 1 ? `<div class="chips">${it.sizes.map(z => `<span>${esc(z.n)} <i>${fmt(z.p)}</i></span>`).join('')}</div>` : ''}</div></button>`).join('')}</div>`;
};
function slideGo(n) {
  const L = S.dlist || [], tr = $('#track'); if (!L.length || !tr) return; S.di = (n + L.length) % L.length; tr.style.transform = `translateX(${S.di * 100}%)`;
  $$('.dot').forEach((d, k) => d.classList.toggle('on', k === S.di));
  const it = itemOf(L[S.di]), sz = (it.sizes || []).filter(z => z.n || z.p);
  $('#sinfo').innerHTML = `<b class="st1">${esc(it.name)}</b>${it.desc ? `<p class="muted">${esc(it.desc)}</p>` : ''}${sz.length ? `<div class="szl">${sz.map(z => `<div><span>${esc(z.n)}</span><b>${fmt(z.p)} <small>${cur()}</small></b></div>`).join('')}</div>` : fromP(it)}
    ${P('c_book') ? `<button class="btn p big w" data-ditem="${it.id}">${ic('cake')} احجز الآن</button>` : ''}`;
}
function slideBind() {
  const st = $('#stage'), tr = $('#track'); if (!st) return; let x0 = null;
  st.onpointerdown = e => { if (e.target.closest('.arr,.dot')) return; x0 = e.clientX; tr.style.transition = 'none'; clearInterval(dTimer); };
  st.onpointermove = e => { if (x0 !== null) tr.style.transform = `translateX(calc(${S.di * 100}% + ${e.clientX - x0}px))`; };
  st.onpointerup = e => { if (x0 === null) return; const d = e.clientX - x0; tr.style.transition = ''; x0 = null; if (Math.abs(d) < 8) { const it = itemOf(S.dlist[S.di]); return viewImg(it.img, it.name, S.dlist.map(itemOf), S.di); } slideGo(Math.abs(d) > st.clientWidth * .15 ? (d > 0 ? S.di + 1 : S.di - 1) : S.di); };
  st.onpointercancel = () => { x0 = null; tr.style.transition = ''; slideGo(S.di); };
}

/* ---------- بناء الطلب (سلة) ---------- */
const pgKind = () => ['corders', 'cash'].includes(S.page) ? 'special' : 'cake';
const PH_MAX = 3;
function newCart(kind) { const t = addDays(todayStr(), 1); return { kind: kind || 'special', lines: [], name: '', phone: '', date: t, time: '17:00', dep: '', note: '', chefs: {}, photos: [] }; }
function pdOpen(html) { const p = $('#pd'); p.hidden = false; p.innerHTML = html; p.scrollTop = 0; }
function pdClose() { const p = $('#pd'); p.hidden = true; p.innerHTML = ''; S.pdx = null; }
/* صفحة الكيكة: الحجم والحشوة والإضافات */
function openItem(id) {
  const it = itemOf(id); if (!it) return;
  if (!P('c_book')) return viewImg(it.img, it.name);
  S.pdx = { iid: id, size: (it.sizes || []).length === 1 ? 0 : -1, qty: 1, fill: null, ad: {}, txt: '', note: '' }; drawItem();
}
function itemDraftLine() {
  const d = S.pdx, it = itemOf(d.iid), sz = (it.sizes || [])[d.size], f = CK().fills.find(x => x.id === d.fill);
  const adds = CK().addons.filter(a => d.ad[a.id]).map(a => { const r = { n: a.n, p: +a.p || 0 }; if (a.cnt) r.c = +d.ad[a.id]; if (a.ph) r.ph = 1; return r; });
  return { id: uid(), iid: it.id, name: it.name, dept: it.dept || '', qty: d.qty, unit: 'قطعة', size: sz ? sz.n : '', price: sz ? +sz.p || 0 : +it.price || 0, fill: f ? { n: f.n, p: +f.p || 0 } : null, adds, txt: d.txt.trim(), note: d.note.trim() };
}
function drawItem() {
  const d = S.pdx, it = itemOf(d.iid), L = it.sizes || [], C = CK(), line = itemDraftLine();
  pdOpen(`<div class="pdw"><div class="pdimg">${it.img ? `<img src="${it.img}" alt="" data-a="zoom">` : ''}<button class="pdback" data-a="pdx">→</button></div>
  <div class="pdb"><div class="pdh"><h2>${esc(it.name)}</h2><div class="qty"><button data-a="qm" ${d.qty < 2 ? 'disabled' : ''}>−</button><b>${d.qty}</b><button data-a="qp">+</button></div></div>
    ${it.desc ? `<p class="muted">${esc(it.desc)}</p>` : ''}
    ${L.length ? `<h4>اختار الحجم</h4><div class="szs">${L.map((s, j) => `<button class="${j === d.size ? 'on' : ''}" data-a="psz" data-i="${j}"><span>${esc(s.n || '—')}</span>${s.p ? `<small>${fmt(s.p)} ${cur()}</small>` : ''}</button>`).join('')}</div>` : ''}
    ${C.fills.length ? `<h4>اختار الحشوة ${C.fillReq ? '' : '<small class="muted">اختياري</small>'}</h4><div class="szs">${C.fills.map(f => `<button class="${d.fill === f.id ? 'on' : ''}" data-a="pfill" data-id="${f.id}"><span>${esc(f.n)}</span>${+f.p ? `<small>+ ${fmt(f.p)}</small>` : ''}</button>`).join('')}</div>` : ''}
    ${C.addons.length ? `<h4>الإضافات <small class="muted">اختياري</small></h4><div class="ads">${C.addons.map(a => { const c = +d.ad[a.id] || 0;
      return a.cnt ? `<div class="adr ${c ? 'on' : ''}"><span class="nm">${esc(a.n)} <small class="muted">${+a.p ? fmt(a.p) + ' للواحدة' : 'مجاناً'}</small></span><div class="stp"><button data-a="adm" data-id="${a.id}" ${c ? '' : 'disabled'}>−</button><em>${c}</em><button data-a="adp" data-id="${a.id}">+</button></div></div>`
        : `<button class="adr ${c ? 'on' : ''}" data-a="pad" data-id="${a.id}"><span class="ck"></span><span class="nm">${esc(a.n)}${a.ph ? ' 📷' : ''}</span><b>${+a.p ? '+ ' + fmt(a.p) : 'مجاناً'}</b></button>`; }).join('')}</div>` : ''}
    <label class="field" style="margin-top:12px"><span>الكتابة على الكيك</span><input class="inp" id="ptxt" maxlength="60" value="${esc(d.txt)}" placeholder="مثلاً: عيد ميلاد سعيد يا سارة"></label>
    <label class="field"><span>ملاحظات على الكيكة</span><input class="inp" id="pnote" value="${esc(d.note)}" placeholder="لون معيّن، تعديل على التصميم…"></label>
  </div></div>
  <div class="pdbar"><div><small class="muted">المجموع</small><b>${d.size < 0 && L.length ? 'اختار الحجم' : money(lineTotal(line))}</b></div><button class="btn p big" data-a="padd">${ic('plus')} أضف للطلب</button></div>`);
}
/* اختيار منتجات بالعدد (معمول، كليجة، معجنات…) */
function openProducts() {
  const groups = byDept(sellItems());
  modal(`<h2>منتجات للطلب<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <input class="inp" id="mFilter" placeholder="ابحث عن منتج…" style="margin-bottom:6px">
    ${groups.map(([k, its]) => `<div class="dgroup"><div class="dgh">${deptDot(k)}<b>${esc(k ? deptName(k) : 'بدون قسم')}</b></div>${its.map(it => `<div class="fline" data-name="${esc(it.name)}"><span>${esc(it.name)} <span class="unit">${it.price ? fmt(it.price) + ' / ' : ''}${esc(it.unit)}</span></span>
      <input class="num" inputmode="${im(it.unit)}" data-pq="${it.id}" placeholder="0"><span class="hint">${esc(it.unit)}</span></div>`).join('')}</div>`).join('') || empty('box', 'ماكو منتجات')}
    <div class="mact"><button class="btn p" data-a="pqAdd">${ic('plus')} أضف للطلب</button><button class="btn" data-close>إلغاء</button></div>`, true);
}
function pickDesign() {
  const L = bookItems();
  modal(`<h2>اختار تصميم الكيك<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <input class="inp" id="mFilter" placeholder="ابحث…" style="margin-bottom:8px">
    <div class="pickg">${L.map(it => `<button class="pk" data-name="${esc(it.name)}" data-ditem="${it.id}">${it.img ? `<img src="${it.img}" alt="">` : ''}<b>${esc(it.name)}</b>${fromP(it)}</button>`).join('') || empty('cake', 'ماكو تصاميم')}</div>`, true);
}
function drawCart() {
  const c = S.cart, tot = c.lines.reduce((s, l) => s + lineTotal(l), 0), dep = +c.dep || 0, depts = [...new Set(c.lines.map(l => l.dept || ''))];
  const needPh = c.lines.some(l => (l.adds || []).some(a => a.ph)), ck = c.kind === 'cake', phs = c.photos || [];
  pdOpen(`<div class="ckw"><div class="pdtop"><button class="pdback s" data-a="pdx">→</button><h2>${ck ? 'حجز كيك لزبون' : 'طلب خاص لزبون'}</h2></div>
  <div class="card pad"><div class="sec" style="margin-top:0">${ic('bag')} محتويات الطلب</div>
    ${c.lines.length ? c.lines.map((l, i) => `<div class="cl">${l.iid && itemOf(l.iid)?.img ? `<img src="${itemOf(l.iid).img}" alt="">` : `<span class="clic">${ic('box')}</span>`}<div class="grow"><b>${esc(l.name)}</b> <span class="muted small">${esc(qtyTxt(l))}</span><div class="muted small">${deptDot(l.dept)} ${esc(deptName(l.dept))}${lineDesc(l) ? ' · ' + esc(lineDesc(l)) : ''}</div></div><b>${fmt(lineTotal(l))}</b><button class="iconbtn" data-a="cdel" data-i="${i}">${ic('trash')}</button></div>`).join('') : `<p class="muted">${ck ? 'الطلب فارغ. اختار تصميم كيك.' : 'الطلب فارغ. ضيف منتجات (معمول، كليجة، معجنات…).'}</p>`}
    <div class="row" style="margin-top:10px">${ck && bookItems().length ? `<button class="btn" data-a="addCake">${ic('cake')} + كيك</button>` : ''}<button class="btn" data-a="addProd">${ic('box')} + منتجات${ck ? '' : ' بالعدد'}</button></div></div>
  ${c.lines.length ? `<div class="card pad"><div class="sec" style="margin-top:0">${ic('chef')} الشيف لكل قسم</div>
    ${depts.map(k => `<div class="fline"><span>${deptDot(k)} ${esc(k ? deptName(k) : 'بدون قسم')}</span>${chefSel(k, c.chefs[k])}<span></span></div>`).join('')}</div>` : ''}
  <div class="card pad"><div class="sec" style="margin-top:0">${ic('user')} معلومات الزبون</div>
    <div class="grid g2" style="gap:10px"><label class="field"><span>اسم الزبون</span><input class="inp" id="bname" value="${esc(c.name)}" autocomplete="off"></label>
    <label class="field"><span>رقم الهاتف</span><input class="inp" id="bphone" type="tel" dir="ltr" value="${esc(c.phone)}" placeholder="07XXXXXXXXX"></label></div><div id="phh" class="bkh"></div>
    <div class="grid g2" style="gap:10px"><label class="field"><span>يوم الاستلام</span><input class="inp" type="date" id="bdate" value="${c.date}" min="${todayStr()}"></label>
    <label class="field"><span>الساعة</span><input class="inp" type="time" id="btime" value="${c.time}"></label></div><div id="caph" class="bkh"></div>
    <label class="field"><span>ملاحظات عامة</span><input class="inp" id="bnote" value="${esc(c.note)}" placeholder="تغليف، توصيل…"></label>
    <div class="phb2"><div class="phh2">${needPh && !phs.length ? '<b style="color:var(--red)">مطلوبة صورة للطباعة على الكيك</b>' : `صور من الزبون <small class="muted">(${phs.length} من ${PH_MAX} · اختياري)</small>`}</div>
      <div class="phl">${phs.map((x, i) => `<div class="pht"><img src="${x}" alt="" data-a="phv" data-i="${i}"><button class="phx" data-a="phdel" data-i="${i}">${ic('x')}</button></div>`).join('')}</div>
      ${phs.length < PH_MAX ? `<div class="row"><button class="btn s" data-a="phpick">${ic('img')} من الجهاز</button><button class="btn s" data-a="phqr">📱 من موبايل الزبون (QR)</button></div>` : '<span class="muted small">وصلت للحد</span>'}<input type="file" id="phf" accept="image/*" multiple hidden></div>
    <label class="field" style="margin-top:12px"><span>العربون المدفوع</span><input class="inp" type="number" id="bdep" inputmode="numeric" min="0" value="${esc(c.dep)}" placeholder="0"></label></div>
  <div class="card pad tot"><div><span>المجموع</span><b>${money(tot)}</b></div><div><span>العربون</span><b id="tdep">${money(dep)}</b></div><div class="rem"><span>الباقي عند الاستلام</span><b id="trem">${money(Math.max(0, tot - dep))}</b></div></div>
  </div><div class="pdbar"><div><small class="muted">المجموع</small><b>${money(tot)}</b></div><button class="btn p big" data-a="bconf" ${c.lines.length ? '' : 'disabled'}>${ic('check')} تأكيد الطلب</button></div>`);
  phHint(); capHint();
}
function readCart() { const c = S.cart; if (!$('#bname')) return; c.name = $('#bname').value; c.phone = $('#bphone').value; c.date = $('#bdate').value; c.time = $('#btime').value; c.note = $('#bnote').value; c.dep = $('#bdep').value; $$('[data-chef]').forEach(s => c.chefs[s.dataset.chef] = s.value); }
const dayCount = (dk, skip, kind) => S.corders.filter(o => o.st !== 'cancel' && kindOf(o) === (kind || 'cake') && (o.due || '').slice(0, 10) === dk && o.id !== skip).length;
const capOf = k => k === 'cake' ? +CK().cap || 0 : 0;
function capHint() { const h = $('#caph'), i = $('#bdate'); if (!h || !i) return; const k = (S.cart || {}).kind, n = dayCount(i.value, null, k), cap = capOf(k);
  h.innerHTML = cap ? (n >= cap ? `<b style="color:var(--red)">⛔ هذا اليوم ممتلئ (${n} من ${cap} طلب)</b>` : `📅 محجوز ${n} من ${cap} · باقي <b>${cap - n}</b>`) : `📅 محجوز بهذا اليوم: <b>${n}</b> طلب`; }
function cusFind(p) { const k = waNum(p); if (!k || k.length < 12) return null; return cusAll().find(c => c.k === k) || null; }
function phHint() { const h = $('#phh'), i = $('#bphone'); if (!h || !i) return; const c = cusFind(i.value); if (!c) { h.innerHTML = ''; return; }
  const nm = $('#bname'); if (nm && !nm.value.trim()) { nm.value = c.name; S.cart.name = c.name; }
  h.innerHTML = `👤 زبون سابق: <b>${esc(c.name)}</b> · ${c.n} طلب${c.debt ? ` · <b style="color:var(--red)">⚠ عليه دين ${money(c.debt)}</b>` : ''}`; }
async function confirmCart(btn) {
  readCart(); const c = S.cart;
  if (!c.lines.length) return toast('الطلب فارغ');
  if (!c.name.trim()) return toast('اكتب اسم الزبون'); if (c.phone.replace(/\D/g, '').length < 10) return toast('رقم الهاتف غير صحيح'); if (!c.date) return toast('اختار يوم الاستلام');
  const depts = [...new Set(c.lines.map(l => l.dept || ''))], miss = depts.filter(k => !c.chefs[k]);
  if (miss.length) return toast('لازم تختار الشيف لقسم: ' + miss.map(k => k ? deptName(k) : 'بدون قسم').join('، '));
  if (c.lines.some(l => (l.adds || []).some(a => a.ph)) && !(c.photos || []).length) return toast('ارفع الصورة المطلوبة للطباعة على الكيك');
  const cap = capOf(c.kind);
  if (cap && dayCount(c.date, null, c.kind) >= cap) { if (!PK(c.kind, 'overcap')) return toast(`يوم ${c.date} ممتلئ (${cap} طلب). اختار يوم ثاني أو راجع المدير`); if (!(await confirmBox(`يوم ${c.date} ممتلئ. تحجز فوق الحد؟`, 'احجز'))) return drawCart(); }
  btn.disabled = true; btn.textContent = 'جاري الحجز…';
  let no = await DB.nextNo(), off = false; if (!no) { off = true; no = Math.max(1000, ...S.corders.map(o => +o.no || 0)) + 1; }
  const phs = c.photos || [], o = { id: uid(), kind: c.kind || 'special', no, at: Date.now(), by: S.me.full_name, by_id: S.me.id, name: c.name.trim(), phone: c.phone.trim(), due: c.date + 'T' + (c.time || '12:00'), dep: +c.dep || 0, note: c.note.trim(),
    lines: c.lines, chefs: Object.fromEntries(depts.map(k => [k, c.chefs[k]])), prod: Object.fromEntries(depts.map(k => [k, 'new'])), st: 'new', ph: phs.length > 0, phn: phs.length };
  if (off) o.offNo = true;
  o.total = orderTotal(o);
  try { await saveCO(o, `${o.kind === 'cake' ? 'حجز كيك' : 'طلب خاص'} #${o.no} · ${o.name} · ${money(o.total)}${o.dep ? ' · عربون ' + money(o.dep) : ''}`); for (let i = 0; i < phs.length; i++) await DB.setPhoto(phOid(o, i), phs[i]); }
  catch (e) { btn.disabled = false; btn.textContent = 'تأكيد الطلب'; return toast('ما انحفظ الطلب: ' + e.message); }
  S.cart = null; showReceipt(o, true); if (prnCfg().auto) setTimeout(() => printO(o), 500);
}
/* الوصل بعد الحجز */
function showReceipt(o, fresh) {
  pdOpen(`<div class="ckw" style="align-items:center"><div class="pdtop" style="width:min(100%,460px)"><button class="pdback s" data-a="pdx">→</button><h2>وصل الطلب <span dir="ltr">#${o.no}</span></h2></div>
    ${fresh ? `<div class="okb">${ic('check')}<div><b>تم تأكيد الطلب</b><div>رقم الطلب <b dir="ltr">#${o.no}</b></div></div></div>` : ''}
    <div class="pvw" id="rcpv"><iframe id="rcpf" title="الوصل" scrolling="no"></iframe></div>
    <div class="row" style="justify-content:center"><button class="btn p big" data-a="oprint" data-id="${o.id}">${ic('print')} طباعة</button><button class="btn g big" data-a="opdf" data-id="${o.id}">${ic('wa')} PDF للزبون</button><button class="btn big" data-a="pdx">${fresh ? 'إنهاء' : 'إغلاق'}</button></div>
    <button class="lnk" data-a="owa" data-id="${o.id}">أو أرسل التفاصيل كرسالة نصية</button></div>`);
  setTimeout(() => fillDoc('#rcpv', '#rcpf', o), 0);
}
/* عارض الصور: list = [{img, name}] */
const phOid = (o, i) => i ? o.id + '_' + i : o.id;
function viewImg(src, cap, list, i) {
  if (!src && !(list || []).length) return; S.lb = { list: list && list.length ? list : [{ img: src, name: cap }], i: list && list.length ? (i || 0) : 0 };
  let b = $('#lb'); if (!b) { b = document.createElement('div'); b.id = 'lb'; document.body.appendChild(b); } b.hidden = false; lbDraw();
}
function lbDraw() { const b = $('#lb'), L = S.lb.list, x = L[S.lb.i] || {}; b.innerHTML = `<button class="lbx" data-a="lbx">${ic('x')}</button>${L.length > 1 ? `<button class="arr l" data-a="lbp">‹</button><button class="arr r" data-a="lbn">›</button>` : ''}
  <img src="${x.img || ''}" alt="" data-a="lbx"><div class="lbc">${esc(x.name || '')}${L.length > 1 ? ` <small>${S.lb.i + 1} / ${L.length}</small>` : ''}</div>`; }
async function orderPhotos(o) { const n = o.phn || (o.ph ? 1 : 0), R0 = []; if (o.demo || o.demoPh) return o.demoPh ? [o.demoPh] : [];
  for (let i = 0; i < n; i++) { try { const s = await DB.photo(phOid(o, i)); if (s) R0.push(s); } catch (e) {} } return R0; }

/* ---------- صور الزبون عن طريق QR (موبايل الزبون يرفع، توصل هنا) ---------- */
let QS = null;
function qtok() { const a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789', u = new Uint32Array(24); crypto.getRandomValues(u); let r = ''; for (let i = 0; i < 24; i++) r += a[u[i] % a.length]; return r; }
const upURL = () => /^https?:/.test(location.protocol) && !/localhost|127\.0\.0\.1/.test(location.host) ? location.origin + '/up.html' : 'https://' + (window.FB_CONFIG ? FB_CONFIG.projectId + '.web.app' : 'sanabelaltahoona-3bec5.web.app') + '/up.html';
async function qrOpen() {
  const left = PH_MAX - (S.cart.photos || []).length; if (left <= 0) return toast('وصلت للحد');
  if (MODE !== 'cloud') return toast('هذي الميزة تشتغل بس ويه الإنترنت والحساب الحقيقي'); if (!navigator.onLine) return toast('ماكو إنترنت هسه، ارفع الصورة من الجهاز');
  const k = qtok(), exp = Date.now() + 10 * 60000; QS = { k, exp, busy: false, t: null };
  modal(`<div class="qrb"><h2>📱 صورة من موبايل الزبون</h2><p class="muted">جاري تجهيز الكود…</p></div>`);
  try { await DB.upsert('cake_qr', { id: k, st: 'wait', exp, max: left, n: 0, at: Date.now(), by: S.me.full_name }); }
  catch (e) { QS = null; closeModal(); return toast('ما گدر يسوي الكود: ' + e.message); }
  if (!QS || QS.k !== k) return; const url = upURL() + '?k=' + k;
  const qb = $('.qrb'); if (!qb) return qrClose(true); qb.innerHTML = `<h2>📱 صورة من موبايل الزبون</h2><div class="qrc">${QR.svg(url, 250)}</div>
    <ol class="qrs"><li>الزبون يفتح <b>الكاميرا</b> بموبايله ويوجّهها على الكود</li><li>يضغط الرابط ويختار ${left > 1 ? 'لحد ' + left + ' صور' : 'الصورة'}</li><li>الصور توصل هنا لوحدها</li></ol>
    <div class="qrw" id="qrw"><span class="spin sm"></span> بانتظار صور الزبون… <b id="qrt"></b></div><div class="mact"><button class="btn" data-a="qrx">إلغاء</button></div>`;
  qrTick(); QS.t = setInterval(qrTick, 2000);
}
async function qrTick() {
  if (!QS) return; if (!$('#qrw')) return qrClose(true); const s = Math.max(0, Math.round((QS.exp - Date.now()) / 1000)), t = $('#qrt'); if (t) t.textContent = Math.floor(s / 60) + ':' + pad2(s % 60);
  if (s <= 0) { clearInterval(QS.t); $('#qrw').innerHTML = '<b style="color:var(--red)">انتهت صلاحية الكود</b> <button class="btn s p" data-a="qrnew">كود جديد</button>'; return; }
  if (QS.busy) return; QS.busy = true; const k = QS.k;
  try { const x = await DB.get('cake_qr', k); if (!x || x.st !== 'done') { if (QS) QS.busy = false; return; }
    $('#qrw').innerHTML = '<span class="spin sm"></span> وصلت! جاري التحميل…'; const n = Math.min(PH_MAX, +x.n || 1), got = [];
    for (let i = 0; i < n; i++) { try { const p = await DB.get('cake_qrp', k + '_' + i); if (p && p.d) got.push(p.d); } catch (e) {} }
    if (!S.cart) return qrClose(true); S.cart.photos = (S.cart.photos || []).concat(got).slice(0, PH_MAX); qrClose(true); closeModal(); drawCart(); toast(got.length > 1 ? 'وصلت ' + got.length + ' صور ✓' : 'وصلت الصورة ✓');
  } catch (e) { if (QS) QS.busy = false; }
}
function qrClose(clean) { if (!QS) return; clearInterval(QS.t); if (clean && MODE === 'cloud') { const k = QS.k; for (let i = 0; i < PH_MAX; i++) DB.remove('cake_qrp', k + '_' + i).catch(() => {}); DB.remove('cake_qr', k).catch(() => {}); } QS = null; }

/* ---------- رسائل واتساب ---------- */
const linesTxt = o => (o.lines || []).map(l => `• ${l.name} ${qtyTxt(l)}${lineDesc(l) ? ' (' + lineDesc(l) + ')' : ''}`).join('\n');
function waConfirm(o) { const d = dueD(o); openURL('https://wa.me/' + waNum(o.phone) + '?text=' + encodeURIComponent(`مرحباً ${o.name} 🌾\nتم تأكيد طلبك لدى ${SHOP}\n\nرقم الطلب: #${o.no}\n${linesTxt(o)}\n\nموعد الاستلام: ${fD(d)} - ${fT(d)}\nالمجموع: ${money(o.total)}\nالعربون: ${money(o.dep)}\nالباقي: ${money(remOf(o))}\n\nشكراً لاختياركم 🎂`)); }
function waReady(o) { const r = remOf(o); openURL('https://wa.me/' + waNum(o.phone) + '?text=' + encodeURIComponent(`مرحباً ${o.name} 🌾\nطلبك رقم #${o.no} جاهز للاستلام من ${SHOP} 🎂${r ? '\nالمبلغ المتبقي: ' + money(r) : ''}\nبانتظارك!`)); }
function waRemind(o) { const d = dueD(o), r = remOf(o); openURL('https://wa.me/' + waNum(o.phone) + '?text=' + encodeURIComponent(`مرحباً ${o.name} 🌾\nنذكّرك بموعد استلام طلبك رقم #${o.no} من ${SHOP}\n📅 ${fD(d)} - ${fT(d)}${r ? '\nالمبلغ المتبقي: ' + money(r) : ''}\nبانتظارك 🎂`)); }

/* ---------- طلبات الزبائن ---------- */
function coFilter(kind) {
  const t = todayStr(), tm = addDays(t, 1), q = S.cq.trim(), f = S.cf; kind = kind || pgKind();
  return S.corders.filter(o => { if (kindOf(o) !== kind) return false; const dk = (o.due || '').slice(0, 10), fin = o.st === 'done' || o.st === 'cancel';
    if (f === 'act' && fin) return false; if (f === 'today' && (dk !== t || fin)) return false; if (f === 'tom' && (dk !== tm || fin)) return false;
    if (f === 'ready' && o.st !== 'ready') return false; if (f === 'done' && o.st !== 'done') return false; if (f === 'cancel' && o.st !== 'cancel') return false; if (f === 'debt' && !(o.st === 'done' && o.debt > 0)) return false;
    if (q && (o.name + ' ' + o.phone + ' ' + o.no + ' ' + (o.lines || []).map(l => l.name).join(' ')).indexOf(q) < 0) return false; return true; })
    .sort((a, b) => (f === 'done' || f === 'all') ? b.at - a.at : (a.due < b.due ? -1 : a.due > b.due ? 1 : 0));
}
function finLine(o) {
  if (o.st === 'done') return `المجموع <b>${fmt(o.total)}</b>${o.disc ? ` · خصم <b>${fmt(o.disc)}</b>` : ''} · ${o.debt ? `<b style="color:var(--red)">دين ${fmt(o.debt)}</b>` : '<b style="color:var(--green)">مدفوع ✓</b>'}`;
  return `المجموع <b>${fmt(o.total)}</b> · عربون ${fmt(o.dep)} · الباقي <b>${fmt(remOf(o))}</b>`;
}
function coCard(o) {
  const k = kindOf(o), d = dueD(o), late = !['done', 'cancel'].includes(o.st) && d < new Date(), df = d - Date.now();
  return `<div class="card co st-${o.st}" data-co="${o.id}"><div class="coh"><b dir="ltr">#${o.no}</b><span class="pill p-${o.st}">${CST[o.st]}</span><span class="due ${late ? 'late' : ''}">${late ? '⚠ متأخر · ' : ''}${fD(d)} · ${fT(d)}</span></div>
    <div class="cob"><div class="grow"><div><b>${esc(o.name)}</b> · <span dir="ltr">${esc(o.phone)}</span></div>
      ${(o.lines || []).map(l => `<div class="small">• <b>${esc(l.name)}</b> ${esc(qtyTxt(l))}${lineDesc(l) ? ` <span class="muted">${esc(lineDesc(l))}</span>` : ''}</div>`).join('')}
      ${o.note ? `<div class="small muted">📝 ${esc(o.note)}</div>` : ''}
      <div class="dsts">${oDepts(o).map(k => { const s = (o.prod || {})[k] || 'new'; return `<span class="dst p-${s === 'sent' ? 'ready' : s}">${deptDot(k)}${esc(deptName(k))} · ${esc(userOf((o.chefs || {})[k])?.full_name || '—')} · ${{ new: 'جديد', prep: 'بلشت', ready: 'جهزت', sent: 'سلّمها' }[s] || CST[s]}</span>`; }).join('')}</div>
      <div class="muted small">سجّله: ${esc(o.by || '')}</div></div>${o.ph ? `<span class="ophw"><img class="oph" data-ph="${o.id}" data-a="ophv" data-id="${o.id}" alt="" src="data:image/gif;base64,R0lGODlhAQABAAAAACw=">${(o.phn || 1) > 1 ? `<i>${o.phn}</i>` : ''}</span>` : (o.lines || []).find(l => l.iid && itemOf(l.iid)?.img) ? `<img class="oph" src="${itemOf(o.lines.find(l => l.iid && itemOf(l.iid)?.img).iid).img}" alt="">` : ''}</div>
    <div class="cof"><span class="small">${finLine(o)}</span><div class="oacts" style="margin:0">
      ${o.st !== 'done' && o.st !== 'cancel' && PK(k, 'deliver') ? `<button class="btn s p" data-a="odel" data-id="${o.id}">${ic('check')} تسليم</button>` : ''}
      ${o.st === 'done' && o.debt > 0 && PK(k, 'deliver') ? `<button class="btn s p" data-a="opay" data-id="${o.id}">تسديد الدين</button>` : ''}
      <button class="btn s g" data-a="${o.st === 'ready' ? 'owr' : 'opdf'}" data-id="${o.id}" title="واتساب">${ic('wa')}</button>
      ${(o.st === 'new' || o.st === 'prep') && df > 0 && df < 48 * 36e5 ? `<button class="btn s" data-a="owrem" data-id="${o.id}">⏰ تذكير</button>` : ''}
      <button class="btn s" data-a="orc" data-id="${o.id}">الوصل</button>
      ${PK(k, 'cancel') && !['done', 'cancel'].includes(o.st) ? `<button class="btn s" data-a="ocan" data-id="${o.id}">إلغاء</button>` : ''}
      ${PK(k, 'del') ? `<button class="btn s x" data-a="orm" data-id="${o.id}">${ic('trash')}</button>` : ''}</div></div></div>`;
}
function loadPh() { $$('img[data-ph]').forEach(im => { if (im.dataset.l) return; im.dataset.l = 1; DB.photo(im.dataset.ph).then(s => { if (s) im.src = s; }); }); }
function coPage(kind) {
  const ck = kind === 'cake', all = S.corders.filter(o => kindOf(o) === kind), act0 = all.filter(o => !['done', 'cancel'].includes(o.st)), tk = todayStr();
  const F = [['act', 'النشطة'], ['today', 'اليوم'], ['tom', 'باجر'], ['ready', 'الجاهزة'], ['done', 'المسلّمة'], ['debt', 'الديون'], ['cancel', 'الملغية'], ['all', 'الكل']];
  const L = coFilter(kind);
  $('#view').innerHTML = `<div class="grid g3"><div class="card kpi"><span class="lbl">طلبات نشطة</span><span class="val">${act0.length}</span></div><div class="card kpi blue"><span class="lbl">تسليم اليوم</span><span class="val">${act0.filter(o => (o.due || '').slice(0, 10) === tk).length}</span></div><div class="card kpi green"><span class="lbl">جاهزة للاستلام</span><span class="val">${all.filter(o => o.st === 'ready').length}</span></div></div>
  <div class="toolbar" style="margin-top:12px"><div class="filters">${F.map(([k, l]) => `<button data-cf="${k}" class="${k === S.cf ? 'on' : ''}">${l}</button>`).join('')}</div><span class="sp"></span>${PK(kind, 'book') ? `<button class="btn p" data-a="newCO" data-k="${kind}">${ic('plus')} ${ck ? 'حجز كيك جديد' : 'طلب خاص جديد'}</button>` : ''}</div>
  <input class="inp" id="cq" type="search" placeholder="بحث بالاسم أو الهاتف أو رقم الطلب أو المنتج" value="${esc(S.cq)}" style="margin-bottom:12px">
  <div class="cols2" id="colist">${L.length ? L.map(coCard).join('') : empty(ck ? 'cake' : 'bag', all.length ? 'ماكو طلبات بهالفلتر' : ck ? 'ماكو طلبات كيك بعد' : 'ماكو طلبات خاصة بعد. مثلاً: معمول أو معجنات لعزيمة')}</div>`;
  loadPh();
}
R.k_ord = () => coPage('cake');
R.corders = () => coPage('special');
/* التسليم: استحصال الباقي، والناقص دين أو خصم */
function collectDlg(o) {
  const rem = remOf(o);
  modal(`<h2>تسليم الطلب <span dir="ltr">#${o.no}</span><span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <p class="muted" style="margin-top:-6px">${esc(o.name)}${o.st !== 'ready' ? ' · <b style="color:var(--red)">الطلب مو جاهز بعد بالمطبخ</b>' : ''}</p>
    <div class="tot"><div><span>المجموع</span><b>${money(o.total)}</b></div><div><span>العربون</span><b>${money(o.dep)}</b></div><div class="rem"><span>المتبقي على الزبون</span><b>${money(rem)}</b></div></div>
    <label class="field" style="margin-top:12px"><span>المبلغ المستلم هسه</span><input class="inp big" type="number" id="colin" inputmode="numeric" min="0" value="${rem}" style="text-align:center;font-weight:700"></label>
    <div id="coldiff" class="cdf"><b style="color:var(--green)">✓ المبلغ كامل</b></div>
    <div id="colk" class="colk" hidden><label><input type="radio" name="colk" value="debt" checked> يبقى دين على الزبون</label><label><input type="radio" name="colk" value="disc"> خصم للزبون</label></div>
    <div class="mact"><button class="btn p" data-a="colok" data-id="${o.id}">${ic('check')} تأكيد التسليم</button><button class="btn" data-close>إلغاء</button></div>`);
  S._colRem = rem;
}
function colDiff() { const i = $('#colin'), d = $('#coldiff'), k = $('#colk'); if (!i) return; const v = +i.value || 0, rem = S._colRem;
  if (i.value === '') { d.innerHTML = ''; k.hidden = true; return; }
  if (v < rem) { d.innerHTML = `<b style="color:var(--red)">ناقص ${fmt(rem - v)} ${cur()}</b>`; k.hidden = false; } else if (v > rem) { d.innerHTML = `<b>ارجع للزبون ${fmt(v - rem)} ${cur()}</b>`; k.hidden = true; } else { d.innerHTML = '<b style="color:var(--green)">✓ المبلغ كامل</b>'; k.hidden = true; } }
function payDlg(o) {
  modal(`<h2>تسديد دين الطلب <span dir="ltr">#${o.no}</span><span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <p class="muted">${esc(o.name)} · <span dir="ltr">${esc(o.phone)}</span></p><div class="tot"><div class="rem"><span>الدين الباقي</span><b>${money(o.debt)}</b></div></div>
    <label class="field" style="margin-top:12px"><span>المبلغ المستلم</span><input class="inp" type="number" id="payin" value="${o.debt}"></label>
    <div class="mact"><button class="btn p" data-a="payok" data-id="${o.id}">تسجيل الدفعة</button><button class="btn" data-close>إلغاء</button></div>`);
}

/* ---------- التقويم ---------- */
R.k_cal = function () {
  const t = new Date(); if (!S.calM) S.calM = new Date(t.getFullYear(), t.getMonth(), 1);
  const y = S.calM.getFullYear(), m = S.calM.getMonth(), nd = new Date(y, m + 1, 0).getDate(), st = (new Date(y, m, 1).getDay() + 1) % 7, cap = +CK().cap || 0, tk = todayStr();
  const C = {}; S.corders.forEach(o => { if (o.st === 'cancel' || kindOf(o) !== 'cake') return; const k = (o.due || '').slice(0, 10); C[k] = (C[k] || 0) + 1; });
  let mn; try { mn = S.calM.toLocaleDateString('ar-IQ-u-nu-latn', { month: 'long', year: 'numeric' }); } catch (e) { mn = y + '-' + (m + 1); }
  let h = `<div class="card pad"><div class="calh"><button class="btn s" data-a="calp">›</button><b>${mn}</b><button class="btn s" data-a="caln">‹</button><button class="btn s" data-a="calt">اليوم</button></div><div class="calg">${['سبت', 'أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة'].map(d => `<span class="cwd">${d}</span>`).join('')}`;
  for (let i = 0; i < st; i++) h += '<span></span>';
  for (let d = 1; d <= nd; d++) { const k = y + '-' + pad2(m + 1) + '-' + pad2(d), n = C[k] || 0, lv = !n ? '' : cap ? (n >= cap ? 'full' : n >= cap * .7 ? 'hi' : 'lo') : (n >= 6 ? 'hi' : 'lo');
    h += `<button class="cday ${k === tk ? 'tod' : ''} ${k === S.calD ? 'sel' : ''} ${lv} ${k < tk ? 'past' : ''}" data-cald="${k}"><i>${d}</i>${n ? `<b>${n}</b><small>${cap ? 'من ' + cap : 'طلب'}</small>` : ''}</button>`; }
  h += '</div></div>';
  if (S.calD) { const L = S.corders.filter(o => kindOf(o) === 'cake' && (o.due || '').slice(0, 10) === S.calD).sort((a, b) => a.due < b.due ? -1 : 1);
    h += `<div class="sec">طلبات ${fD(new Date(S.calD + 'T12:00'))} <span class="muted small">(${L.filter(o => o.st !== 'cancel').length})</span></div><div class="cols2">${L.length ? L.map(coCard).join('') : empty('cal', 'ماكو طلبات بهذا اليوم')}</div>`; }
  if (P('c_cat_edit')) h += `<div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">الحد الأقصى لطلبات الكيك باليوم <span class="muted small">0 = بدون حد</span></div><div class="row"><input class="inp" type="number" id="capin" min="0" value="${cap}" style="max-width:140px"><span class="muted">طلب باليوم</span></div></div>`;
  $('#view').innerHTML = h; loadPh();
};

/* ---------- الصندوق اليومي ---------- */
function cashData(dk, u, kind) {
  const R0 = { dep: 0, depN: 0, coll: 0, collN: 0, pay: 0, payN: 0, debt: 0, disc: 0, can: 0, canDep: 0, by: {} }, B = n => R0.by[n] || (R0.by[n] = { dep: 0, coll: 0, pay: 0 });
  S.corders.forEach(o => { if (kindOf(o) !== kind) return;
    if (o.at && fmtD(new Date(o.at)) === dk && (!u || o.by === u)) { R0.dep += +o.dep || 0; R0.depN++; B(o.by || '—').dep += +o.dep || 0; if (o.st === 'cancel') { R0.can++; R0.canDep += +o.dep || 0; } }
    if (o.st === 'done' && o.doneAt && fmtD(new Date(o.doneAt)) === dk && (!u || o.collBy === u)) { const c = o.coll != null ? +o.coll : remOf(o); R0.coll += c; R0.collN++; B(o.collBy || '—').coll += c; R0.debt += +o.debt || 0; R0.disc += +o.disc || 0; }
    (o.pays || []).forEach(p => { if (fmtD(new Date(p.at)) === dk && (!u || p.by === u)) { R0.pay += +p.a || 0; R0.payN++; B(p.by || '—').pay += +p.a || 0; } });
  });
  R0.tot = R0.dep + R0.coll + R0.pay; return R0;
}
const cashCtx = () => { const kind = pgKind(), all = PK(kind, 'cash_all'), dk = S.cashD || todayStr(), u = all ? (S.cashU || '') : S.me.full_name; return { kind, all, dk, u, R0: cashData(dk, u, kind) }; };
function cashPage() {
  const { kind, all, dk, u, R0 } = cashCtx(), us = {};
  S.corders.forEach(o => { if (kindOf(o) !== kind) return; if (o.by) us[o.by] = 1; if (o.collBy) us[o.collBy] = 1; });
  $('#view').innerHTML = `<div class="toolbar"><input class="inp" type="date" id="cashd" value="${dk}" max="${todayStr()}" style="width:auto">
    ${all ? `<select class="inp" id="cashu" style="width:auto"><option value="">كل الموظفين</option>${Object.keys(us).map(n => `<option ${n === u ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>` : `<span class="muted">صندوق: <b>${esc(u)}</b></span>`}</div>
  <div class="grid g4"><div class="card kpi"><span class="lbl">المفروض بالصندوق</span><span class="val">${fmt(R0.tot)} <small>${cur()}</small></span></div>
    <div class="card kpi blue"><span class="lbl">عربون الحجوزات</span><span class="val">${fmt(R0.dep)}</span><span class="sub">${R0.depN} حجز</span></div>
    <div class="card kpi green"><span class="lbl">المستلم عند التسليم</span><span class="val">${fmt(R0.coll)}</span><span class="sub">${R0.collN} طلب</span></div>
    <div class="card kpi"><span class="lbl">تسديد ديون</span><span class="val">${fmt(R0.pay)}</span><span class="sub">${R0.payN} دفعة</span></div></div>
  <div class="card pad" style="margin-top:14px"><div class="tot"><div><span>ديون جديدة (ما انستلمت)</span><b>${money(R0.debt)}</b></div><div><span>خصومات</span><b>${money(R0.disc)}</b></div><div><span>طلبات انحجزت وانلغت بنفس اليوم</span><b>${R0.can}${R0.canDep ? ' · عربونها ' + money(R0.canDep) : ''}</b></div>
    ${Object.keys(R0.by).length > 1 && !u ? Object.entries(R0.by).map(([n, x]) => `<div><span>${esc(n)}</span><b>${money(x.dep + x.coll + x.pay)}</b></div>`).join('') : ''}</div></div>
  <div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">إغلاق الصندوق</div>
    <label class="field"><span>المبلغ الفعلي بالصندوق</span><input class="inp" type="number" id="cashin" placeholder="${R0.tot}"></label><div id="cashdf" class="cdf"></div>
    <label class="field"><span>ملاحظة (اختياري)</span><input class="inp" id="cashn" placeholder="مثلاً: سحبنا 10000 مصاريف"></label>
    <div class="row"><button class="btn p" data-a="cashsave">حفظ الإغلاق</button><button class="btn" data-a="cashprn">${ic('print')} طباعة</button></div></div>`;
}
R.k_cash = cashPage; R.cash = cashPage;
function cashDoc() {
  const { kind, dk, u, R0 } = cashCtx(), i = $('#cashin'), a = i && i.value !== '' ? +i.value : null, n = $('#cashn');
  const r = (x, y) => `<tr><td>${x}</td><td>${y}</td></tr>`;
  return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>إغلاق الصندوق</title><style>@page{size:80mm auto;margin:3mm}body{font-family:Tahoma,Arial,sans-serif;margin:0;padding:6px;color:#000;font-size:13px;max-width:76mm}h2{text-align:center;margin:4px 0}p{text-align:center;margin:2px 0}table{width:100%;border-collapse:collapse;margin-top:8px}td{padding:4px 2px;border-bottom:1px dashed #999}td:last-child{text-align:left;font-weight:bold}</style></head><body>
  <h2>${SHOP}</h2><p>إغلاق ${kind === 'cake' ? 'صندوق الكيك' : 'صندوق الطلبات الخاصة'} · ${dk}</p><p>${u ? 'الموظف: ' + esc(u) : 'كل الموظفين'} · طبعه: ${esc(S.me.full_name)}</p><table>${r('عربون الحجوزات (' + R0.depN + ')', fmt(R0.dep))}${r('المستلم عند التسليم (' + R0.collN + ')', fmt(R0.coll))}${r('تسديد ديون (' + R0.payN + ')', fmt(R0.pay))}${r('<b>المفروض بالصندوق</b>', fmt(R0.tot))}
  ${a != null ? r('الفعلي', fmt(a)) + r('الفرق', (a - R0.tot > 0 ? '+' : '') + fmt(a - R0.tot)) : ''}${r('ديون جديدة', fmt(R0.debt))}${r('خصومات', fmt(R0.disc))}</table>${n && n.value ? `<p style="margin-top:8px">ملاحظة: ${esc(n.value)}</p>` : ''}<p style="margin-top:14px">التوقيع: ..................</p></body></html>`;
}

/* ---------- الزبائن ---------- */
function cusAll() {
  const M = {};
  S.corders.forEach(o => { const k = waNum(o.phone); if (!k) return; const c = M[k] || (M[k] = { k, phone: o.phone, name: o.name, n: 0, spent: 0, debt: 0, last: 0, first: Infinity, orders: [] });
    c.orders.push(o); if ((o.at || 0) >= c.last) { c.last = o.at || 0; c.name = o.name; c.phone = o.phone; } c.first = Math.min(c.first, o.at || 0);
    if (o.st !== 'cancel') { c.n++; c.spent += netTotal(o); } if (o.st === 'done' && o.debt) c.debt += o.debt; });
  return Object.values(M);
}
function occList(days) {
  const now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()), R0 = [], seen = {}; let sent = {}; try { sent = JSON.parse(localStorage.getItem('san_occ') || '{}'); } catch (e) {}
  S.corders.forEach(o => { if (o.st === 'cancel' || !o.phone) return; const d = dueD(o); if (isNaN(d) || t0 - d < 300 * 864e5) return;
    const an = new Date(t0.getFullYear(), d.getMonth(), d.getDate()); if (an < t0) an.setFullYear(an.getFullYear() + 1); const left = Math.round((an - t0) / 864e5); if (left > days) return;
    const k = waNum(o.phone) + '_' + (d.getMonth() + 1) + '-' + d.getDate(); if (seen[k]) return; seen[k] = 1; R0.push({ o, left, an, k, sent: sent[k + '_' + an.getFullYear()] }); });
  return R0.sort((a, b) => a.left - b.left);
}
R.k_cus = function () {
  let L = cusAll(); const all = L.length, rep = L.filter(c => c.n > 1).length, q = (S.cusQ || '').trim(), oc = occList(14);
  if (q) L = L.filter(c => (c.name + ' ' + c.phone).includes(q)); if (S.cusS === 'debt') L = L.filter(c => c.debt > 0);
  L.sort((a, b) => S.cusS === 'n' ? b.n - a.n : S.cusS === 'spent' ? b.spent - a.spent : S.cusS === 'debt' ? b.debt - a.debt : b.last - a.last);
  $('#view').innerHTML = `<div class="grid g3"><div class="card kpi"><span class="lbl">عدد الزبائن</span><span class="val">${all}</span></div><div class="card kpi green"><span class="lbl">رجعوا يطلبون</span><span class="val">${rep}</span><span class="sub">${all ? Math.round(rep / all * 100) : 0}%</span></div><div class="card kpi blue"><span class="lbl">مناسبات خلال أسبوعين</span><span class="val">${oc.length}</span></div></div>
  <div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">🎉 مناسبات قادمة <span class="muted small">زبائن طلبوا بنفس هالأيام السنة الماضية</span></div>
    ${oc.length ? oc.map((x, i) => `<div class="lrow2"><div class="av">${esc(initials(x.o.name))}</div><div class="grow"><b>${esc(x.o.name)}</b> <span class="muted small" dir="ltr">${esc(x.o.phone)}</span><div class="muted small">${esc((x.o.lines || []).map(l => l.name).join('، '))} · ${(x.o.due || '').slice(0, 10)}</div></div><span class="chip">${x.left === 0 ? 'اليوم' : x.left === 1 ? 'باجر' : 'بعد ' + x.left + ' يوم'}</span><button class="btn s g" data-a="occwa" data-i="${i}">${ic('wa')}${x.sent ? ' انرسلت ✓' : ' تذكير'}</button></div>`).join('') : '<p class="muted">ماكو مناسبات خلال الأسبوعين الجايات.</p>'}</div>
  <div class="toolbar" style="margin-top:14px">${seg('data-cuss', [['last', 'الأحدث'], ['n', 'الأكثر طلبات'], ['spent', 'الأكثر شراء'], ['debt', 'عليهم دين']], S.cusS || 'last')}<input class="inp" id="cusq" type="search" placeholder="بحث بالاسم أو الهاتف" value="${esc(q)}" style="max-width:280px"></div>
  <div class="card">${L.length ? L.slice(0, 300).map(c => `<button class="lrow2 btnrow" data-cusv="${c.k}"><div class="av">${esc(initials(c.name))}</div><div class="grow"><b>${esc(c.name)}</b><div class="muted small" dir="ltr" style="text-align:right">${esc(c.phone)}</div></div><span class="cn"><b>${c.n}</b><small>طلب</small></span><span class="cn"><b>${fmt(c.spent)}</b><small>${cur()}</small></span>${c.debt ? `<span class="chip red">دين ${fmt(c.debt)}</span>` : ''}</button>`).join('') : empty('users', 'ماكو زبائن بعد')}</div>`;
};
function cusView(k) {
  const c = cusAll().find(x => x.k === k); if (!c) return;
  modal(`<h2>${esc(c.name)}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2><p class="muted" dir="ltr" style="text-align:right;margin-top:-8px">${esc(c.phone)}</p>
    <div class="tot"><div><span>عدد الطلبات</span><b>${c.n}</b></div><div><span>مجموع الشراء</span><b>${money(c.spent)}</b></div>${c.debt ? `<div class="rem"><span>دين باقي</span><b style="color:var(--red)">${money(c.debt)}</b></div>` : ''}<div><span>زبون من</span><b>${fmtD(new Date(c.first))}</b></div></div>
    <div class="card" style="margin:12px 0;max-height:40vh;overflow:auto">${c.orders.sort((a, b) => b.at - a.at).map(o => `<button class="lrow2 btnrow" data-a="cuso" data-no="${o.no}"><b dir="ltr">#${o.no}</b><div class="grow">${esc((o.lines || []).map(l => l.name).join('، '))}<div class="muted small">${(o.due || '').slice(0, 10)}</div></div><span>${fmt(o.total)}</span><span class="pill p-${o.st}">${CST[o.st]}</span></button>`).join('')}</div>
    <a class="btn g w" href="https://wa.me/${waNum(c.phone)}" target="_blank" rel="noopener">${ic('wa')} مراسلة على واتساب</a>`);
}

/* ---------- الأحداث ---------- */
H.click.push(async (t, ds, id) => {
  const a = ds.a, o = ds.id ? findCO(ds.id) : null;
  if (ds.dcat !== undefined) { S.dcat = ds.dcat; return render(), true; }
  if (ds.ditem) { closeModal(); openItem(ds.ditem); return true; }
  if (ds.cf) { S.cf = ds.cf; return render(), true; }
  if (ds.cald) { S.calD = S.calD === ds.cald ? '' : ds.cald; return render(), true; }
  if (ds.cuss) { S.cusS = ds.cuss; return render(), true; }
  if (ds.cusv) { cusView(ds.cusv); return true; }
  if (!a) return;
  if (a === 'newCO') { S.cart = newCart(ds.k || pgKind()); drawCart(); return true; }
  if (a === 'lbx') { const b = $('#lb'); if (b) { b.hidden = true; b.innerHTML = ''; } return true; }
  if (a === 'lbp' || a === 'lbn') { const n = S.lb.list.length; S.lb.i = (S.lb.i + (a === 'lbn' ? 1 : -1) + n) % n; lbDraw(); return true; }
  if (a === 'qrx') { qrClose(true); closeModal(); return true; }
  if (a === 'qrnew') { qrClose(true); closeModal(); qrOpen(); return true; }
  if (a === 'phqr') { readCart(); qrOpen(); return true; }
  if (a === 'pdx') { if (S.pdx && S.cart) { S.pdx = null; drawCart(); } else { pdClose(); S.cart = null; render(); } return true; }
  if (a === 'zoom') { const it = itemOf(S.pdx.iid); viewImg(it.img, it.name); return true; }
  if (S.pdx) {
    const d = S.pdx;
    if (a === 'qm') { if (d.qty > 1) d.qty--; return drawItem(), true; } if (a === 'qp') { d.qty++; return drawItem(), true; }
    if (a === 'psz') { d.size = +ds.i; return drawItem(), true; }
    if (a === 'pfill') { d.fill = d.fill === ds.id && !CK().fillReq ? null : ds.id; return drawItem(), true; }
    if (a === 'pad') { if (d.ad[ds.id]) delete d.ad[ds.id]; else d.ad[ds.id] = 1; return drawItem(), true; }
    if (a === 'adp') { d.ad[ds.id] = Math.min(99, (+d.ad[ds.id] || 0) + 1); return drawItem(), true; }
    if (a === 'adm') { const n = (+d.ad[ds.id] || 0) - 1; if (n > 0) d.ad[ds.id] = n; else delete d.ad[ds.id]; return drawItem(), true; }
    if (a === 'padd') {
      const it = itemOf(d.iid); if ((it.sizes || []).length && d.size < 0) return toast('اختار الحجم أول'), true;
      if (CK().fills.length && CK().fillReq && !d.fill) return toast('اختار الحشوة أول'), true;
      const line = itemDraftLine(); S.pdx = null; S.cart = S.cart || newCart('cake'); S.cart.lines.push(line);
      if (!S.cart.chefs[line.dept]) { const L = chefsOf(line.dept); if (L.length === 1) S.cart.chefs[line.dept] = L[0].id; }
      drawCart(); toast('انضافت للطلب'); return true;
    }
  }
  if (a === 'addCake') { readCart(); pickDesign(); return true; }
  if (a === 'addProd') { readCart(); openProducts(); return true; }
  if (a === 'pqAdd') { $$('[data-pq]').forEach(i => { const q = num(i.value); if (!q) return; const it = itemOf(i.dataset.pq);
      const ex = S.cart.lines.find(l => l.iid === it.id && !l.size); if (ex) ex.qty = r3(ex.qty + q); else S.cart.lines.push({ id: uid(), iid: it.id, name: it.name, dept: it.dept || '', qty: q, unit: it.unit, price: +it.price || 0 });
      if (!S.cart.chefs[it.dept || '']) { const L = chefsOf(it.dept); if (L.length === 1) S.cart.chefs[it.dept] = L[0].id; } });
    closeModal(); drawCart(); return true; }
  if (a === 'cdel') { readCart(); S.cart.lines.splice(+ds.i, 1); drawCart(); return true; }
  if (a === 'phpick') { readCart(); $('#phf').click(); return true; }
  if (a === 'phdel') { readCart(); S.cart.photos.splice(+ds.i, 1); drawCart(); return true; }
  if (a === 'phv') { viewImg(null, '', S.cart.photos.map((x, i) => ({ img: x, name: 'صورة الزبون ' + (i + 1) })), +ds.i); return true; }
  if (a === 'bconf') { await confirmCart(t); return true; }
  if (a === 'oprint' && o) { printO(o); return true; } if (a === 'opdf' && o) { sendPDF(o); return true; } if (a === 'owa' && o) { waConfirm(o); return true; }
  if (a === 'owr' && o) { waReady(o); return true; } if (a === 'owrem' && o) { waRemind(o); return true; }
  if (a === 'orc' && o) { showReceipt(o, false); return true; }
  if (a === 'ophv' && o) { orderPhotos(o).then(L => L.length ? viewImg(null, '', L.map((x, i) => ({ img: x, name: `صورة الزبون #${o.no}` + (L.length > 1 ? ' (' + (i + 1) + ')' : '') })), 0) : toast('ما لكيت الصورة')); return true; }
  if (a === 'odel' && o) { collectDlg(o); return true; }
  if (a === 'colok' && o) {
    const raw = $('#colin').value; if (raw === '') return toast('اكتب المبلغ المستلم'), true;
    const rem = remOf(o), val = Math.max(0, +raw || 0), k = (document.querySelector('input[name=colk]:checked') || {}).value || 'debt';
    o.coll = Math.min(val, rem); o.debt = 0; o.disc = 0; if (val < rem) { if (k === 'disc') o.disc = rem - val; else o.debt = rem - val; }
    o.st = 'done'; o.doneAt = Date.now(); o.collBy = S.me.full_name; t.disabled = true;
    await saveCO(o, `تسليم ${kindOf(o) === 'cake' ? 'كيك' : 'طلب'} #${o.no} · ${o.name} · استلم ${money(o.coll)}${o.debt ? ' · دين ' + money(o.debt) : ''}${o.disc ? ' · خصم ' + money(o.disc) : ''}`);
    closeModal(); render(); toast(o.debt ? 'تم التسليم · باقي دين ' + fmt(o.debt) : val > rem ? 'تم التسليم ✓ ارجع للزبون ' + fmt(val - rem) : 'تم التسليم والاستحصال ✓'); return true;
  }
  if (a === 'opay' && o) { payDlg(o); return true; }
  if (a === 'payok' && o) { const v = Math.min(o.debt, Math.max(0, +$('#payin').value || 0)); if (!v) return toast('اكتب مبلغ أكبر من صفر'), true;
    o.debt -= v; o.debtPaid = (o.debtPaid || 0) + v; (o.pays = o.pays || []).push({ a: v, at: Date.now(), by: S.me.full_name });
    await saveCO(o, `تسديد ${money(v)} من دين الطلب #${o.no} · ${o.name}`); closeModal(); render(); toast(o.debt ? 'انسجلت الدفعة · باقي ' + fmt(o.debt) : 'تسدد الدين بالكامل ✓'); return true; }
  if (a === 'ocan' && o) { if (!(await confirmBox(`إلغاء الطلب #${o.no}؟ يبقى بالسجل كملغي.`, 'إلغاء الطلب', true))) return true; o.st = 'cancel'; o.cancelBy = S.me.full_name; await saveCO(o, `إلغاء طلب #${o.no} · ${o.name}`); render(); return true; }
  if (a === 'orm' && o) { if (!(await confirmBox(`حذف الطلب #${o.no} نهائياً؟`, 'حذف', true))) return true; await DB.remove('orders', o.id); S.corders = S.corders.filter(x => x !== o); logAdd(`حذف طلب #${o.no} · ${o.name}`, 'co'); render(); return true; }
  if (a === 'calp' || a === 'caln') { S.calM = new Date(S.calM.getFullYear(), S.calM.getMonth() + (a === 'caln' ? 1 : -1), 1); render(); return true; }
  if (a === 'calt') { S.calM = null; S.calD = todayStr(); render(); return true; }
  if (a === 'cashsave') { const i = $('#cashin'); if (!i || i.value === '') return toast('اكتب المبلغ الفعلي'), true; const { kind, dk, u, R0 } = cashCtx(), x = +i.value || 0, n = $('#cashn');
    logAdd(`إغلاق ${kind === 'cake' ? 'صندوق الكيك' : 'صندوق الطلبات الخاصة'} ${dk}${u ? ' (' + u + ')' : ''}: المفروض ${fmt(R0.tot)} · الفعلي ${fmt(x)} · ${x === R0.tot ? 'مطابق' : x < R0.tot ? 'ناقص ' + fmt(R0.tot - x) : 'زايد ' + fmt(x - R0.tot)}${n && n.value ? ' · ' + n.value : ''}`, 'cash'); toast('انحفظ الإغلاق ✓'); return true; }
  if (a === 'cashprn') { printHtml(cashDoc(), 'R80'); return true; }
  if (a === 'occwa') { const x = occList(14)[+ds.i]; if (!x) return true; const s = (() => { try { return JSON.parse(localStorage.getItem('san_occ') || '{}'); } catch (e) { return {}; } })(); s[x.k + '_' + x.an.getFullYear()] = Date.now(); try { localStorage.setItem('san_occ', JSON.stringify(s)); } catch (e) {}
    openURL('https://wa.me/' + waNum(x.o.phone) + '?text=' + encodeURIComponent(`مرحباً ${x.o.name} 🌾\nقبل سنة احتفلتوا ويانا 🎂\nالمناسبة قرّبت، وحابين نكون وياكم هالسنة هم! احجزوا من هسه.\n— ${SHOP}`)); setTimeout(render, 600); return true; }
  if (a === 'cuso') { closeModal(); const x = S.corders.find(y => String(y.no) === String(ds.no)); S.cq = String(ds.no); S.cf = 'all'; go(x && kindOf(x) === 'special' ? 'corders' : 'k_ord'); return true; }
});
H.input.push(t => {
  if (t.id === 'cq') { S.cq = t.value; const l = $('#colist'); if (l) { const L = coFilter(); l.innerHTML = L.length ? L.map(coCard).join('') : empty('bag', 'ماكو طلبات'); loadPh(); } return true; }
  if (t.id === 'bphone') { S.cart && (S.cart.phone = t.value); phHint(); return true; }
  if (t.id === 'bdate') { capHint(); return true; }
  if (t.id === 'bdep') { const c = S.cart; c.dep = t.value; const tot = c.lines.reduce((s, l) => s + lineTotal(l), 0), d = +t.value || 0; $('#tdep').textContent = money(d); $('#trem').textContent = money(Math.max(0, tot - d)); return true; }
  if (t.id === 'ptxt' && S.pdx) { S.pdx.txt = t.value; return true; } if (t.id === 'pnote' && S.pdx) { S.pdx.note = t.value; return true; }
  if (t.id === 'colin') { colDiff(); return true; }
  if (t.id === 'cashin') { const d = $('#cashdf'), { R0 } = cashCtx(), x = (+t.value || 0) - R0.tot; d.innerHTML = t.value === '' ? '' : x === 0 ? '<b style="color:var(--green)">✓ مطابق</b>' : x < 0 ? `<b style="color:var(--red)">ناقص ${fmt(-x)}</b>` : `<b>زايد ${fmt(x)}</b>`; return true; }
  if (t.id === 'cusq') { S.cusQ = t.value; render().then(() => { const i = $('#cusq'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }); return true; }
});
H.change.push(async t => {
  if (t.id === 'phf' && t.files[0]) { readCart(); for (const f of [...t.files].slice(0, PH_MAX - S.cart.photos.length)) S.cart.photos.push(await shrink(f, 1400)); drawCart(); return true; }
  if (t.id === 'cashd') { S.cashD = t.value; render(); return true; } if (t.id === 'cashu') { S.cashU = t.value; render(); return true; }
  if (t.id === 'capin') { S.cfg.cake.cap = Math.max(0, +t.value || 0); await DB.upsert('settings', { id: 'cake', value: S.cfg.cake }); toast(S.cfg.cake.cap ? 'الحد: ' + S.cfg.cake.cap + ' طلب باليوم' : 'بدون حد'); return true; }
});
