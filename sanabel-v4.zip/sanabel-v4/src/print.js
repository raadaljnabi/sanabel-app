/* ===== الطباعة والوصل والفاتورة + التفعيل (داخل تطبيق الأندرويد) ===== */
const A = () => window.Android;
const lg = () => (S.cfg.shop && S.cfg.shop.logo) || 'logo.png';
const absLogo = () => { const l = lg(); return /^data:|^https?:/.test(l) ? l : new URL(l, location.href).href; };
const PRN_DEV = ['mode', 'ip', 'port', 'copies', 'auto'];
function prnCfg() { const d = { mode: 'dialog', ip: '', port: 9100, paper: 'r80', tpl: 'classic', copies: 1, auto: false, img: true, cimg: true }, c = S.cfg.print || {};
  for (const k in c) d[k] = c[k]; let L = {}; try { L = JSON.parse(localStorage.getItem('san_prn') || '{}'); } catch (e) {} for (const k in L) d[k] = L[k]; if (!A()) d.mode = 'dialog'; return d; }
async function setPrn(k, v) { if (PRN_DEV.includes(k)) { let L = {}; try { L = JSON.parse(localStorage.getItem('san_prn') || '{}'); } catch (e) {} L[k] = v; try { localStorage.setItem('san_prn', JSON.stringify(L)); } catch (e) {} return; }
  S.cfg.print = { ...(S.cfg.print || {}), [k]: v }; await DB.upsert('settings', { id: 'print', value: S.cfg.print }); }
const isInv = c => c.paper === 'a4' || c.paper === 'a5';
const SZ = { a4: { w: 794, pad: 44, fs: 14, pt: 595, media: 'A4' }, a5: { w: 559, pad: 28, fs: 12, pt: 420, media: 'A5' } };
const TPLN = { classic: 'كلاسيكي', modern: 'عصري', minimal: 'بسيط' };
const docFontName = () => (S.cfg.shop && S.cfg.shop.font) || (function () { try { return localStorage.getItem('san_font'); } catch (e) { return ''; } })() || 'Tajawal';
const FONT = '', FF = "'Tajawal',Tahoma,Arial,sans-serif";
const RCSS = '.rcp{background:#fff;color:#1a1a1a;width:100%;max-width:360px;padding:16px 14px;font-size:14px;line-height:1.55;direction:rtl;text-align:right}.rch{display:flex;flex-direction:column;align-items:center;gap:2px;text-align:center}.rch img{width:62px;height:62px;object-fit:contain}.rch b{font-size:20px}.rch small{color:#555}.rcn{text-align:center;margin:8px 0;padding:6px;border:1.5px dashed #888;border-radius:8px;font-size:15px}.rr{display:flex;justify-content:space-between;gap:10px;padding:2px 0}.rr>span:last-child{text-align:left;max-width:62%}.rr.big{font-weight:800;font-size:16px}.rr small{color:#555}.rcs{border-top:1.5px dashed #999;margin:8px 0}.rcd{text-align:center}.rcd b{font-size:16px}.rcf{text-align:center;margin-top:10px;color:#444;font-size:13px}';
/* الوصل الصغير */
function rcpt(o) {
  const d = dueD(o), sh = S.cfg.shop || {}, row = (a, b, c) => `<div class="rr${c ? ' ' + c : ''}"><span>${a}</span><span>${b}</span></div>`;
  return `<div class="rcp"><div class="rch"><img src="${absLogo()}" alt=""><b>${SHOP}</b>${sh.slogan ? `<small>${esc(sh.slogan)}</small>` : ''}${sh.phone ? `<small dir="ltr">${esc(sh.phone)}</small>` : ''}</div>
  <div class="rcn">وصل طلب <b dir="ltr">#${o.no}</b></div>${row('التاريخ', fD(new Date(o.at)))}${row('الزبون', esc(o.name))}${row('الهاتف', `<span dir="ltr">${esc(o.phone)}</span>`)}<div class="rcs"></div>
  ${(o.lines || []).map(l => row(`<b>${esc(l.name)}</b>${lineDesc(l) ? `<br><small>${esc(lineDesc(l))}</small>` : ''}`, `${esc(qtyTxt(l))}<br>${fmt(lineTotal(l))}`)).join('')}
  ${o.note ? row('ملاحظات', esc(o.note)) : ''}${o.ph ? row('صور', (o.phn > 1 ? o.phn + ' مرفقة' : 'مرفقة') + ' 📷') : ''}<div class="rcs"></div>${row('المجموع', esc(money(o.total)), 'big')}${row('العربون', esc(money(o.dep)))}
  ${o.coll != null ? row('المستلم عند التسليم', esc(money(o.coll))) + (o.disc ? row('خصم', esc(money(o.disc))) : '') + row(o.debt ? 'دين باقي' : 'الباقي', o.debt ? esc(money(o.debt)) : 'تم الاستحصال ✓', 'big') : row('الباقي', esc(money(remOf(o))), 'big')}
  <div class="rcs"></div><div class="rcd">موعد الاستلام<br><b>${fD(d)} · <span style="white-space:nowrap">${fT(d)}</span></b></div><div class="rcf">${esc(sh.rcNote || 'شكراً لاختياركم 🌾')}</div></div>`;
}
function rDoc(o, share, paper, thermal) { const cw = paper === 'r58' ? 290 : 380, mw = paper === 'r58' ? '48mm' : '72mm';
  return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">${share ? '<meta name="viewport" content="width=400">' : thermal ? `<meta name="viewport" content="width=${cw}">` : ''}<link href="https://fonts.googleapis.com/css2?family=${docFontName()}:wght@400;700;800&display=swap" rel="stylesheet"><title>وصل #${o.no}</title><style>@page{margin:${paper ? '2mm' : '4mm'}}body{margin:0;font-family:'${docFontName()}',Tahoma,Arial,sans-serif;background:#fff}${RCSS}
  ${share ? '.rcp{max-width:none;margin:0;padding:22px 20px 26px;font-size:15px}' : thermal ? `.rcp{max-width:none;margin:0;padding:4px 2px 10px;font-size:${paper === 'r58' ? 14 : 15}px;font-weight:700}.rcp,.rcp *{color:#000!important}` : `.rcp{max-width:${mw};margin:0 auto;padding:0}`}</style></head><body>${rcpt(o)}</body></html>`; }
/* الفاتورة A4 / A5 بثلاث قوالب */
function invHTML(o, size, tpl, photo, forShot) {
  const c = prnCfg(), sh = S.cfg.shop || {}, z = SZ[size] || SZ.a5, ac = '#FC8312', d = dueD(o);
  const rows = (o.lines || []).map(l => { const it = itemOf(l.iid); return [esc(l.name) + (lineDesc(l) ? `<br><small>${esc(lineDesc(l))}</small>` : '') + (c.img && it && it.img ? `<img class="th" src="${it.img}" alt="">` : ''), esc(qtyTxt(l)), l.price ? fmt(l.price) : '—', fmt(lineTotal(l))]; });
  let css = `@page{size:${z.media};margin:${forShot ? '0' : '6mm'}}${forShot ? '' : `.pg{max-width:none!important;padding:${Math.round(z.pad * .55)}px!important}`}*{box-sizing:border-box;margin:0;padding:0}html,body{background:#fff}body{font-family:'${docFontName()}',Tahoma,Arial,sans-serif;color:#1d1d1f;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .pg{width:100%;max-width:${z.w}px;margin:0 auto;padding:${z.pad}px;font-size:${z.fs}px;line-height:1.6;display:flex;flex-direction:column;gap:${Math.round(z.fs * 1.2)}px}${forShot ? `.pg{min-height:${Math.round(z.w * 1.414)}px}` : ''}
  .ih{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}.br{display:flex;gap:12px;align-items:center}.br img{width:${z.fs * 4.4}px;height:${z.fs * 4.4}px;object-fit:contain}.sn{font-size:${z.fs * 1.6}px;font-weight:800;display:block}.br small{display:block;color:#666;font-size:${z.fs * .86}px}
  .it{text-align:left}.it h1{font-size:${z.fs * 1.7}px}.it .no{font-size:${z.fs * 1.15}px;font-weight:800;direction:ltr}.it small{display:block;color:#666;font-size:${z.fs * .86}px}
  .meta{display:grid;grid-template-columns:1fr 1fr;gap:12px}.bx{padding:10px 12px}.bx h4{font-size:${z.fs * .86}px;color:#777;margin-bottom:4px}.bx p{display:flex;justify-content:space-between;gap:8px}
  table{width:100%;border-collapse:collapse}th,td{padding:${z.fs * .55}px ${z.fs * .6}px;text-align:right;vertical-align:middle}th{font-size:${z.fs * .86}px}td small{color:#666}td.n,th.n{text-align:left;white-space:nowrap}.th{width:${z.fs * 3}px;height:${z.fs * 3}px;object-fit:cover;border-radius:6px;float:left;margin-right:8px}
  .bt{display:grid;grid-template-columns:1.2fr 1fr;gap:14px;align-items:start}.nt{display:flex;flex-direction:column;gap:8px}.nt .bx p{display:block}.cph{max-width:100%;max-height:${z.fs * 11}px;object-fit:contain;border-radius:8px;display:block;margin-top:6px}.cphs{display:flex;gap:6px}.cphs .cph{flex:1;min-width:0}
  .tt div{display:flex;justify-content:space-between;padding:6px 12px}.tt .gr{font-weight:800;font-size:${z.fs * 1.25}px}.due{text-align:center;padding:10px}.due b{font-size:${z.fs * 1.25}px}
  .ft{margin-top:auto;display:flex;flex-direction:column;gap:12px}.terms{font-size:${z.fs * .86}px;color:#555}.sig{display:flex;justify-content:space-between;gap:30px;margin-top:${z.fs * 1.6}px}.sig span{flex:1;border-top:1px solid #333;padding-top:4px;text-align:center;font-size:${z.fs * .86}px;color:#555}.thx{text-align:center;color:#666}`;
  if (tpl === 'modern') css += `.ih{background:${ac};color:#fff;border-radius:16px;padding:${z.fs * 1.3}px}.br img{background:#fff;border-radius:50%;padding:4px}.br small,.it small{color:rgba(255,255,255,.85)}.bx{background:#f5f5f7;border-radius:12px}thead th{background:${ac};color:#fff}tbody tr:nth-child(even) td{background:#f7f7f9}.tt{background:#f5f5f7;border-radius:12px;padding:6px 0}.tt .gr{background:${ac};color:#fff;border-radius:999px;margin:4px 8px}.due{background:#f5f5f7;border-radius:12px}`;
  else if (tpl === 'minimal') css += `.ih{border-bottom:1px solid #ddd;padding-bottom:${z.fs}px}.it h1{font-weight:400;color:#888;font-size:${z.fs * 1.2}px}.bx{padding:6px 0}thead th{border-bottom:1.5px solid #222;color:#666;font-weight:400}tbody td{border-bottom:1px solid #eee}.tt div{padding:5px 0}.tt .gr{font-size:${z.fs * 1.7}px;border-top:1.5px solid #222;padding-top:8px}.due{border:1px solid #ddd;border-radius:8px}`;
  else css += `.ih{border-bottom:3px double #222;padding-bottom:${z.fs}px}.bx{border:1px solid #999}.bx h4{color:#222;border-bottom:1px solid #ccc;padding-bottom:3px}table,th,td{border:1px solid #888}thead th{background:#eee}.tt{border:1px solid #888}.tt div{border-bottom:1px solid #ccc}.tt div:last-child{border-bottom:0}.tt .gr{background:#eee}.due{border:2px solid #222}`;
  const txts = (o.lines || []).filter(l => l.txt).map(l => `«${esc(l.txt)}»`).join('<br>');
  return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=${z.w}"><link href="https://fonts.googleapis.com/css2?family=${docFontName()}:wght@400;700;800&display=swap" rel="stylesheet"><title>فاتورة #${o.no}</title><style>${css}</style></head><body><div class="pg">
  <header class="ih"><div class="br"><img src="${absLogo()}" alt=""><div><b class="sn">${SHOP}</b>${sh.slogan ? `<small>${esc(sh.slogan)}</small>` : ''}${sh.phone ? `<small dir="ltr" style="text-align:right">${esc(sh.phone)}</small>` : ''}${sh.addr ? `<small>${esc(sh.addr)}</small>` : ''}</div></div>
  <div class="it"><h1>فاتورة</h1><div class="no">#${o.no}</div><small>${fD(new Date(o.at))}</small></div></header>
  <section class="meta"><div class="bx"><h4>الزبون</h4><p><span>الاسم</span><b>${esc(o.name)}</b></p><p><span>الهاتف</span><b dir="ltr">${esc(o.phone)}</b></p></div><div class="bx"><h4>الطلب</h4><p><span>الحالة</span><b>${CST[o.st] || ''}</b></p><p><span>سجّله</span><b>${esc(o.by || '—')}</b></p></div></section>
  <table><thead><tr><th>الصنف</th><th>الكمية</th><th class="n">السعر</th><th class="n">المجموع</th></tr></thead><tbody>${rows.map(r => `<tr><td>${r[0]}</td><td>${r[1]}</td><td class="n">${r[2]}</td><td class="n">${r[3]}</td></tr>`).join('')}</tbody></table>
  <section class="bt"><div class="nt">${txts ? `<div class="bx"><h4>الكتابة على الكيك</h4><p>${txts}</p></div>` : ''}${o.note ? `<div class="bx"><h4>ملاحظات</h4><p>${esc(o.note)}</p></div>` : ''}${c.cimg && photo && photo.length ? `<div class="bx"><h4>${photo.length > 1 ? 'الصور المرفقة من الزبون' : 'الصورة المرفقة من الزبون'}</h4><div class="cphs">${photo.map(p => `<img class="cph" src="${p}" alt="">`).join('')}</div></div>` : ''}</div>
  <div class="nt"><div class="tt"><div><span>المجموع</span><b>${esc(money(o.total))}</b></div><div><span>العربون المدفوع</span><b>${esc(money(o.dep))}</b></div>
  ${o.coll != null ? `<div><span>المستلم عند التسليم</span><b>${esc(money(o.coll))}</b></div>${o.disc ? `<div><span>خصم</span><b>${esc(money(o.disc))}</b></div>` : ''}<div class="gr"><span>${o.debt ? 'دين باقي' : 'الحساب'}</span><span>${o.debt ? esc(money(o.debt)) : 'مدفوع بالكامل ✓'}</span></div>` : `<div class="gr"><span>المتبقي</span><span>${esc(money(remOf(o)))}</span></div>`}</div>
  <div class="due">موعد الاستلام<br><b>${fD(d)} · ${fT(d)}</b></div></div></section>
  <footer class="ft">${sh.terms ? `<div class="terms"><b>الشروط:</b> ${esc(sh.terms)}</div>` : ''}<div class="sig"><span>توقيع الزبون</span><span>ختم وتوقيع المحل</span></div><div class="thx">${esc(sh.rcNote || 'شكراً لاختياركم 🌾')}</div></footer></div></body></html>`;
}
const orderPhoto = o => o.ph || o.demoPh ? orderPhotos(o) : Promise.resolve([]);
function invDoc(o, size, forShot) { const c = prnCfg(); return Promise.race([orderPhoto(o).catch(() => null), new Promise(r => setTimeout(() => r(null), 5000))]).then(ph => invHTML(o, size, c.tpl, ph, forShot)); }
function browserPrint(html) {
  toast('جاري تجهيز الطباعة…'); const old = $('#bpf'); if (old) old.remove();
  try { const f = document.createElement('iframe'); f.id = 'bpf'; f.style.cssText = 'position:fixed;left:-10000px;top:0;width:900px;height:1300px;border:0;visibility:hidden'; document.body.appendChild(f);
    const w = f.contentWindow, dc = w.document; dc.open(); dc.write(html); dc.close(); let done = false;
    const go = () => { if (done) return; done = true; setTimeout(() => { try { w.focus(); w.print(); } catch (e) { toast('ما انفتحت نافذة الطباعة'); } }, 200); };
    const ready = () => { const imgs = [...dc.images].filter(i => !i.complete).map(i => new Promise(r => { i.onload = i.onerror = r; })); Promise.all([dc.fonts && dc.fonts.ready || 0, ...imgs]).then(go, go); };
    if (dc.readyState === 'complete') ready(); else w.addEventListener('load', ready); setTimeout(go, 4000); } catch (e) { toast('ما انفتحت نافذة الطباعة'); }
}
function printHtml(h, media) { if (A() && A().printHtml2) A().printHtml2(h, media || 'A4'); else if (A() && A().printHtml) A().printHtml(h); else browserPrint(h); }
function printO(o) {
  const c = prnCfg(), An = A();
  if (c.mode === 'office' && c.ip && An && An.printPdfNet) { const inv = isInv(c), PG = c.paper === 'a5' ? [420, 595] : [595, 842];
    (inv ? invDoc(o, c.paper, true) : Promise.resolve(rDoc(o, false, c.paper, true))).then(h => An.printPdfNet(h, c.ip, +c.port || 9100, inv ? SZ[c.paper].w : (c.paper === 'r58' ? 290 : 380), PG[0], PG[1], inv ? PG[0] : (c.paper === 'r58' ? 165 : 227), +c.copies || 1)); return; }
  if (isInv(c)) { invDoc(o, c.paper).then(h => printHtml(h, SZ[c.paper].media)); return; }
  if (c.mode === 'net' && c.ip && An && An.printEscPos) { An.printEscPos(rDoc(o, false, c.paper, true), c.ip, +c.port || 9100, c.paper === 'r58' ? 384 : 576, c.paper === 'r58' ? 290 : 380, +c.copies || 1); return; }
  printHtml(rDoc(o, false, c.paper), c.paper === 'r58' ? 'R58' : 'R80');
}
function sendPDF(o) {
  const c = prnCfg(), An = A(), cap = (isInv(c) ? 'فاتورة' : 'وصل') + ' طلبك رقم #' + o.no + ' من ' + SHOP + ' 🌾';
  if (An && isInv(c) && An.sharePdf2) { const z = SZ[c.paper]; invDoc(o, c.paper, true).then(h => An.sharePdf2(h, waNum(o.phone), String(o.no), cap, z.w, z.pt, 1.414)); return; }
  if (An && An.sharePdf) { An.sharePdf(rDoc(o, true, c.paper), waNum(o.phone), String(o.no), cap); return; }
  toast('إرسال PDF يشتغل من داخل تطبيق الأندرويد. هنا ينرسل كرسالة نصية'); setTimeout(() => waConfirm(o), 900);
}
const docW = () => { const c = prnCfg(); return isInv(c) ? SZ[c.paper].w : (c.paper === 'r58' ? 230 : 310); };
const docFor = o => { const c = prnCfg(); return isInv(c) ? invDoc(o, c.paper, true) : Promise.resolve(rDoc(o, false, c.paper).replace('</style>', 'body{padding:10px 0}</style>')); };
function fillDoc(box, frame, o) { const f = $(frame), b = $(box); if (!f || !b) return; b.dataset.w = docW(); docFor(o).then(h => { f.onload = () => { fitFrame(box, frame); setTimeout(() => fitFrame(box, frame), 700); }; f.srcdoc = h; }); }
function fitFrame(box, frame) { const b = $(box), f = $(frame); if (!b || !f) return; const w = +b.dataset.w, s = Math.min(1, b.clientWidth / w); let h = 420; try { h = f.contentDocument.documentElement.scrollHeight || h; } catch (e) {}
  f.style.width = w + 'px'; f.style.height = h + 'px'; f.style.right = Math.max(0, (b.clientWidth - w * s) / 2) + 'px'; f.style.transform = 'scale(' + s + ')'; b.style.height = Math.ceil(h * s) + 'px'; }
window.addEventListener('resize', () => { if ($('#rcpf')) fitFrame('#rcpv', '#rcpf'); if ($('#pvf')) fitFrame('#pvw', '#pvf'); });
function sampleO() { const o = S.corders.find(x => x.st !== 'cancel'); if (o) return o; const it = bookItems()[0] || act(S.items)[0];
  return { id: 'demo', demo: true, no: 1001, at: Date.now(), name: 'سارة أحمد', phone: '07701234567', due: addDays(todayStr(), 1) + 'T17:00', dep: 20000, total: 52000, st: 'new', by: S.me.full_name,
    lines: [{ name: it ? it.name : 'كيك', iid: it && it.id, qty: 1, unit: 'قطعة', size: 'وسط', price: 40000, adds: [{ n: 'شموع', p: 2000, c: 1 }, { n: 'طباعة صورة', p: 10000 }], txt: 'عيد ميلاد سعيد' }] }; }
/* إعدادات الطباعة (تنعرض بصفحة الإعدادات) */
function printCard() {
  const c = prnCfg(), inv = isInv(c);
  return `<div class="card pad"><div class="sec" style="margin-top:0">${ic('print')} الطابعة <span class="muted small">إعدادات هذا الجهاز بس</span></div>
    ${A() ? seg('data-pmode', [['dialog', 'اختيار من النافذة'], ['office', 'طابعة مكتب بالشبكة'], ['net', 'طابعة إيصالات حرارية بالشبكة']], c.mode)
      + (c.mode !== 'dialog' ? `<div class="grid g2" style="gap:10px;margin-top:10px"><label class="field"><span>عنوان الطابعة (IP)</span><input class="inp" id="prnip" dir="ltr" value="${esc(c.ip)}" placeholder="192.168.1.100"></label><label class="field"><span>المنفذ</span><input class="inp" id="prnport" dir="ltr" value="${c.port || 9100}"></label></div>
      <div class="row"><button class="btn s" data-a="prnscan">🔍 بحث بالشبكة</button><button class="btn s" data-a="prntest">اختبار الاتصال</button>${seg('data-pcopies', [[1, 'نسخة'], [2, 'نسختين'], [3, '3 نسخ']], c.copies)}</div><div id="pfound"></div>` : '')
      : '<p class="hint">على الحاسبة تنفتح نافذة الطباعة: اختار الطابعة وحجم الورق، والمقياس 100، وطفّي «الرؤوس والتذييلات».</p>'}
    <div class="sec">شكل الوصل / الفاتورة</div>${seg('data-ppaper', [['r80', 'إيصال 80مم'], ['r58', 'إيصال 58مم'], ['a5', 'فاتورة A5'], ['a4', 'فاتورة A4']], c.paper)}
    ${inv ? `<div style="margin-top:10px">${seg('data-ptpl', Object.entries(TPLN), c.tpl)}</div><label class="row small" style="gap:6px;margin-top:10px"><input type="checkbox" id="pimg" ${c.img ? 'checked' : ''}> صورة المنتج بالجدول</label><label class="row small" style="gap:6px;margin-top:6px"><input type="checkbox" id="pcimg" ${c.cimg ? 'checked' : ''}> صورة الزبون المرفقة</label>` : ''}
    <div class="sec">طباعة تلقائية بعد كل طلب</div>${seg('data-pauto', [[0, 'لا'], [1, 'نعم']], c.auto ? 1 : 0)}
    <div class="row" style="justify-content:space-between;margin-top:14px"><b>معاينة</b><div class="row"><button class="btn s" data-a="prntry">${ic('print')} طباعة تجريبية</button><button class="btn s g" data-a="pdftry">${ic('wa')} PDF تجريبي</button></div></div>
    <div class="pvw" id="pvw"><iframe id="pvf" title="معاينة" scrolling="no"></iframe></div></div>`;
}
window.__prnFound = (list, n) => { const el = $('#pfound'); if (!n) toast('الجهاز مو مربوط بواي فاي'); if (el) el.innerHTML = (list || []).length ? list.map(ip => `<button class="btn s" data-pick-ip="${ip}">🖨 ${ip}</button>`).join(' ') : '<span class="muted small">ما لكيت طابعة. تأكد إنها شغالة وعلى نفس الراوتر.</span>'; };
window.__prnTest = (ok, why) => toast(ok ? '✓ الطابعة متصلة وجاهزة' : '✗ ما گدر يوصل للطابعة: ' + (why || ''));
H.click.push(async (t, ds) => {
  const k = ['pmode', 'ppaper', 'ptpl', 'pauto', 'pcopies'].find(x => ds[x] !== undefined);
  if (k) { const v = ds[k], map = { pmode: 'mode', ppaper: 'paper', ptpl: 'tpl', pauto: 'auto', pcopies: 'copies' }; await setPrn(map[k], k === 'pauto' ? v === '1' : k === 'pcopies' ? +v : v); render(); return true; }
  if (ds.pickIp) { await setPrn('ip', ds.pickIp); render(); return true; }
  if (ds.a === 'prnscan') { if (A() && A().findPrinters) { toast('جاري البحث…'); A().findPrinters(); } return true; }
  if (ds.a === 'prntest') { const c = prnCfg(); if (!c.ip) return toast('اكتب عنوان الطابعة أول'), true; if (A() && A().testPrinter) A().testPrinter(c.ip, +c.port || 9100); return true; }
  if (ds.a === 'prntry') { printO(sampleO()); return true; }
  if (ds.a === 'pdftry') { const s = clone(sampleO()); s.phone = ''; sendPDF(s); return true; }
});
H.change.push(async t => {
  if (t.id === 'prnip') { await setPrn('ip', t.value.trim()); return true; } if (t.id === 'prnport') { await setPrn('port', +t.value || 9100); return true; }
  if (t.id === 'pimg' || t.id === 'pcimg') { await setPrn(t.id === 'pimg' ? 'img' : 'cimg', t.checked); fillDoc('#pvw', '#pvf', sampleO()); return true; }
});

/* ---------- التفعيل والاشتراك ---------- */
const LIC_PUB = { kty: 'EC', crv: 'P-256', x: '-v5k_-QnvNE39OVDW-xkwIpJx0dc5MGXjT3bHg7wzWg', y: '7omFoyJJJUqZgsBRlWUEhF45SfmEAylU-cKPLmGcqOc' };
let LIC = { st: 'wait', info: null }, licErr = '';
const PLAN = { T: 'تجريبي', M: 'شهري', H: '6 أشهر', Y: 'سنوي', L: 'مدى الحياة' };
function b64u(s) { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s), a = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
function rawDev() { try { if (A() && A().deviceId) { const a = String(A().deviceId() || '').replace(/[^0-9a-fA-F]/g, '').toUpperCase(); if (a.length >= 12) return a.slice(0, 12); } } catch (e) {}
  let d = ''; try { d = localStorage.getItem('sanabel_dev') || ''; } catch (e) {} if (!d) { const r = new Uint8Array(6); crypto.getRandomValues(r); d = [...r].map(x => (x < 16 ? '0' : '') + x.toString(16)).join('').toUpperCase(); try { localStorage.setItem('sanabel_dev', d); } catch (e) {} } return d; }
const devCode = () => { const d = rawDev(); return d.slice(0, 4) + '-' + d.slice(4, 8) + '-' + d.slice(8, 12); };
function licParse(code) { code = String(code || '').replace(/\s+/g, ''); const p = code.split('.'); if (p.length !== 2) return null; let pay; try { pay = new TextDecoder().decode(b64u(p[0])); } catch (e) { return null; }
  const f = pay.split('|'); if (f[0] !== '1' || f.length < 4 || !/^\d{8}$/.test(f[2])) return null; return { pay, sig: p[1], dev: f[1], exp: f[2], plan: f[3] }; }
function licVerify(code) { const c = licParse(code); if (!c) return Promise.resolve(null);
  const nat = () => { try { if (A() && A().verifyLic && A().verifyLic(c.pay, c.sig)) return c; } catch (e) {} return null; }; const sub = window.crypto && crypto.subtle; if (!sub) return Promise.resolve(nat());
  return sub.importKey('jwk', LIC_PUB, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']).then(k => sub.verify({ name: 'ECDSA', hash: 'SHA-256' }, k, b64u(c.sig), new TextEncoder().encode(c.pay))).then(ok => ok ? c : nat()).catch(() => nat()); }
const expDate = e => new Date(+e.slice(0, 4), +e.slice(4, 6) - 1, +e.slice(6, 8), 23, 59, 59);
const daysLeft = i => Math.ceil((expDate(i.exp) - Date.now()) / 864e5);
async function licCheck() {
  if (!A()) { LIC = { st: 'ok', info: null }; return LIC; }
  const now = Date.now(); let seen = 0; try { seen = +localStorage.getItem('sanabel_seen') || 0; } catch (e) {}
  if (seen && now < seen - 36 * 3600e3) { LIC = { st: 'clock', info: null }; return LIC; } try { localStorage.setItem('sanabel_seen', String(Math.max(seen, now))); } catch (e) {}
  let code = ''; try { code = localStorage.getItem('sanabel_lic') || ''; } catch (e) {} if (!code) { LIC = { st: 'none', info: null }; return LIC; }
  const c = await licVerify(code); LIC = !c ? { st: 'bad', info: null } : c.dev !== rawDev() ? { st: 'dev', info: c } : daysLeft(c) < 0 ? { st: 'expired', info: c } : { st: 'ok', info: c }; return LIC;
}
const licOK = () => LIC.st === 'ok' || LIC.st === 'wait';
function licBar() { const el = $('#licbar'); if (!el) return; el.innerHTML = ''; if (LIC.st !== 'ok' || !LIC.info || LIC.info.exp === '99991231') return; const d = daysLeft(LIC.info); if (d > 15) return; el.innerHTML = `<span class="chip red">⚠ الاشتراك ينتهي ${d <= 0 ? 'اليوم' : 'بعد ' + d + ' يوم'}</span>`; }
function renderLic(back) {
  const i = LIC.info, dc = devCode(), M = { none: ['التطبيق غير مفعّل', 'حتى تستخدم التطبيق تحتاج كود تفعيل من Meras Tech.'], expired: ['انتهى الاشتراك', i ? 'انتهى اشتراكك بتاريخ ' + fD(expDate(i.exp)) + '. بياناتك محفوظة.' : ''], bad: ['كود التفعيل غير صحيح', 'اطلب كود جديد.'], dev: ['الكود لجهاز ثاني', 'أرسل كود جهازك واطلب كود جديد.'], clock: ['تاريخ الجهاز غير صحيح', 'صحّح التاريخ والوقت واضغط إعادة المحاولة.'], ok: ['الاشتراك', i ? 'فعّال · ' + (PLAN[i.plan] || '') + (i.exp === '99991231' ? ' · بدون انتهاء' : ' · لحد ' + fD(expDate(i.exp))) : 'فعّال'] }[LIC.st] || ['', ''];
  const wt = 'السلام عليكم، أريد ' + (LIC.st === 'expired' || LIC.st === 'ok' ? 'تجديد اشتراك' : 'تفعيل') + ' تطبيق ' + SHOP + '\nكود الجهاز: ' + dc;
  $('#root').innerHTML = `<div class="applogin"><div class="alhero"><img src="logo.png" alt=""><b>${M[0]}</b><span>${M[1]}</span></div><div class="alform">
    ${LIC.st !== 'clock' ? `<div class="devc"><small class="muted">كود الجهاز</small><b dir="ltr">${dc}</b></div>
      <a class="btn g w" href="https://wa.me/${WA}?text=${encodeURIComponent(wt)}" target="_blank" rel="noopener">${ic('wa')} إرسال كود الجهاز لـ Meras Tech</a>
      <label class="field" style="margin-top:12px"><span>كود التفعيل</span><textarea class="inp" id="licin" rows="3" dir="ltr" spellcheck="false" placeholder="الصق كود التفعيل هنا"></textarea></label>
      ${licErr ? `<div class="err">${esc(licErr)}</div>` : ''}<button class="btn p w big" id="lcGo">تفعيل</button>` : '<button class="btn p w big" id="lcRe">إعادة المحاولة</button>'}
    ${back ? '<button class="btn w" id="lcBack" style="margin-top:8px">رجوع</button>' : ''}<p class="muted small" style="text-align:center;margin-top:14px">تصميم وتطوير <b>Meras Tech</b> · <b dir="ltr">${WAT}</b></p></div></div>`;
  const go = $('#lcGo'); if (go) go.onclick = async () => { const code = ($('#licin').value || '').trim(); if (!code) { licErr = 'الصق كود التفعيل'; return renderLic(back); }
    const c = await licVerify(code); licErr = !c ? 'الكود غير صحيح، تأكد إنك نسخته كامل' : c.dev !== rawDev() ? 'هذا الكود لجهاز ثاني' : daysLeft(c) < 0 ? 'هذا الكود منتهي' : ''; if (licErr) return renderLic(back);
    try { localStorage.setItem('sanabel_lic', code.replace(/\s+/g, '')); } catch (x) {} toast('تم التفعيل ✓'); location.reload(); };
  const re = $('#lcRe'); if (re) re.onclick = async () => { await licCheck(); if (licOK()) location.reload(); else renderLic(back); };
  const bk = $('#lcBack'); if (bk) bk.onclick = () => startApp();
}
setInterval(async () => { if (!A()) return; await licCheck(); if (!licOK()) renderLic(); else licBar(); }, 5 * 60 * 1000);
