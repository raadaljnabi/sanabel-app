/* ===== الرئيسية + لوحة التحكم + الإدارة (المنتجات، الأقسام، المستخدمين، الأدوار، الإعدادات، السجل، التقارير) ===== */
const greet = () => new Date().getHours() < 12 ? 'صباح الخير' : 'مساء الخير';

/* ---------- الرئيسية: كل واحد يشوف شغله ---------- */
R.home = async function () {
  const c = currentCtx(); await ensureShifts(addDays(c.date, -2)); const me = S.me.id, tk = todayStr();
  let h = `<div class="hero"><div><span class="hg">${greet()}،</span><b>${esc(S.me.full_name.replace(/^الشيف\s+/, ''))}</b><small>${dayName(tk)} · ${roleName(S.me.role)}</small></div></div>`;
  if (P('jard')) {
    const mine = canEditShift(c.date, c.shift), rec = getRec(c.date, c.shift), st = shiftState(c.date, c.shift), its = jardItems(), done = its.filter(it => rec?.rows?.[it.id]?.close != null).length;
    const mleft = Math.round((shiftEnd(c.date, c.shift) - Date.now()) / 60000), left = mleft > 60 ? `${Math.floor(mleft / 60)} س ${mleft % 60} د` : `${Math.max(mleft, 0)} دقيقة`;
    h += !mine ? `<div class="card bigcard"><span class="bc-ic">${ic('clock')}</span><b>ماكو إلك شفت هسه</b><p>الشفت الحالي: ${SHIFT[c.shift]} ${shiftRange(c.shift)}</p></div>`
      : st === 'none' ? `<div class="card bigcard accent"><span class="bc-ic">${ic('clip')}</span><b>بداية الشفت ال${SHIFT[c.shift]}</b><p>${shiftRange(c.shift)} · عدّ الموجود بالصالة واستلم الشفت</p><button class="btn p w big" data-go="jard">${ic('check')} استلام الشفت</button></div>`
      : st === 'open' ? `<div class="card bigcard"><span class="bc-ic">${ic('clip')}</span><b>الشفت ال${SHIFT[c.shift]} مفتوح</b><p>باقي ${left} · سجّلت المتبقي لـ ${done} من ${its.length} صنف</p><div class="prog"><i style="width:${its.length ? done / its.length * 100 : 0}%"></i></div><button class="btn d w big" data-go="jard">${done === its.length ? 'مراجعة وإغلاق الشفت' : 'متابعة الجرد'}</button></div>`
      : `<div class="card bigcard ok"><span class="bc-ic">${ic('check')}</span><b>تسكّر شفتك</b><p>شكراً ${esc(S.me.full_name)}</p></div>`;
  }
  const tiles = [];
  if (P('prod')) { const J = prodJobs().filter(j => j.chef === me); tiles.push(['production', 'chef', J.filter(j => j.st === 'new').length, 'شغل جديد إلي'], ['production', 'play', J.filter(j => j.st === 'prep' || j.st === 'ready').length, 'بلشت بي / جهزته']); }
  if (PA('c_orders', 'c_book')) { const A0 = S.corders.filter(o => kindOf(o) === 'cake' && !['done', 'cancel'].includes(o.st)); tiles.push(['k_ord', 'cake', A0.filter(o => (o.due || '').slice(0, 10) === tk).length, 'كيك تسليم اليوم'], ['k_ord', 'check', A0.filter(o => o.st === 'ready').length, 'كيك عند الكاونتر']); }
  if (PA('o_view', 'o_book')) { const A0 = S.corders.filter(o => kindOf(o) === 'special' && !['done', 'cancel'].includes(o.st)); tiles.push(['corders', 'bag', A0.filter(o => (o.due || '').slice(0, 10) === tk).length, 'طلبات خاصة تسليم اليوم'], ['corders', 'check', A0.filter(o => o.st === 'ready').length, 'طلبات خاصة جاهزة']); }
  if (P('po_new')) tiles.push(['porders', 'layers', S.porders.filter(o => o.status !== 'done' && o.for_date <= addDays(tk, 1)).length, 'طلبيات الصالة المفتوحة']);
  if (P('wh_issue')) tiles.push(['wh', 'box', S.whs.filter(w => w.status === 'new').length, 'طلبات مواد بانتظار الصرف']);
  else if (P('wh_req')) tiles.push(['wh', 'box', S.whs.filter(w => w.chef_id === me && w.status === 'new').length, 'طلبات موادي المعلقة']);
  if (tiles.length) h += `<div class="tiles">${tiles.map(([g, i, n, l]) => `<button class="tile" data-go="${g}">${ic(i)}<b>${n}</b><span>${l}</span></button>`).join('')}</div>`;
  const quick = [];
  if (P('c_book')) quick.push(`<button class="btn p big" data-a="newCO" data-k="cake">${ic('cake')} حجز كيك</button>`);
  if (P('o_book')) quick.push(`<button class="btn big" data-a="newCO" data-k="special">${ic('plus')} طلب خاص لزبون</button>`);
  if (P('po_new')) quick.push(`<button class="btn big" id="newOrder">${ic('layers')} طلبية للمطبخ</button>`);
  if (P('wh_req')) quick.push(`<button class="btn big" id="newWh">${ic('box')} طلب مواد من المستودع</button>`);
  if (P('c_show')) quick.push(`<button class="btn big" data-go="k_show">${ic('tv')} شاشة العرض</button>`);
  if (quick.length) h += `<div class="row" style="margin-top:14px">${quick.join('')}</div>`;
  if (P('prod')) { const J = prodJobs().filter(j => j.chef === me && j.st !== 'sent').sort((a, b) => a.due < b.due ? -1 : 1).slice(0, 5);
    h += `<div class="sec">شغلي القريب<span class="sp"></span><button class="lnk" data-go="production">الكل</button></div>` + (J.length ? J.map(j => `<button class="card lrow" data-go="production"><span class="chip ${j.st === 'new' ? 'new' : j.st === 'ready' ? 'ready' : 'prod'}">${PST[j.st]}</span><div><b>${esc(j.title)}</b><small>${esc(deptName(j.dept))} · ${(j.due || '').slice(0, 10)} · ${j.lines.length} صنف</small></div>${ic('more')}</button>`).join('') : `<div class="card">${empty('chef', 'ماكو شغل مفتوح إلك')}</div>`); }
  $('#view').innerHTML = h;
};

/* ---------- لوحة التحكم ---------- */
R.dashboard = async function () {
  const d = S.ddate || todayStr(); await ensureShifts(addDays(d, -8)); const its = jardItems();
  const sold = its.map(it => [it.unit, daySold(d, it.id)]), waste = its.map(it => [it.unit, dayWaste(d, it.id)]);
  const pcs = sold.filter(x => x[0] === 'قطعة').reduce((a, b) => a + b[1], 0), kg = sold.filter(x => x[0] !== 'قطعة').reduce((a, b) => a + b[1], 0);
  const hallVal = its.reduce((s, it) => s + daySold(d, it.id) * (+it.price || 0), 0);
  const SP = S.corders.filter(o => kindOf(o) === 'special'), CO = S.corders.filter(o => kindOf(o) === 'cake');
  const booked = SP.filter(o => o.at && fmtD(new Date(o.at)) === d && o.st !== 'cancel'), dueToday = SP.filter(o => (o.due || '').slice(0, 10) === d && o.st !== 'cancel');
  const cBook = CO.filter(o => o.at && fmtD(new Date(o.at)) === d && o.st !== 'cancel'), cDue = CO.filter(o => (o.due || '').slice(0, 10) === d && o.st !== 'cancel');
  const J = prodJobs(), byD = act(S.depts).map(x => ({ x, n: J.filter(j => j.dept === x.id && j.st !== 'sent').length, r: J.filter(j => j.dept === x.id && j.st === 'sent').length }));
  const shiftCard = s => { const r = getRec(d, s), ss = shiftState(d, s), late = ss !== 'closed' && Date.now() > shiftEnd(d, s).getTime() + 30 * 60000;
    const stt = ss === 'closed' ? ['closed', 'مغلق', 'done'] : late ? ['late', ss === 'open' ? 'متأخر بالإغلاق' : 'ما انستلم', 'red'] : ss === 'open' ? ['open', 'مفتوح', 'new'] : ['', 'ما بدأ', ''];
    const who = r?.employee_name || assigned(d, s).map(id => userOf(id)?.full_name).filter(Boolean).join('، ');
    return `<div class="card shiftcard" data-go="jard" style="cursor:pointer"><span class="dot ${stt[0]}"></span><div style="flex:1"><b>الشفت ال${SHIFT[s]} <span class="muted small" style="font-weight:400">${shiftRange(s)}</span></b><span class="muted small">${who ? esc(who) : '—'}</span></div><span class="chip ${stt[2]}">${stt[1]}</span></div>`; };
  const days = Array.from({ length: 7 }, (_, i) => addDays(d, i - 6)), week = days.map(x => ({ x, v: its.filter(i => i.unit === 'قطعة').reduce((a, i) => a + daySold(x, i.id), 0) + S.corders.filter(o => o.at && fmtD(new Date(o.at)) === x && o.st !== 'cancel').length })), mx = Math.max(1, ...week.map(w => w.v));
  const neg = its.filter(it => (soldOf(d, 'am', it.id) ?? 0) < 0 || (soldOf(d, 'pm', it.id) ?? 0) < 0);
  $('#view').innerHTML = `<div class="toolbar"><div><b style="font-size:17px">ملخص ${dayName(d)}</b></div><span class="sp"></span>${dateCtl('dDate', d)}</div>
  ${neg.length ? `<div class="alert" style="margin-bottom:10px">${ic('alert')}<div><b>أخطاء بالعد (مبيع بالسالب):</b> ${neg.map(i => esc(i.name)).join('، ')}</div></div>` : ''}
  <div class="grid g4">
    <div class="card kpi"><div class="ic">${ic('cash')}</div><span class="lbl">مبيعات الصالة</span><span class="val">${r3(pcs)} <small>قطعة</small></span><span class="sub">${kg ? r3(kg) + ' كغم · ' : ''}${hallVal ? 'تقريباً ' + money(hallVal) : ''}</span></div>
    <div class="card kpi blue" data-go="corders" style="cursor:pointer"><div class="ic">${ic('bag')}</div><span class="lbl">طلبات خاصة انحجزت</span><span class="val">${booked.length}</span><span class="sub">${money(booked.reduce((s, o) => s + (o.total || 0), 0))} · عربون ${fmt(booked.reduce((s, o) => s + (o.dep || 0), 0))}</span></div>
    <div class="card kpi green" data-go="corders" style="cursor:pointer"><div class="ic">${ic('cal')}</div><span class="lbl">طلبات خاصة تسليم اليوم</span><span class="val">${dueToday.length}</span><span class="sub">${dueToday.filter(o => o.st === 'done').length} مسلّم · ${dueToday.filter(o => o.st === 'ready').length} جاهز</span></div>
    <div class="card kpi red"><div class="ic">${ic('trash')}</div><span class="lbl">التالف بالصالة</span><span class="val">${byUnit(waste)}</span></div></div>
  <div class="grid g4" style="margin-top:14px"><div class="card kpi" data-go="k_ord" style="cursor:pointer"><div class="ic">${ic('cake')}</div><span class="lbl">طلبات كيك انحجزت</span><span class="val">${cBook.length}</span><span class="sub">${money(cBook.reduce((s, o) => s + (+o.total || 0), 0))} · عربون ${fmt(cBook.reduce((s, o) => s + (+o.dep || 0), 0))}</span></div>
    <div class="card kpi green" data-go="k_cal" style="cursor:pointer"><div class="ic">${ic('cal')}</div><span class="lbl">كيك تسليم هذا اليوم</span><span class="val">${cDue.length}</span><span class="sub">${cDue.filter(o => o.st === 'done').length} مسلّم · ${cDue.filter(o => o.st === 'ready').length} عند الكاونتر</span></div>
    <div class="card kpi blue" data-go="k_kit" style="cursor:pointer"><div class="ic">${ic('chef')}</div><span class="lbl">كيك بالمطبخ</span><span class="val">${CO.filter(o => o.st === 'new' || o.st === 'prep').length}</span><span class="sub">جديد أو قيد التحضير</span></div></div>
  <div class="sec">الإنتاج حسب القسم</div><div class="grid g4">${byD.map(b => `<div class="card kpi" data-go="production" style="cursor:pointer"><span class="lbl">${deptDot(b.x.id)} ${esc(b.x.name)}</span><span class="val">${b.n}</span><span class="sub">شغل مفتوح · ${b.r} انسلّم اليوم</span></div>`).join('')}
    <div class="card kpi" data-go="wh" style="cursor:pointer"><span class="lbl">${ic('box', 'sm')} المستودع</span><span class="val">${S.whs.filter(w => w.status === 'new').length}</span><span class="sub">طلب بانتظار الصرف</span></div></div>
  <div class="grid g2" style="margin-top:14px">${shiftCard('am')}${shiftCard('pm')}</div>
  <div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">الحركة آخر 7 أيام <span class="sp"></span><span class="muted small">قطع الصالة + طلبات الزبائن</span></div>
    <div class="chart">${week.map(w => `<div class="col ${w.x === d ? 'today' : ''}"><span class="v">${r3(w.v) || ''}</span><div class="bar" style="height:${w.v / mx * 140}px"></div><span class="d">${dayShort(w.x)}</span></div>`).join('')}</div></div>`;
};

/* ---------- المنتجات والأسعار ---------- */
const sizesOf = it => (it.sizes || []).filter(s => s.n || s.p);
const cakeEd = () => PA('c_cat_edit', 'catalog');
const roNote = () => cakeEd() ? '' : `<div class="alert">${ic('shield')}<div>عرض فقط. التعديل يحتاج صلاحية «تعديل تصاميم الكيك».</div></div>`;
R.catalog = () => catalogView(S.setTab === 'mats' ? 'mats' : 'items');
R.k_cats = () => catalogView('cats');
R.k_add = () => catalogView('adds');
function catalogView(k) {
  const tabs = [['items', 'منتجات الصالة'], ['mats', 'المواد الأولية']];
  let h = k === 'items' || k === 'mats' ? `<div class="toolbar">${seg('data-stab', tabs, k)}</div>` : roNote() + `<fieldset class="fs" ${cakeEd() ? '' : 'disabled'}>`;
  if (k === 'items') {
    const groups = byDept(S.items.filter(it => !it.book).sort((a, b) => (b.active !== false) - (a.active !== false) || (a.sort || 0) - (b.sort || 0)));
    h += `<div class="row" style="margin-bottom:12px"><button class="btn p" data-a="itNew">${ic('plus')} منتج جديد</button><span class="hint">كل منتج إله قسم إنتاج، والطلبيات تروح لشيفات قسمه. تصاميم الكيك صارت بقسم <button class="lnk" data-go="k_imgs">الكيك ← التصاميم والأسعار</button></span></div>`
      + groups.map(([dk, L]) => `<div class="sec">${deptDot(dk)} ${esc(dk ? deptName(dk) : 'بدون قسم')} <span class="muted small">(${L.length})</span></div><div class="card">${L.map(it => `<button class="lrow2 btnrow ${it.active === false ? 'off' : ''}" data-itedit="${it.id}">${it.img ? `<img class="th0" src="${it.img}" alt="">` : `<span class="th0 noimg">${ic(it.book ? 'cake' : 'box')}</span>`}
        <div class="grow"><b>${esc(it.name)}</b> <span class="muted small">${esc(it.unit || '')}</span><div class="tags">${it.book ? '<span class="chip prod">كيك مخصص للحجز</span>' : ''}${it.jard !== false && !it.book ? '<span class="chip">بالجرد</span>' : ''}${!it.book && it.sell !== false ? '<span class="chip new">يتباع للزبائن</span>' : ''}${it.active === false ? '<span class="chip red">موقوف</span>' : ''}</div></div>
        <b>${sizesOf(it).length ? sizesOf(it).map(s => fmt(s.p)).join(' / ') : it.price ? fmt(it.price) : '—'}</b></button>`).join('')}</div>`).join('');
  } else if (k === 'cats') {
    h += `<div class="card pad"><div class="row"><input class="inp" id="newCat" placeholder="مثلاً: عيد الأم" style="flex:1"><button class="btn p" data-a="catAdd">${ic('plus')} إضافة</button></div></div><input type="file" id="covf" accept="image/*" hidden>
      <div class="card" style="margin-top:12px">${S.cats.map((c, i) => `<div class="srow" data-cid="${c.id}"><button class="th0 cov" data-a="catCov" data-id="${c.id}">${c.cover || bookItems().find(x => x.cat === c.id)?.img ? `<img src="${c.cover || bookItems().find(x => x.cat === c.id).img}" alt="">` : ic('img')}</button>
        <input class="inp" data-catn="${c.id}" value="${esc(c.name)}"><span class="muted small nw">${bookItems().filter(x => x.cat === c.id).length} تصميم</span>
        <button class="btn s" data-a="catMv" data-id="${c.id}" data-d="-1" ${i === 0 ? 'disabled' : ''}>▲</button><button class="btn s" data-a="catMv" data-id="${c.id}" data-d="1" ${i === S.cats.length - 1 ? 'disabled' : ''}>▼</button><button class="btn s x" data-a="catDel" data-id="${c.id}">${ic('trash')}</button></div>`).join('') || empty('cake', 'ماكو مناسبات')}</div>`;
  } else if (k === 'adds') {
    const C = CK();
    h += `<div class="card pad"><div class="sec" style="margin-top:0">الحشوات <span class="muted small">السعر 0 = بدون زيادة · ينضاف على كل قطعة</span></div>${seg('data-fillreq', [[1, 'اختيار الحشوة إجباري'], [0, 'اختياري']], C.fillReq ? 1 : 0)}
      <div style="margin-top:10px">${C.fills.map((f, i) => `<div class="srow"><input class="inp" data-cfg="fills.${i}.n" value="${esc(f.n)}" placeholder="اسم الحشوة"><input class="inp num" data-cfg="fills.${i}.p" value="${f.p || ''}" placeholder="الزيادة"><button class="btn s x" data-a="cfgDel" data-k="fills" data-i="${i}">${ic('trash')}</button></div>`).join('')}</div>
      <button class="btn s" data-a="cfgAdd" data-k="fills">${ic('plus')} حشوة</button></div>
      <div class="card pad" style="margin-top:12px"><div class="sec" style="margin-top:0">الإضافات <span class="muted small">«بالعدد» مثل الشموع والسعر للواحدة</span></div>
      ${C.addons.map((a, i) => `<div class="srow"><input class="inp" data-cfg="addons.${i}.n" value="${esc(a.n)}" placeholder="اسم الإضافة"><input class="inp num" data-cfg="addons.${i}.p" value="${a.p || ''}" placeholder="السعر"><label class="row small nw" style="gap:4px"><input type="checkbox" data-cfgc="addons.${i}.cnt" ${a.cnt ? 'checked' : ''}> بالعدد</label><label class="row small nw" style="gap:4px"><input type="checkbox" data-cfgc="addons.${i}.ph" ${a.ph ? 'checked' : ''}> تحتاج صورة</label><button class="btn s x" data-a="cfgDel" data-k="addons" data-i="${i}">${ic('trash')}</button></div>`).join('')}
      <button class="btn s" data-a="cfgAdd" data-k="addons">${ic('plus')} إضافة</button></div>
      <div class="card pad" style="margin-top:12px"><div class="sec" style="margin-top:0">الحد الأقصى لطلبات الكيك باليوم <span class="muted small">0 = بدون حد</span></div><div class="row"><input class="inp" type="number" id="capin" min="0" value="${+C.cap || 0}" style="max-width:140px"><span class="muted">طلب باليوم</span></div></div>`;
  } else {
    const list = S.mats.slice().sort((a, b) => (b.active !== false) - (a.active !== false) || (a.sort || 0) - (b.sort || 0)), sel = (v, attr) => `<select class="inp" ${attr}>${[...new Set([...MAT_UNITS, v].filter(Boolean))].map(u => `<option ${u === v ? 'selected' : ''}>${u}</option>`).join('')}</select>`;
    h += `<div class="card pad"><div class="srow" style="padding:0;border:0"><input class="inp" id="newMat" placeholder="اسم مادة جديدة">${sel('كغم', 'id="newMatU"')}<button class="btn p" data-a="matAdd">${ic('plus')} إضافة</button></div></div>
      <div class="card" style="margin-top:12px">${list.map(m => `<div class="srow ${m.active === false ? 'off' : ''}" data-mid="${m.id}"><input class="inp" data-mk="name" value="${esc(m.name)}">${sel(m.unit, 'data-mk="unit"')}<button class="btn s" data-a="matTog" data-id="${m.id}">${m.active === false ? 'تفعيل' : 'إيقاف'}</button></div>`).join('') || empty('box', 'ماكو مواد')}</div>`;
  }
  if (k === 'cats' || k === 'adds') h += '</fieldset>';
  $('#view').innerHTML = h;
}
/* تصاميم الكيك: صورة، وصف، مناسبة، أحجام وأسعار */
R.k_imgs = function () {
  const q = (S.kiq || '').trim(), cf = S.kic || '', L = S.items.filter(i => i.book).filter(it => (!cf || (cf === '_' ? !S.cats.some(c => c.id === it.cat) : it.cat === cf)) && (!q || it.name.includes(q)));
  $('#view').innerHTML = roNote() + `<div class="toolbar">${cakeEd() ? `<button class="btn p" data-a="itNewCake">${ic('plus')} تصميم جديد</button>` : ''}
    <select class="inp" id="kic" style="width:auto"><option value="">كل المناسبات</option>${S.cats.map(c => `<option value="${c.id}" ${c.id === cf ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}<option value="_" ${cf === '_' ? 'selected' : ''}>بدون مناسبة</option></select>
    <input class="inp" id="kiq" type="search" placeholder="بحث…" value="${esc(q)}" style="max-width:220px"><span class="sp"></span><span class="muted small">${L.length} تصميم</span></div>
    <div class="dgrid">${L.map(it => `<button class="dcard ${it.active === false ? 'off' : ''}" ${cakeEd() ? `data-itedit="${it.id}"` : `data-a="kimg" data-src="${it.img || ''}"`}>${it.img ? `<img src="${it.img}" alt="" loading="lazy">` : `<span class="noimg">${ic('cake')}</span>`}
      <div class="dci"><b>${esc(it.name)}</b><small class="muted">${esc(S.cats.find(c => c.id === it.cat)?.name || 'بدون مناسبة')}${it.active === false ? ' · موقوف' : ''}</small><div class="chips">${sizesOf(it).map(z => `<span>${esc(z.n || '—')} <i>${fmt(z.p)}</i></span>`).join('') || (it.price ? `<span>${fmt(it.price)}</span>` : '')}</div></div></button>`).join('') || empty('cake', 'ماكو تصاميم')}</div>`;
};
/* المظهر: يتحكم بشكل كل التطبيق */
R.look = function () {
  const L = lookCfg(), opt = (id, list, v) => `<div class="seg">${list.map(([k, l]) => `<button data-lk="${id}" data-v="${k}" class="${String(k) === String(v) ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  $('#view').innerHTML = `<div class="grid g2" style="align-items:start"><div>
  <div class="card pad"><div class="sec" style="margin-top:0">${ic('edit')} الثيم والألوان</div>
    <div class="thm">${THEMES.map((t, i) => `<button class="thb ${L.ac === t.ac && L.bg === t.bg ? 'on' : ''}" data-thm="${i}" style="--a:${t.ac};--b:${t.bg}"><i></i><span>${t.n}</span></button>`).join('')}</div>
    <div class="grid g2" style="gap:10px;margin-top:12px"><label class="field"><span>اللون الأساسي</span><input class="inp clr" type="color" data-lkc="ac" value="${L.ac || '#FC8312'}"></label><label class="field"><span>لون الخلفية</span><input class="inp clr" type="color" data-lkc="bg" value="${L.bg || '#F6F2ED'}"></label></div>
    <button class="btn s" data-a="lkReset">الألوان الافتراضية</button></div>
  <div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">الخط</div>${opt('font', [['Tajawal', 'تجوال'], ['Cairo', 'القاهرة'], ['Almarai', 'المراعي']], L.font)}
    <p style="font-family:'${L.font}';font-size:18px;margin:12px 0 0">سنابل الطاحونة · كيك ومعجنات ١٢٣</p></div>
  <div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">الشعار والزوايا</div>
    <label class="field"><span>حجم الشعار بالشاشات: <b>${L.lh}px</b></span><input type="range" min="28" max="90" data-lkr="lh" value="${L.lh}"></label>
    <label class="field"><span>تدوير الزوايا: <b>${L.rad}px</b></span><input type="range" min="0" max="34" data-lkr="rad" value="${L.rad}"></label>
    <p class="hint">الشعار نفسه يتغيّر من <button class="lnk" data-go="settings">الإعدادات ← معلومات المحل</button></p></div></div>
  <div><div class="card pad"><div class="sec" style="margin-top:0">${ic('tv')} شاشة عرض الكيك</div>
    <div class="muted small" style="margin-bottom:6px">طريقة العرض</div>${opt('view', [['slider', 'سلايدر'], ['grid', 'شبكة'], ['list', 'قائمة']], L.view)}
    <div class="muted small" style="margin:12px 0 6px">نسبة الصورة</div>${opt('ratio', [['1/1', 'مربع'], ['4/5', '4:5'], ['3/4', '3:4'], ['2/3', 'طولي'], ['4/3', 'عرضي']], L.ratio)}
    <div class="muted small" style="margin:12px 0 6px">ملائمة الصورة</div>${opt('fit', [['cover', 'تملي الإطار'], ['contain', 'كاملة بدون قص']], L.fit)}
    ${L.view === 'slider' ? `<label class="row small" style="gap:8px;margin-top:12px"><input type="checkbox" id="lkAuto" ${L.auto ? 'checked' : ''}> تقليب تلقائي للسلايدر</label>${L.auto ? `<label class="field" style="margin-top:8px"><span>كل <b>${L.sec}</b> ثواني</span><input type="range" min="2" max="12" data-lkr="sec" value="${L.sec}"></label>` : ''}` : ''}</div>
    <div class="card pad lkprev" style="margin-top:14px"><div class="sec" style="margin-top:0">معاينة</div><div class="gal">${bookItems().slice(0, 3).map(it => `<div class="gi">${it.img ? `<img src="${it.img}" alt="">` : ''}<div class="gc"><b>${esc(it.name)}</b>${fromP(it)}</div></div>`).join('')}</div>
    <div class="row" style="margin-top:10px"><button class="btn p">زر أساسي</button><button class="btn">زر عادي</button><span class="chip new">جديد</span><span class="chip done">جاهز</span></div></div></div></div>`;
};
async function saveLook(patch) { S.cfg.look = Object.assign(lookCfg(), patch); applyLook(); await DB.upsert('settings', { id: 'look', value: S.cfg.look }); }
function itemForm(it, cake) {
  const d = it ? clone(it) : { name: '', unit: cake ? 'قطعة' : 'قطعة', dept: cake ? (S.depts.find(x => /كيك/.test(x.name))?.id || '') : '', price: '', active: true, jard: !cake, sell: !cake, book: !!cake, sizes: cake ? [{ n: 'صغير', p: '' }] : [], sort: S.items.length };
  S.itd = d; drawItemForm();
}
function drawItemForm() {
  const d = S.itd;
  modal(`<h2>${d.id ? 'تعديل منتج' : d.book ? 'تصميم كيك جديد' : 'منتج جديد'}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2>
    <label class="field"><span>الاسم</span><input class="inp" id="itN" value="${esc(d.name)}"></label>
    <div class="grid g2" style="gap:10px"><label class="field"><span>قسم الإنتاج</span><select class="inp" id="itD"><option value="">بدون قسم</option>${act(S.depts).map(x => `<option value="${x.id}" ${x.id === d.dept ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
    <label class="field"><span>الوحدة</span><select class="inp" id="itU">${[...new Set([...ITEM_UNITS, d.unit].filter(Boolean))].map(u => `<option ${u === d.unit ? 'selected' : ''}>${u}</option>`).join('')}</select></label></div>
    
    ${d.book ? `<div class="card pad" style="box-shadow:none;margin-bottom:10px"><div class="row" style="align-items:flex-start">${d.img ? `<img src="${d.img}" alt="" style="width:90px;height:90px;object-fit:cover;border-radius:12px">` : ''}<button class="btn s" data-a="itImg">${ic('img')} ${d.img ? 'تغيير الصورة' : 'رفع صورة'}</button><input type="file" id="itImgF" accept="image/*" hidden></div>
      <label class="field" style="margin-top:10px"><span>الوصف</span><input class="inp" id="itDesc" value="${esc(d.desc || '')}"></label>
      <label class="field"><span>المناسبة بشاشة العرض</span><select class="inp" id="itCat"><option value="">بدون</option>${S.cats.map(c => `<option value="${c.id}" ${c.id === d.cat ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>
      <div class="muted small" style="margin-bottom:6px">الأحجام والأسعار</div>${(d.sizes || []).map((s, j) => `<div class="srow"><input class="inp" data-szn="${j}" value="${esc(s.n || '')}" placeholder="الحجم"><input class="inp num" data-szp="${j}" value="${s.p || ''}" placeholder="السعر"><button class="btn s x" data-a="szDel" data-i="${j}">${ic('x')}</button></div>`).join('')}
      <button class="btn s" data-a="szAdd">${ic('plus')} حجم وسعر</button></div>`
    : `<label class="field"><span>السعر للوحدة (للزبائن)</span><input class="inp" type="number" id="itP" value="${d.price || ''}" placeholder="0"></label>
      <label class="row small" style="gap:8px;margin-bottom:6px"><input type="checkbox" id="itJ" ${d.jard !== false ? 'checked' : ''}> ينعرض بالصالة ويدخل بالجرد وطلبيات الصالة</label>
      <label class="row small" style="gap:8px;margin-bottom:6px"><input type="checkbox" id="itS" ${d.sell !== false ? 'checked' : ''}> يتباع للزبائن بطلبات خاصة (مثل المعمول بالكيلو)</label>`}
    <div class="mact"><button class="btn p" data-a="itSave">${ic('check')} حفظ</button>${d.id ? `<button class="btn ${d.active === false ? 'g' : 'x'}" data-a="itTog">${d.active === false ? 'تفعيل' : 'إيقاف'}</button>` : ''}<button class="btn" data-close>إلغاء</button></div>`, true);
}
function readItemForm() { const d = S.itd; d.name = $('#itN').value.trim(); d.dept = $('#itD').value; d.unit = $('#itU').value;
  if (d.book) { d.desc = $('#itDesc').value.trim(); d.cat = $('#itCat').value; d.sizes = $$('[data-szn]').map(i => ({ n: i.value.trim(), p: +$(`[data-szp="${i.dataset.szn}"]`).value || 0 })); d.jard = false; d.sell = false; }
  else { d.price = +$('#itP').value || 0; d.jard = $('#itJ').checked; d.sell = $('#itS').checked; } }

/* ---------- أقسام الإنتاج والشيفات ---------- */
R.depts = function () {
  const chefs = S.users.filter(u => u.active && u.role !== OWNER && roleHas(u.role, 'prod'));
  $('#view').innerHTML = `<div class="card pad"><div class="row"><input class="inp" id="newDept" placeholder="اسم قسم جديد، مثلاً: الخبز والصمون" style="flex:1"><input type="color" id="newDeptC" value="#2F6DB5" style="width:52px;height:42px;border:0;background:none"><button class="btn p" data-a="deptAdd">${ic('plus')} إضافة قسم</button></div>
    <p class="hint">كل قسم إله منتجاته وشيفاته. الشيف يگدر يكون بأكثر من قسم. الشيف = مستخدم دوره بيه صلاحية «شيف».</p></div>
  ${S.depts.map(d => { const its = S.items.filter(i => i.dept === d.id && i.active !== false).length;
    return `<div class="card pad" style="margin-top:12px;${d.active === false ? 'opacity:.55' : ''}"><div class="row"><input type="color" data-deptc="${d.id}" value="${esc(d.color || '#999999')}" style="width:40px;height:36px;border:0;background:none"><input class="inp" data-deptn="${d.id}" value="${esc(d.name)}" style="flex:1;font-weight:700"><span class="muted small nw">${its} منتج</span><button class="btn s" data-a="deptTog" data-id="${d.id}">${d.active === false ? 'تفعيل' : 'إيقاف'}</button></div>
      <div class="sec">الشيفات بهذا القسم</div><div class="chips2">${chefs.map(u => `<label class="pchk2 ${(u.depts || []).includes(d.id) ? 'on' : ''}"><input type="checkbox" data-dchef="${d.id}|${u.id}" ${(u.depts || []).includes(d.id) ? 'checked' : ''}> ${esc(u.full_name)}</label>`).join('') || '<span class="muted small">ماكو شيفات. ضيف مستخدم دوره بيه صلاحية «شيف».</span>'}</div></div>`; }).join('')}`;
};

/* ---------- المستخدمين ---------- */
const canTouch = u => u.role !== OWNER || isOwner();
function roleOptions(sel) { return (isOwner() || sel === OWNER ? [[OWNER, 'المدير الرئيسي']] : []).concat(S.roles.map(r => [r.id, r.name])).map(([id, n]) => `<option value="${esc(id)}" ${id === sel ? 'selected' : ''}>${esc(n)}</option>`).join('') + (sel && sel !== OWNER && !roleOf(sel) ? `<option value="${esc(sel)}" selected>(دور محذوف)</option>` : ''); }
R.users = function () {
  const us = [...S.users].sort((a, b) => (b.active - a.active) || ((a.role === OWNER ? 0 : 1) - (b.role === OWNER ? 0 : 1)) || String(a.full_name).localeCompare(String(b.full_name), 'ar'));
  $('#view').innerHTML = `<div class="toolbar"><span class="muted">${S.users.filter(u => u.active).length} مستخدم فعّال</span><span class="sp"></span><button class="btn p" data-a="uNew">${ic('plus')} مستخدم جديد</button></div>
  <div class="card">${us.map(u => { const self = u.id === S.me.id, lock = !canTouch(u);
    return `<div class="lrow2 ${u.active ? '' : 'off'}"><div class="av">${esc(initials(u.full_name))}</div><div class="grow"><b>${esc(u.full_name)}</b> ${self ? '<span class="chip">إنت</span>' : ''} ${u.active ? '' : '<span class="chip red">موقوف</span>'}<div class="muted small"><span dir="ltr">@${esc(u.username || '')}</span>${(u.depts || []).length && roleHas(u.role, 'prod') ? ' · ' + u.depts.map(deptName).join('، ') : ''}</div></div>
      <select class="inp" data-urole="${u.id}" style="width:auto" ${self || lock ? 'disabled' : ''}>${roleOptions(u.role)}</select><button class="btn s" data-a="uEdit" data-id="${u.id}" ${lock ? 'disabled' : ''}>تعديل</button>
      ${self ? '' : `<button class="btn s ${u.active ? 'x' : ''}" data-a="uTog" data-id="${u.id}" ${lock ? 'disabled' : ''}>${u.active ? 'إيقاف' : 'تفعيل'}</button>`}</div>`; }).join('')}</div>
  <p class="hint">كل موظف يدخل باسم المستخدم وكلمة المرور مالته، ويشوف بس الصفحات اللي يسمح بيها دوره.${MODE === 'cloud' ? ' إذا موظف نسى كلمة المرور: أوقف حسابه وسوّيله حساب جديد.' : ''}</p>`;
};
function userForm(u) {
  const isNew = !u, mp = MODE === 'cloud' ? 6 : 4, role = u ? u.role : (S.roles[0] || {}).id, deps = u ? (u.depts || []) : [];
  modal(`<h2>${isNew ? 'مستخدم جديد' : 'تعديل ' + esc(u.full_name)}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2><div id="uErr"></div>
    <label class="field"><span>الاسم الكامل</span><input class="inp" id="uName" value="${esc(u ? u.full_name : '')}"></label>
    ${isNew ? `<label class="field"><span>اسم المستخدم (بالإنجليزي، للدخول)</span><input class="inp" id="uUser" dir="ltr" autocapitalize="none" placeholder="ahmed"></label><label class="field"><span>كلمة المرور (${mp} أحرف على الأقل)</span><input class="inp" id="uPass" dir="ltr" autocomplete="off"></label>
      <label class="field"><span>الدور</span><select class="inp" id="uRole">${roleOptions(role)}</select></label>`
    : (DB.canResetOthers && u.id !== S.me.id ? `<label class="field"><span>كلمة مرور جديدة (اختياري)</span><input class="inp" id="uPass" dir="ltr" autocomplete="off"></label>` : '')}
    <div class="field"><span>أقسام الإنتاج <small class="muted">(للشيفات بس)</small></span><div class="chips2">${act(S.depts).map(d => `<label class="pchk2 ${deps.includes(d.id) ? 'on' : ''}"><input type="checkbox" data-udept="${d.id}" ${deps.includes(d.id) ? 'checked' : ''}> ${esc(d.name)}</label>`).join('')}</div></div>
    <div class="mact"><button class="btn p" data-a="uSave" data-id="${u ? u.id : ''}">${isNew ? '+ إضافة' : 'حفظ'}</button><button class="btn" data-close>إلغاء</button></div>`);
}

/* ---------- الأدوار والصلاحيات ---------- */
R.roles = function () {
  const n = id => S.users.filter(u => u.role === id && u.active).length;
  $('#view').innerHTML = `<div class="toolbar"><span class="muted">اضغط على أي دور حتى تختار صلاحياته. التعديل يمشي على كل اللي عندهم هالدور.</span><span class="sp"></span><button class="btn p" data-a="rNew">${ic('plus')} دور جديد</button></div>
  <div class="rgrid"><div class="card rcard lock"><b>👑 المدير الرئيسي</b><span class="muted small">كل الصلاحيات · ما يتعدّل ولا ينحذف</span><span class="chip">${n(OWNER)} مستخدم</span></div>
  ${S.roles.map(r => `<button class="card rcard" data-a="rEdit" data-id="${esc(r.id)}"><b>${esc(r.name)}</b><div class="tags">${PERMS.map(g => [g, g.items.filter(([k]) => (r.perms || {})[k]).length]).filter(x => x[1]).map(([g, c]) => `<span class="chip">${g.ic} ${g.t}: ${c}</span>`).join('') || '<span class="chip red">بدون صلاحيات</span>'}</div><span class="muted small">${n(r.id)} مستخدم</span></button>`).join('')}</div>`;
};
function roleForm(r) {
  const p = (r && r.perms) || {};
  modal(`<h2>${r ? 'تعديل الدور' : 'دور جديد'}<span class="sp"></span><button class="iconbtn" data-close>${ic('x')}</button></h2><div id="rErr"></div>
    <label class="field"><span>اسم الدور</span><input class="inp" id="rName" value="${esc(r ? r.name : '')}" placeholder="مثلاً: شيف حلويات، مشرف صالة"></label>
    ${PERMS.map(g => { const all = g.items.every(([k]) => p[k]); return `<div class="pg"><div class="pgh"><b>${g.ic} ${g.t}</b><button type="button" class="btn s" data-pall="${g.g}" data-on="${all ? 1 : 0}">${all ? 'إلغاء الكل' : 'تحديد الكل'}</button></div>
      <div class="pcols">${g.items.map(([k, l]) => `<label class="pchk"><input type="checkbox" data-pg="${g.g}" data-pk="${k}" ${p[k] ? 'checked' : ''}><span>${esc(l)}</span></label>`).join('')}</div></div>`; }).join('')}
    <div class="mact"><button class="btn p" data-a="rSave" data-id="${r ? esc(r.id) : ''}">حفظ الدور</button>${r ? `<button class="btn x" data-a="rDel" data-id="${esc(r.id)}">حذف</button>` : ''}<button class="btn" data-close>إلغاء</button></div>`, true);
}

/* ---------- الإعدادات ---------- */
R.settings = function () {
  const sh = S.cfg.shop;
  $('#view').innerHTML = `<div class="grid g2" style="align-items:start"><div>
  <div class="card pad"><div class="sec" style="margin-top:0">${ic('home')} معلومات المحل <span class="muted small">تطلع بالوصل والفاتورة</span></div>
    <label class="field"><span>عبارة تحت الاسم</span><input class="inp" data-shop="slogan" value="${esc(sh.slogan || '')}"></label>
    <div class="grid g2" style="gap:10px"><label class="field"><span>هاتف المحل</span><input class="inp" data-shop="phone" dir="ltr" value="${esc(sh.phone || '')}"></label><label class="field"><span>العملة</span><input class="inp" data-shop="cur" value="${esc(sh.cur || 'د.ع')}"></label></div>
    <label class="field"><span>العنوان</span><input class="inp" data-shop="addr" value="${esc(sh.addr || '')}"></label>
    <label class="field"><span>الشروط (أسفل الفاتورة)</span><textarea class="inp" data-shop="terms" rows="2">${esc(sh.terms || '')}</textarea></label>
    <label class="field"><span>عبارة الشكر</span><input class="inp" data-shop="rcNote" value="${esc(sh.rcNote || '')}"></label>
    <div class="row"><img src="${lg()}" alt="" style="width:56px;height:56px;object-fit:contain;border-radius:12px;background:var(--field)"><button class="btn s" data-a="logoPick">رفع شعار</button>${sh.logo ? '<button class="btn s x" data-a="logoDel">الشعار الافتراضي</button>' : ''}<input type="file" id="logof" accept="image/*" hidden></div></div>
  <div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">${ic('dl')} النسخ الاحتياطي ونقل البيانات</div>
    <div class="row"><button class="btn p" data-a="bkSave">${ic('dl')} حفظ نسخة كاملة (الصالة والمطبخ والمستودع)</button></div>
    <div class="sec">بيانات تطبيق الكيك القديم</div><p class="hint" style="margin-top:0">إذا عندك نسخة احتياطية من تطبيق الكيك القديم (ملف .json) تكدر تدخل تصاميمه وطلباته هنا.</p>
    <div class="row"><button class="btn" data-a="bkOld">${ic('up')} استيراد نسخة الكيك القديم</button>${A() && A().openLegacy ? `<button class="btn" data-a="bkLegacy">${ic('dl')} سحب البيانات من التطبيق القديم بالجهاز</button>` : ''}<input type="file" id="bkf" accept=".json,application/json" hidden></div></div>
  ${A() ? `<div class="card pad" style="margin-top:14px"><div class="sec" style="margin-top:0">الاشتراك</div><p>${LIC.st === 'ok' && LIC.info ? 'فعّال · ' + (PLAN[LIC.info.plan] || '') + (LIC.info.exp === '99991231' ? ' · بدون انتهاء' : ' · لحد ' + fD(expDate(LIC.info.exp))) : 'غير مفعّل'}</p><p class="muted small">كود الجهاز: <b dir="ltr">${devCode()}</b></p><button class="btn s" data-a="licNew">إدخال كود جديد</button></div>` : ''}
  </div><div>${printCard()}</div></div>`;
  setTimeout(() => fillDoc('#pvw', '#pvf', sampleO()), 0);
};
async function backupAll() {
  toast('جاري تجهيز النسخة…'); const data = {}; for (const t of TABLES) { try { data[t] = await DB.list(t); } catch (e) { data[t] = []; } }
  const txt = JSON.stringify({ app: 'sanabel-v2', at: Date.now(), by: S.me.full_name, data }), d = new Date(), name = `sanabel-backup-${fmtD(d)}-${pad2(d.getHours())}${pad2(d.getMinutes())}.json`;
  if (A() && A().saveFile) { A().saveFile(txt, name, false); return; }
  const u = URL.createObjectURL(new Blob([txt], { type: 'application/json' })), a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 4000);
}
/* استيراد نسخة تطبيق الكيك القديم (حفظ بالجهاز) */
async function importOldCake(f) {
  let o; try { o = JSON.parse(await f.text()); } catch (e) { return toast('الملف مو نسخة احتياطية صحيحة'); }
  if (!o || o.app !== 'sanabel' || !o.data || !o.data.cats) return toast('هذا مو ملف تطبيق الكيك القديم');
  const d = o.data, n = d.cats.reduce((s, c) => s + c.imgs.length, 0);
  let cakeDept = S.depts.find(x => /كيك/.test(x.name)); if (!cakeDept) { cakeDept = await DB.upsert('depts', { id: 'd_cake', name: 'الكيك', color: '#D9467A', sort: 0, active: true }); S.depts.push(cakeDept); }
  if (!(await confirmBox(`استيراد ${d.cats.length} مناسبة و${n} تصميم و${(d.orders || []).length} طلب من تطبيق الكيك القديم؟`, 'استيراد'))) return;
  toast('جاري الاستيراد…'); let k = 0;
  for (const [ci, c] of d.cats.entries()) { await DB.upsert('show_cats', { id: c.id, name: c.name, sort: 50 + ci, cover: c.cover || '' });
    for (const [j, m] of c.imgs.entries()) { await DB.upsert('items', { id: m.id, name: m.cap || c.name + ' ' + (j + 1), desc: m.desc || '', img: m.src, cat: c.id, dept: cakeDept.id, unit: 'قطعة', book: true, jard: false, sell: false, active: true, sort: 200 + k++, sizes: (m.sizes || []).filter(s => s.n || s.p) }); } }
  const cc = { ...S.cfg.cake }; if (d.fills) cc.fills = d.fills; if (d.addons) cc.addons = d.addons; if (d.fillReq != null) cc.fillReq = d.fillReq; if (d.cap != null) cc.cap = d.cap; await DB.upsert('settings', { id: 'cake', value: cc });
  let mx = 0;
  for (const x of d.orders || []) { mx = Math.max(mx, +x.no || 0);
    const line = { id: uid(), iid: x.iid, name: x.item || 'كيك', dept: cakeDept.id, qty: x.qty || 1, unit: 'قطعة', size: x.size || '', price: +x.sp || 0, fill: x.fill || null, adds: x.adds || [], txt: x.txt || '', note: '' };
    const st = x.st || 'new', prodSt = st === 'ready' || st === 'done' ? 'sent' : st === 'prep' ? 'prep' : 'new';
    const no = { ...x, kind: 'cake', lines: [line], note: x.note || '', chefs: { [cakeDept.id]: '' }, prod: { [cakeDept.id]: prodSt }, legacy: true };
    ['iid', 'item', 'size', 'sp', 'qty', 'adds', 'fill', 'txt', 'cat', 'photo'].forEach(f => delete no[f]);
    await DB.upsert('orders', no); const ph = (o.photos || {})['o_' + x.id] || x.photo; if (ph) await DB.setPhoto(x.id, ph); }
  if (mx) await DB.bumpNo(mx);
  logAdd(`استيراد بيانات تطبيق الكيك القديم: ${n} تصميم و${(d.orders || []).length} طلب`, 'sys'); await refresh('*'); toast('تم الاستيراد ✓');
}

/* ---------- سجل النشاط ---------- */
R.log = async function () {
  if (!S._logs || S._logsAt < Date.now() - 30000) { $('#view').innerHTML = '<div class="loading">جاري تحميل السجل…</div>'; try { S._logs = (await DB.list('logs', { field: 'at', from: addDays(todayStr(), -45) })).sort((a, b) => b.at.localeCompare(a.at)); S._logsAt = Date.now(); } catch (e) { $('#view').innerHTML = `<div class="alert">${esc(e.message)}</div>`; return; } }
  const us = [...new Set(S._logs.map(x => x.u))], q = S.lgQ || '', L = S._logs.filter(x => (!S.lgU || x.u === S.lgU) && (!q || x.a.includes(q)));
  let day = '', h = '';
  L.slice(0, 500).forEach(x => { const d = x.at.slice(0, 10); if (d !== day) { day = d; h += `<div class="lgd">${fD(new Date(x.at))}</div>`; } h += `<div class="lgi"><span class="t">${fT(new Date(x.at))}</span><span class="av">${esc(initials(x.u))}</span><span class="tx"><b>${esc(x.u)}</b> ${esc(x.a)}</span></div>`; });
  $('#view').innerHTML = `<div class="toolbar"><select class="inp" id="lgu" style="width:auto"><option value="">كل الموظفين</option>${us.map(u => `<option ${u === S.lgU ? 'selected' : ''}>${esc(u)}</option>`).join('')}</select><input class="inp" id="lgq" type="search" placeholder="بحث: رقم طلب، اسم زبون…" value="${esc(q)}" style="max-width:280px"><span class="sp"></span><span class="muted small">${L.length} عملية · آخر 45 يوم</span><button class="btn s" data-a="lgRe">تحديث</button></div>
  <div class="card pad">${h || empty('log', 'ماكو عمليات')}</div>`;
};

/* ---------- حسابي ---------- */
R.account = function () {
  $('#view').innerHTML = `<div class="card pad row" style="gap:14px;max-width:560px"><div class="av" style="width:56px;height:56px;font-size:22px">${esc(initials(S.me.full_name))}</div>
    <div style="flex:1"><b style="font-size:18px">${esc(S.me.full_name)}</b><div class="muted" dir="ltr" style="text-align:end">@${esc(S.me.username || '')}</div></div><span class="chip">${esc(roleName(S.me.role))}</span></div>
  ${myDepts().length ? `<div class="card pad" style="max-width:560px;margin-top:14px"><b>أقسامي:</b> ${myDepts().map(d => deptDot(d) + ' ' + esc(deptName(d))).join(' · ')}</div>` : ''}
  <div class="card pad" style="max-width:560px;margin-top:14px"><div class="sec" style="margin-top:0">${ic('key')} تغيير كلمة المرور</div>
    <label class="field"><span>كلمة المرور الجديدة</span><input class="inp" id="np1" type="password" dir="ltr"></label><label class="field"><span>أعد كتابتها</span><input class="inp" id="np2" type="password" dir="ltr"></label>
    <button class="btn d" data-a="chpw">حفظ كلمة المرور</button></div>
  <div style="max-width:560px;margin-top:14px" class="row"><button class="btn x" data-logout>${ic('out')} تسجيل الخروج / تبديل المستخدم</button>${MODE === 'demo' ? '<button class="btn" data-a="resetDemo">إعادة البيانات التجريبية</button>' : ''}</div>`;
};

/* ---------- التقارير ---------- */
R.k_rep = () => R.reports('cake');
R.reports = async function (kind) {
  const { rfrom, rto } = S, quick = [['اليوم', 0], ['7 أيام', 6], ['30 يوم', 29]], cake = kind === 'cake', tab = cake ? 'sales' : S.rtab;
  let h = `<div class="toolbar">${cake ? `<b>${ic('cake')} مبيعات الكيك</b>` : seg('data-rtab', [['sales', 'الطلبات الخاصة'], ['hall', 'الصالة والمستودع'], ['prod', 'الإنتاج']], S.rtab)}<span class="sp"></span>
    <div class="filters">${quick.map(([l, n]) => `<button data-rq="${n}" class="${rfrom === addDays(todayStr(), -n) && rto === todayStr() ? 'on' : ''}">${l}</button>`).join('')}</div>
    <label class="row small muted" style="gap:6px">من <input type="date" class="inp" id="rFrom" value="${rfrom}" style="width:auto;padding:7px 10px"></label><label class="row small muted" style="gap:6px">إلى <input type="date" class="inp" id="rTo" value="${rto}" style="width:auto;padding:7px 10px"></label>
    <button class="btn s" data-a="csv">${ic('dl')} Excel</button><button class="btn s" data-a="prt">${ic('print')} طباعة</button></div>`;
  const s0 = +new Date(rfrom + 'T00:00'), e0 = +new Date(addDays(rto, 1) + 'T00:00');
  const tbl = (title, head, rows) => `<div class="sec">${title}</div>` + (rows.length ? `<div class="card tw"><table class="t"><thead><tr>${head.map(x => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : `<div class="card">${empty('chart', 'ماكو بيانات بهالفترة')}</div>`);
  if (tab === 'sales') {
    const all = S.corders.filter(o => kindOf(o) === (cake ? 'cake' : 'special') && o.at >= s0 && o.at < e0), ok = all.filter(o => o.st !== 'cancel');
    const sales = ok.reduce((s, o) => s + netTotal(o), 0), recv = ok.reduce((s, o) => s + (o.dep || 0) + (o.st === 'done' ? (o.coll != null ? o.coll : remOf(o)) : 0) + (o.debtPaid || 0), 0), out = ok.reduce((s, o) => s + (o.st === 'done' ? (o.debt || 0) : remOf(o)), 0);
    const by = (f) => { const m = {}; ok.forEach(o => f(o).forEach(([k, n, v]) => { const x = m[k] || (m[k] = [0, 0]); x[0] += n; x[1] += v; })); return Object.entries(m).sort((a, b) => b[1][1] - a[1][1]); };
    const items = by(o => o.lines.map(l => [l.name, l.qty, lineTotal(l)])), depts = by(o => o.lines.map(l => [deptName(l.dept), 1, lineTotal(l)])), users = by(o => [[o.by || '—', 1, o.total]]);
    S._csv = [['المنتج', 'الكمية', 'القيمة'], ...items.map(([k, v]) => [k, r3(v[0]), v[1]]), [], ['القسم', 'الأسطر', 'القيمة'], ...depts.map(([k, v]) => [k, v[0], v[1]]), [], ['الموظف', 'الطلبات', 'القيمة'], ...users.map(([k, v]) => [k, v[0], v[1]])];
    h += `<div class="grid g4"><div class="card kpi"><span class="lbl">المبيعات</span><span class="val">${fmt(sales)} <small>${cur()}</small></span><span class="sub">${ok.length} طلب · ${all.length - ok.length} ملغي</span></div><div class="card kpi green"><span class="lbl">المبالغ المستلمة</span><span class="val">${fmt(recv)}</span></div><div class="card kpi red"><span class="lbl">المتبقي عند الزبائن</span><span class="val">${fmt(out)}</span></div><div class="card kpi blue"><span class="lbl">متوسط الطلب</span><span class="val">${fmt(ok.length ? Math.round(sales / ok.length) : 0)}</span></div></div>`
      + tbl('الأكثر مبيعاً', ['المنتج', 'الكمية', 'القيمة'], items.map(([k, v]) => [esc(k), r3(v[0]), '<b>' + fmt(v[1]) + '</b>'])) + `<div class="grid g2" style="align-items:start"><div>${tbl('حسب قسم الإنتاج', ['القسم', 'الأسطر', 'القيمة'], depts.map(([k, v]) => [esc(k), v[0], fmt(v[1])]))}</div><div>${tbl('حسب الموظف', ['الموظف', 'الطلبات', 'القيمة'], users.map(([k, v]) => [esc(k), v[0], fmt(v[1])]))}</div></div>`;
  } else if (tab === 'prod') {
    const m = {}; const add = (dept, chef, kind) => { const k = dept + '|' + chef, x = m[k] || (m[k] = { dept, chef, po: 0, co: 0 }); x[kind]++; };
    S.porders.filter(o => o.for_date >= rfrom && o.for_date <= rto && ['ready', 'sent', 'done'].includes(o.status)).forEach(o => add(o.dept || '', o.chef_id, 'po'));
    S.corders.filter(o => (o.due || '').slice(0, 10) >= rfrom && (o.due || '').slice(0, 10) <= rto && o.st !== 'cancel').forEach(o => oDepts(o).forEach(d => { if (['ready', 'sent'].includes((o.prod || {})[d]) || ['ready', 'done'].includes(o.st)) add(d, (o.chefs || {})[d], 'co'); }));
    const rows = Object.values(m).sort((a, b) => (b.po + b.co) - (a.po + a.co));
    S._csv = [['القسم', 'الشيف', 'طلبيات صالة', 'طلبات زبائن'], ...rows.map(x => [deptName(x.dept), userOf(x.chef)?.full_name || '', x.po, x.co])];
    h += tbl('الشغل المنجز حسب القسم والشيف', ['القسم', 'الشيف', 'طلبيات الصالة', 'طلبات الزبائن', 'المجموع'], rows.map(x => [deptDot(x.dept) + esc(deptName(x.dept)), esc(userOf(x.chef)?.full_name || '—'), x.po, x.co, '<b>' + (x.po + x.co) + '</b>']));
  }
  $('#view').innerHTML = h;
  if (tab === 'hall') { const keep = $('#view').innerHTML; await renderReportsHall(); $('#view').innerHTML = keep + $('#view').innerHTML; }
};

/* ---------- الأحداث ---------- */
H.click.push(async (t, ds, id) => {
  const a = ds.a;
  if (ds.stab) { S.setTab = ds.stab; return render(), true; }
  if (ds.rtab) { S.rtab = ds.rtab; return render(), true; }
  if (ds.rq !== undefined) { S.rfrom = addDays(todayStr(), -ds.rq); S.rto = todayStr(); return render(), true; }
  if (ds.itedit) { itemForm(itemOf(ds.itedit)); return true; }
  if (ds.fillreq !== undefined) { S.cfg.cake.fillReq = ds.fillreq === '1'; await DB.upsert('settings', { id: 'cake', value: S.cfg.cake }); return render(), true; }
  if (ds.pall) { const on = ds.on !== '1'; $$(`[data-pg="${ds.pall}"]`).forEach(c => c.checked = on); t.dataset.on = on ? '1' : '0'; t.textContent = on ? 'إلغاء الكل' : 'تحديد الكل'; return true; }
  if (ds.thm !== undefined) { const T = THEMES[+ds.thm]; await saveLook({ ac: T.ac, bg: T.bg }); return render(), true; }
  if (ds.lk) { await saveLook({ [ds.lk]: ds.v }); return render(), true; }
  if (!a) return;
  if (a === 'lkReset') { const L = lookCfg(); delete L.ac; delete L.bg; S.cfg.look = L; applyLook(); await DB.upsert('settings', { id: 'look', value: L }); return render(), true; }
  if (a === 'csv') { const csv = '﻿' + (S._csv || []).map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n'); const el = document.createElement('a'); el.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); el.download = `تقرير-${S.rfrom}-${S.rto}.csv`; document.body.appendChild(el); el.click(); el.remove(); return true; }
  if (a === 'prt') { window.print(); return true; }
  /* المنتجات */
  if (a === 'itNew' || a === 'itNewCake') { itemForm(null, a === 'itNewCake'); return true; }
  if (a === 'itImg') { readItemForm(); $('#itImgF').click(); return true; }
  if (a === 'szAdd') { readItemForm(); S.itd.sizes.push({ n: '', p: 0 }); drawItemForm(); return true; }
  if (a === 'szDel') { readItemForm(); S.itd.sizes.splice(+ds.i, 1); drawItemForm(); return true; }
  if (a === 'itSave' || a === 'itTog') { readItemForm(); const d = S.itd; if (!d.name) return toast('اكتب اسم المنتج'), true; if (a === 'itTog') d.active = d.active === false; const old = d.id && itemOf(d.id);
    const saved = await DB.upsert('items', d); const i = S.items.findIndex(x => x.id === saved.id); if (i >= 0) S.items[i] = saved; else S.items.push(saved);
    if (old && JSON.stringify([old.price, old.sizes]) !== JSON.stringify([saved.price, saved.sizes])) logAdd(`تغيير سعر «${saved.name}»`, 'price'); else if (!old) logAdd(`إضافة منتج «${saved.name}» (${deptName(saved.dept)})`, 'cat');
    closeModal(); render(); toast('انحفظ ✓'); return true; }
  if (a === 'catAdd') { const n = $('#newCat').value.trim(); if (!n) return true; const c = await DB.upsert('show_cats', { name: n, sort: S.cats.length, cover: '' }); S.cats.push(c); return render(), true; }
  if (a === 'catDel') { const c = S.cats.find(x => x.id === ds.id); if (!(await confirmBox(`حذف مناسبة «${c.name}»؟ التصاميم تبقى.`, 'حذف', true))) return true; await DB.remove('show_cats', c.id); S.cats = S.cats.filter(x => x !== c); return render(), true; }
  if (a === 'catMv') { const i = S.cats.findIndex(x => x.id === ds.id), j = i + +ds.d; if (j < 0 || j >= S.cats.length) return true; [S.cats[i], S.cats[j]] = [S.cats[j], S.cats[i]]; for (const [k, c] of S.cats.entries()) { c.sort = k; await DB.upsert('show_cats', c); } return render(), true; }
  if (a === 'catCov') { S._cov = ds.id; $('#covf').click(); return true; }
  if (a === 'cfgAdd') { S.cfg.cake[ds.k].push({ id: uid(), n: '', p: 0 }); await DB.upsert('settings', { id: 'cake', value: S.cfg.cake }); return render(), true; }
  if (a === 'cfgDel') { S.cfg.cake[ds.k].splice(+ds.i, 1); await DB.upsert('settings', { id: 'cake', value: S.cfg.cake }); return render(), true; }
  if (a === 'matAdd') { const n = $('#newMat').value.trim(); if (!n) return true; const m = await DB.upsert('materials', { name: n, unit: $('#newMatU').value, active: true, sort: S.mats.length }); S.mats.push(m); return render(), true; }
  if (a === 'matTog') { const m = matOf(ds.id); m.active = m.active === false; await DB.upsert('materials', m); return render(), true; }
  /* الأقسام */
  if (a === 'deptAdd') { const n = $('#newDept').value.trim(); if (!n) return true; const d = await DB.upsert('depts', { name: n, color: $('#newDeptC').value, sort: S.depts.length + 1, active: true }); S.depts.push(d); logAdd(`إضافة قسم إنتاج «${n}»`, 'sys'); return render(), true; }
  if (a === 'deptTog') { const d = deptOf(ds.id); d.active = d.active === false; await DB.upsert('depts', d); return render(), true; }
  /* المستخدمين */
  if (a === 'uNew') { if (!S.roles.length) return toast('سوّي دور أول من «الأدوار والصلاحيات»'), true; userForm(null); return true; }
  if (a === 'uEdit') { userForm(userOf(ds.id)); return true; }
  if (a === 'uTog') { const u = userOf(ds.id); if (u.active && !(await confirmBox(`إيقاف حساب «${u.full_name}»؟`, 'إيقاف', true))) return true; await DB.updateUser(u.id, { active: !u.active }); u.active = !u.active; logAdd(`${u.active ? 'تفعيل' : 'إيقاف'} حساب «${u.full_name}»`, 'usr'); return render(), true; }
  if (a === 'uSave') {
    const er = m => $('#uErr').innerHTML = `<div class="err">${esc(m)}</div>`, mp = MODE === 'cloud' ? 6 : 4, name = $('#uName').value.trim(), depts = $$('[data-udept]').filter(c => c.checked).map(c => c.dataset.udept);
    if (!name) return er('اكتب الاسم'), true; t.disabled = true;
    try { if (!ds.id) { const un = $('#uUser').value.trim().toLowerCase(), pw = $('#uPass').value.trim(), role = $('#uRole').value;
        if (!/^[a-z0-9._-]{3,}$/.test(un)) { t.disabled = false; return er('اسم المستخدم بالإنجليزي، 3 أحرف على الأقل، بدون مسافات'), true; } if (pw.length < mp) { t.disabled = false; return er(`كلمة المرور ${mp} أحرف على الأقل`), true; }
        const u = await DB.createUser({ username: un, password: pw, full_name: name, role, depts }); S.users.push(u); logAdd(`إضافة مستخدم «${name}» (${roleName(role)})`, 'usr'); toast(`انضاف ${name} ✓ · يدخل بـ ${un}`); }
      else { const u = await DB.updateUser(ds.id, { full_name: name, depts }); Object.assign(userOf(ds.id), u); const pw = $('#uPass') ? $('#uPass').value.trim() : ''; if (pw) { if (pw.length < mp) { t.disabled = false; return er('كلمة المرور قصيرة'), true; } await DB.setPassword(ds.id, pw); } if (ds.id === S.me.id) Object.assign(S.me, u); toast('انحفظ ✓'); }
    } catch (x) { t.disabled = false; return er(x.message), true; }
    closeModal(); render(); return true; }
  /* الأدوار */
  if (a === 'rNew') { roleForm(null); return true; }
  if (a === 'rEdit') { roleForm(roleOf(ds.id)); return true; }
  if (a === 'rSave') { const name = $('#rName').value.trim(), er = m => { $('#rErr').innerHTML = `<div class="err">${esc(m)}</div>`; $('.sheet').scrollTop = 0; }; if (!name) return er('اكتب اسم الدور'), true;
    if (S.roles.some(x => x.name === name && x.id !== ds.id)) return er('اكو دور بنفس الاسم'), true;
    const perms = {}; $$('[data-pk]').forEach(c => { if (c.checked) perms[c.dataset.pk] = true; });
    if (ds.id === S.me.role && !isOwner() && !perms.roles && !(await confirmBox('راح تشيل صلاحية الأدوار من دورك إنت. متأكد؟', 'نعم', true))) return true;
    const r = await DB.upsert('roles', { id: ds.id || 'r' + Date.now().toString(36), name, perms, sort: ds.id ? (roleOf(ds.id).sort || 0) : S.roles.length + 1 });
    const i = S.roles.findIndex(x => x.id === r.id); if (i >= 0) S.roles[i] = r; else S.roles.push(r); logAdd(`${ds.id ? 'تعديل' : 'إضافة'} دور «${name}»`, 'usr'); closeModal(); render(); toast('انحفظ الدور ✓'); return true; }
  if (a === 'rDel') { const n = S.users.filter(u => u.role === ds.id).length; if (n) return toast(`هذا الدور عليه ${n} مستخدم. غيّر دورهم أول`), true; if (!(await confirmBox('حذف هذا الدور؟', 'حذف', true))) return true; await DB.remove('roles', ds.id); S.roles = S.roles.filter(r => r.id !== ds.id); render(); return true; }
  /* الإعدادات */
  if (a === 'logoPick') { $('#logof').click(); return true; }
  if (a === 'logoDel') { delete S.cfg.shop.logo; await DB.upsert('settings', { id: 'shop', value: S.cfg.shop }); return render(), true; }
  if (a === 'bkSave') { await backupAll(); return true; }
  if (a === 'bkOld') { $('#bkf').value = ''; $('#bkf').click(); return true; }
  if (a === 'bkLegacy') { A().openLegacy(); return true; }
  if (a === 'licNew') { renderLic(true); return true; }
  if (a === 'lgRe') { S._logs = null; return render(), true; }
  if (a === 'chpw') { const p1 = $('#np1').value, mp = MODE === 'cloud' ? 6 : 4; if (p1.length < mp) return toast(`كلمة المرور ${mp} أحرف على الأقل`), true; if (p1 !== $('#np2').value) return toast('كلمتين المرور مو نفس الشي'), true; await DB.changeMyPassword(p1); $('#np1').value = $('#np2').value = ''; toast('تغيّرت كلمة المرور ✓'); return true; }
  if (a === 'resetDemo') { if (!(await confirmBox('إرجاع كل البيانات التجريبية من جديد؟', 'إرجاع', true))) return true; DB.resetDemo(); location.reload(); return true; }
});
H.change.push(async t => {
  if (t.id === 'dDate') { if (t.value) { S.ddate = t.value; render(); } return true; }
  if (t.id === 'rFrom' || t.id === 'rTo') { if (t.value) { S[t.id === 'rFrom' ? 'rfrom' : 'rto'] = t.value; if (S.rfrom > S.rto) [S.rfrom, S.rto] = [S.rto, S.rfrom]; render(); } return true; }
  if (t.id === 'itBook') { readItemForm(); S.itd.book = t.checked; if (t.checked && !(S.itd.sizes || []).length) S.itd.sizes = [{ n: '', p: +S.itd.price || 0 }]; drawItemForm(); return true; }
  if (t.id === 'itImgF' && t.files[0]) { S.itd.img = await shrink(t.files[0], 1000); drawItemForm(); return true; }
  if (t.id === 'covf' && t.files[0]) { const c = S.cats.find(x => x.id === S._cov); c.cover = await shrink(t.files[0], 900); await DB.upsert('show_cats', c); render(); return true; }
  if (t.dataset.catn) { const c = S.cats.find(x => x.id === t.dataset.catn); c.name = t.value.trim() || c.name; await DB.upsert('show_cats', c); toast('انحفظ'); return true; }
  if (t.dataset.cfg || t.dataset.cfgc) { const [k, i, f] = (t.dataset.cfg || t.dataset.cfgc).split('.'), o = S.cfg.cake[k][+i]; o[f] = t.dataset.cfgc ? (t.checked ? 1 : 0) : f === 'p' ? (+t.value || 0) : t.value.trim(); await DB.upsert('settings', { id: 'cake', value: S.cfg.cake }); toast('انحفظ'); return true; }
  if (t.dataset.mk) { const m = matOf(t.closest('[data-mid]').dataset.mid), v = t.value.trim(); if (!v) return true; m[t.dataset.mk] = v; await DB.upsert('materials', m); toast('انحفظ'); return true; }
  if (t.dataset.deptn || t.dataset.deptc) { const d = deptOf(t.dataset.deptn || t.dataset.deptc); if (t.dataset.deptn) d.name = t.value.trim() || d.name; else d.color = t.value; await DB.upsert('depts', d); toast('انحفظ'); return true; }
  if (t.dataset.dchef) { const [d, u] = t.dataset.dchef.split('|'), us = userOf(u), L = new Set(us.depts || []); t.checked ? L.add(d) : L.delete(d); us.depts = [...L]; await DB.updateUser(u, { depts: us.depts }); t.closest('.pchk2').classList.toggle('on', t.checked); logAdd(`${t.checked ? 'ربط' : 'فك'} ${us.full_name} ${t.checked ? 'بـ' : 'من'} قسم ${deptName(d)}`, 'usr'); toast('انحفظ'); return true; }
  if (t.dataset.udept) { t.closest('.pchk2').classList.toggle('on', t.checked); return true; }
  if (t.dataset.urole) { const u = userOf(t.dataset.urole); if (t.value === OWNER && !(await confirmBox(`تنطي «${u.full_name}» صلاحية المدير الرئيسي؟`, 'نعم'))) { t.value = u.role; return true; }
    await DB.updateUser(u.id, { role: t.value }); u.role = t.value; logAdd(`تغيير دور «${u.full_name}» إلى ${roleName(t.value)}`, 'usr'); toast('صار دور ' + u.full_name + ': ' + roleName(t.value)); return true; }
  if (t.dataset.shop) { S.cfg.shop[t.dataset.shop] = t.value.trim(); await DB.upsert('settings', { id: 'shop', value: S.cfg.shop }); toast('انحفظ'); return true; }
  if (t.id === 'logof' && t.files[0]) { S.cfg.shop.logo = await shrink(t.files[0], 500, 'image/png'); await DB.upsert('settings', { id: 'shop', value: S.cfg.shop }); render(); return true; }
  if (t.id === 'bkf' && t.files[0]) { await importOldCake(t.files[0]); return true; }
  if (t.id === 'lgu') { S.lgU = t.value; render(); return true; }
  if (t.id === 'kic') { S.kic = t.value; render(); return true; }
  if (t.dataset.lkc) { await saveLook({ [t.dataset.lkc]: t.value }); render(); return true; }
  if (t.dataset.lkr) { await saveLook({ [t.dataset.lkr]: +t.value }); render(); return true; }
  if (t.id === 'lkAuto') { await saveLook({ auto: t.checked }); render(); return true; }

});
H.input.push(t => { if (t.id === 'kiq') { S.kiq = t.value; render().then(() => { const j = $('#kiq'); if (j) { j.focus(); j.setSelectionRange(j.value.length, j.value.length); } }); return true; }
  if (t.id === 'lgq') { S.lgQ = t.value; render().then(() => { const j = $('#lgq'); if (j) { j.focus(); j.setSelectionRange(j.value.length, j.value.length); } }); return true; } });
