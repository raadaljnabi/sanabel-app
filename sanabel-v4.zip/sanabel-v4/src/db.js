/* ===== طبقة البيانات: Firebase (السيرفر) أو نسخة تجريبية على الجهاز ===== */
const CFG = window.APP_CONFIG || {};
const FORCE_DEMO = /[?&]demo\b/.test(location.search);
// demo: تجريبي على الجهاز · cloud: Firebase · offline: مكتبة Firebase ما انحملت (ماكو إنترنت بأول تشغيل)
const MODE = (FORCE_DEMO || !(CFG.firebase && CFG.firebase.apiKey)) ? 'demo' : (window.firebase ? 'cloud' : 'offline');
const uid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID().replace(/-/g, '').slice(0, 20) : 'id' + Math.random().toString(36).slice(2) + Date.now().toString(36);
const clone = o => JSON.parse(JSON.stringify(o));
const pad2 = n => String(n).padStart(2, '0');
const fmtD = d => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
const todayStr = () => fmtD(new Date());
const addDays = (s, n) => { const d = new Date(s + 'T12:00'); d.setDate(d.getDate() + n); return fmtD(d); };
const WASTE_REASONS = ['محروق', 'منتهي الصلاحية', 'مكسور أو تالف', 'ضيافة', 'أكل موظفين', 'أخرى'];
const TABLES = ['profiles', 'roles', 'depts', 'items', 'show_cats', 'materials', 'settings', 'shifts', 'kitchen_orders', 'wh_requests', 'orders', 'logs'];

/* صورة كيكة مرسومة للنسخة التجريبية */
function cakeSvg(a, b) {
  const s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}" stop-opacity=".35"/><stop offset="1" stop-color="${b}" stop-opacity=".35"/></linearGradient></defs><rect width="800" height="600" fill="#f7ece6"/><rect width="800" height="600" fill="url(#g)"/><ellipse cx="400" cy="520" rx="290" ry="34" fill="#fff"/><rect x="170" y="380" width="460" height="130" rx="22" fill="${a}"/><rect x="230" y="270" width="340" height="120" rx="22" fill="${b}"/><rect x="290" y="170" width="220" height="110" rx="22" fill="${a}"/><path d="M170 400q30 50 60 0t60 0 60 0 60 0 60 0 60 0 60 0v-30H170z" fill="#fff"/><path d="M230 290q28 44 56 0t56 0 56 0 56 0 56 0v-24H230z" fill="#fff"/><g fill="#e53b5b"><circle cx="340" cy="160" r="16"/><circle cx="400" cy="150" r="16"/><circle cx="460" cy="160" r="16"/></g></svg>`;
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s);
}
const defaultRoles = () => DEFAULT_ROLES.map(r => ({ id: r.id, name: r.name, sort: r.sort, perms: Object.fromEntries(r.perms.map(k => [k, true])) }));
const defaultCakeCfg = () => ({
  fills: [{ id: 'f1', n: 'فانيلا', p: 0 }, { id: 'f2', n: 'شوكولاتة', p: 0 }, { id: 'f3', n: 'فراولة', p: 0 }, { id: 'f4', n: 'لوتس', p: 2000 }, { id: 'f5', n: 'نوتيلا', p: 3000 }, { id: 'f6', n: 'فستق', p: 5000 }],
  addons: [{ id: 'a1', n: 'شموع', p: 2000, cnt: 1 }, { id: 'a2', n: 'كتابة اسم على الكيك', p: 0 }, { id: 'a3', n: 'طباعة صورة على الكيك', p: 10000, ph: 1 }, { id: 'a4', n: 'تغليف هدية', p: 5000 }],
  fillReq: true, cap: 0,
});
function defaultCatalog() {
  const D = { pastry: 'd_pastry', sweets: 'd_sweets', cake: 'd_cake' };
  const items = [['فطيرة جبن', 'قطعة', 'pastry', 1000], ['فطيرة لحم', 'قطعة', 'pastry', 1500], ['فطيرة سبانخ', 'قطعة', 'pastry', 1000], ['فطيرة زعتر', 'قطعة', 'pastry', 750], ['لحم بعجين', 'قطعة', 'pastry', 1000], ['سمبوسة', 'قطعة', 'pastry', 500], ['كرواسون', 'قطعة', 'pastry', 1000], ['كاهي', 'قطعة', 'pastry', 1000],
    ['كليجة', 'كغم', 'sweets', 12000], ['كعك بسمسم', 'كغم', 'sweets', 8000], ['بقصم', 'كغم', 'sweets', 7000], ['معمول', 'كغم', 'sweets', 15000], ['قطعة كيك شوكولاتة', 'قطعة', 'cake', 3000], ['قطعة كيك فراولة', 'قطعة', 'cake', 3000]]
    .map((x, i) => ({ id: uid(), name: x[0], unit: x[1], dept: D[x[2]], price: x[3], active: true, sort: i, jard: true, sell: true }));
  const materials = [['طحين', 'كغم'], ['سكر', 'كغم'], ['زبدة', 'كغم'], ['دهن', 'كغم'], ['جبن', 'كغم'], ['لحم مثروم', 'كغم'], ['سبانخ', 'كغم'], ['زعتر', 'كغم'], ['سمسم', 'كغم'], ['تمر', 'كغم'], ['خميرة', 'كيس'], ['بيض', 'طبقة'], ['حليب', 'لتر'], ['زيت', 'لتر'], ['كريمة', 'لتر'], ['شوكولاتة', 'كغم']]
    .map((x, i) => ({ id: uid(), name: x[0], unit: x[1], active: true, sort: i }));
  const settings = [{ id: 'shift_times', value: { am: { start: '07:00', end: '15:00' }, pm: { start: '15:00', end: '23:00' }, remind: 15 } }, { id: 'schedule', value: { weekly: {}, overrides: {} } },
    { id: 'cake', value: defaultCakeCfg() }, { id: 'shop', value: { slogan: 'أطيب الكيك والمعجنات', cur: 'د.ع', phone: '', addr: '', terms: 'العربون غير قابل للاسترجاع بعد بدء التحضير. يرجى الاستلام بالموعد المحدد.', rcNote: 'شكراً لاختياركم 🌾' } }];
  return { items, materials, settings };
}

/* تصاميم كيك ومناسبات افتراضية (تنزرع أول مرة حتى يبين الشغل) */
function defaultCakeDesigns(dept) {
  const cats = [['أعياد ميلاد'], ['أعراس'], ['خطوبة'], ['مواليد'], ['تخرج']].map((x, i) => ({ id: uid(), name: x[0], sort: i, cover: '' }));
  const B = [['كيك الفراولة', 'إسفنج فانيلا بكريمة طازجة وفراولة', '#e8577e', '#f7c6d4', 25000, 0], ['كيك الشوكولاتة', 'طبقات شوكولاتة بلجيكية مع صوص غناش', '#5b3424', '#a0674b', 30000, 0],
    ['ريد فيلفيت', 'كيك ريد فيلفيت بكريمة الجبن', '#b3212f', '#f3e4dc', 30000, 0], ['كيك اللوتس', 'كريمة لوتس وقطع بسكويت مقرمشة', '#c27c3e', '#ead2b3', 32000, 0], ['كيك الفستق', 'كريمة فستق حلبي', '#7fa645', '#e6eccf', 35000, 0],
    ['كيك الكراميل', 'كراميل مملّح بطبقات كريمة خفيفة', '#d08a2c', '#f6dfb6', 28000, 0], ['كيك عرس طابقين', 'تصميم أبيض بورد طبيعي', '#f3e4dc', '#e8c9b8', 120000, 1], ['كيك عرس 3 طوابق', 'تصميم ملكي بتفاصيل ذهبية', '#e9d8b5', '#fff6e8', 220000, 1],
    ['كيك خطوبة', 'قلب وردي بكريمة', '#e86a92', '#f5b942', 45000, 2], ['كيك مواليد ولد', 'أزرق فاتح', '#7bb4e8', '#e3f0fb', 35000, 3], ['كيك مواليد بنت', 'وردي فاتح', '#f08fc0', '#fde3ef', 35000, 3], ['كيك تخرج', 'قبعة تخرج وشهادة', '#3a3a6a', '#e8e3f5', 40000, 4]];
  const items = B.map((x, i) => ({ id: uid(), name: x[0], desc: x[1], img: cakeSvg(x[2], x[3]), unit: 'قطعة', dept, cat: cats[x[5]].id, book: true, jard: false, sell: false, active: true, sort: 100 + i,
    sizes: x[5] === 1 ? [{ n: 'حسب العدد', p: x[4] }] : [{ n: 'صغير (6 أشخاص)', p: x[4] }, { n: 'وسط (12 شخص)', p: x[4] + 15000 }, { n: 'كبير (20 شخص)', p: x[4] + 35000 }] }));
  return { cats, items };
}
function seedData() {
  const cat = defaultCatalog(); const items = cat.items;
  const CD = defaultCakeDesigns('d_cake'), show_cats = CD.cats; items.push(...CD.items);
  const u = (username, full_name, role, depts) => ({ id: uid(), username, password: '1234', full_name, role, depts: depts || [], active: true, created_at: new Date().toISOString() });
  const profiles = [u('admin', 'مدير النظام', 'manager'), u('ahmed', 'أحمد كريم', 'hall'), u('zainab', 'زينب علي', 'hall'), u('haider', 'الشيف حيدر', 'chef', ['d_pastry']), u('ali', 'الشيف علي', 'cake_chef', ['d_cake', 'd_sweets']),
    u('rana', 'الشيف رنا', 'cake_chef', ['d_cake']), u('abbas', 'عباس حسن', 'store'), u('sara', 'سارة أحمد', 'cashier'), u('noor', 'نور حسين', 'supervisor')];
  const P = n => profiles.find(p => p.username === n);
  const hall = [P('ahmed'), P('zainab')];
  const weekly = { [hall[0].id]: [0, 1, 2, 3, 4, 5, 6].map(d => d === 5 ? 'pm' : 'am'), [hall[1].id]: [0, 1, 2, 3, 4, 5, 6].map(d => d === 5 ? 'am' : 'pm') };
  cat.settings.find(s => s.id === 'schedule').value.weekly = weekly;
  const db = { profiles, roles: defaultRoles(), depts: DEFAULT_DEPTS.map(d => ({ ...d, active: true })), items, show_cats, materials: cat.materials, settings: cat.settings, shifts: [], kitchen_orders: [], wh_requests: [], orders: [], logs: [], meta: { seq: 1000 } };
  const r = (a, b) => a + Math.random() * (b - a);
  const jitems = items.filter(i => i.jard);
  const avg = it => it.unit === 'كغم' ? 3 : it.dept === 'd_cake' ? 8 : 30;
  const empFor = (d, s) => hall.find(h => weekly[h.id][new Date(d + 'T12:00').getDay()] === s) || hall[0];
  const chefFor = dept => profiles.find(p => p.depts.includes(dept));
  let carry = {};
  for (let k = 7; k >= 0; k--) {
    const d = addDays(todayStr(), -k);
    (k ? ['am', 'pm'] : ['am']).forEach(s => {
      const emp = empFor(d, s); const rows = {}; const recvLines = {};
      jitems.forEach(it => {
        const w = it.unit === 'كغم'; let open = carry[it.id] || 0;
        if (!w && open > 2 && Math.random() < .06) open -= 1;
        const recv = s === 'am' ? (w ? Math.round(avg(it) * r(1.1, 1.4) * 2) / 2 : Math.round(avg(it) * r(1.1, 1.4))) : 0;
        if (recv) recvLines[it.id] = recv;
        const avail = open + recv;
        const sold = w ? Math.round(avail * (s === 'am' ? r(.5, .65) : r(.75, .95)) * 4) / 4 : Math.round(avail * (s === 'am' ? r(.5, .65) : r(.75, .95)));
        const waste = (!w && Math.random() < .3) ? 1 : 0;
        const close = Math.max(0, Math.round((avail - sold - waste) * 100) / 100);
        rows[it.id] = { open, recv: recv || null, waste: waste || null, wasteBy: waste ? { [WASTE_REASONS[Math.floor(Math.random() * 5)]]: waste } : undefined, close: (k === 0 && it.sort > 6) ? null : close };
        carry[it.id] = close;
      });
      const at = d + 'T' + (s === 'am' ? '07:05' : '15:05') + ':00';
      db.shifts.push({ date: d, shift: s, employee_id: emp.id, employee_name: emp.full_name, rows, opened: true, opened_at: at, opened_by_name: emp.full_name,
        receipts: s === 'am' ? [{ id: uid(), at: d + 'T07:20:00', by_name: emp.full_name, order_id: null, lines: recvLines }] : [],
        closed: k > 0, closed_at: k > 0 ? d + 'T' + (s === 'am' ? '15:00' : '23:00') + ':00' : null, updated_at: at });
    });
    if (!k) break;
    ['d_pastry', 'd_sweets', 'd_cake'].forEach(dept => { const ch = chefFor(dept);
      db.kitchen_orders.push({ id: uid(), for_date: addDays(d, 1), dept, created_by: hall[1].id, created_by_name: hall[1].full_name, chef_id: ch.id,
        lines: Object.fromEntries(jitems.filter(i => i.dept === dept).map(it => [it.id, it.unit === 'كغم' ? 3 : Math.round(avg(it) * 1.2)])), notes: '', status: 'done',
        created_at: d + 'T23:10:00', received_at: addDays(d, 1) + 'T07:20:00', received_by_name: hall[0].full_name }); });
    const ch = chefFor(k % 2 ? 'd_pastry' : 'd_cake'), M = db.materials;
    const ml = { [M[0].id]: 40 + k, [M[2].id]: 4, [M[4].id]: 6 };
    db.wh_requests.push({ id: uid(), date: d, chef_id: ch.id, chef_name: ch.full_name, lines: ml, notes: '', status: 'issued', issued: { ...ml }, issued_by_name: 'عباس حسن', issued_at: d + 'T05:30:00', created_at: d + 'T05:00:00' });
  }
  const pas = jitems.filter(i => i.dept === 'd_pastry');
  db.kitchen_orders.push({ id: uid(), for_date: todayStr(), dept: 'd_pastry', created_by: hall[0].id, created_by_name: hall[0].full_name, chef_id: P('haider').id,
    lines: { [pas[0].id]: 30, [pas[1].id]: 25, [pas[5].id]: 20 }, notes: 'دفعة الظهر', status: 'prod', created_at: new Date(Date.now() - 4 * 3600e3).toISOString() });
  db.kitchen_orders.push({ id: uid(), for_date: addDays(todayStr(), 1), dept: 'd_cake', created_by: hall[1].id, created_by_name: hall[1].full_name, chef_id: P('rana').id,
    lines: Object.fromEntries(jitems.filter(i => i.dept === 'd_cake').map(it => [it.id, 10])), notes: 'للعرض', status: 'new', created_at: new Date(Date.now() - 3600e3).toISOString() });
  db.wh_requests.push({ id: uid(), date: todayStr(), chef_id: P('haider').id, chef_name: 'الشيف حيدر', lines: { [db.materials[0].id]: 50, [db.materials[4].id]: 8 }, notes: '', status: 'new', issued: null, created_at: new Date().toISOString() });
  // طلبات زبائن تجريبية
  const tm = addDays(todayStr(), 1), mam = items.find(i => i.name === 'معمول'), kl = items.find(i => i.name === 'كليجة'), pz = items.find(i => i.name === 'فطيرة جبن');
  const ck = n => items.find(i => i.name === n), cl = (n, sz, p, f, adds, txt) => ({ id: uid(), iid: ck(n).id, name: n, dept: 'd_cake', qty: 1, unit: 'قطعة', size: sz, price: p, fill: f, adds: adds || [], txt: txt || '' });
  const co = (no, name, phone, due, line, dep, st, extra) => { const o = { id: uid(), no, kind: 'cake', at: Date.now() - (1010 - no) * 3600e3, by: 'سارة أحمد', name, phone, due, dep, st, note: '', lines: [line], chefs: { d_cake: P('rana').id }, prod: { d_cake: st === 'new' ? 'new' : st === 'prep' ? 'prep' : 'sent' }, prodLog: st === 'ready' ? [{ d: 'd_cake', st: 'sent', at: Date.now() - 3600e3, by: 'الشيف رنا' }] : [], ...(extra || {}) }; o.total = o.lines.reduce((s, l) => s + (l.price + (l.fill ? l.fill.p : 0)) * l.qty + (l.adds || []).reduce((a, x) => a + x.p * (x.c || 1), 0), 0); return o; };
  db.orders.push(co(1003, 'رهف علي', '07709871234', tm + 'T17:00', cl('كيك الشوكولاتة', 'وسط (12 شخص)', 45000, { n: 'نوتيلا', p: 3000 }, [{ n: 'شموع', p: 2000, c: 2 }], 'عيد ميلاد سعيد يا رهف'), 20000, 'new'));
  db.orders.push(co(1004, 'أم علي', '07809998877', todayStr() + 'T19:00', cl('كيك اللوتس', 'وسط (12 شخص)', 47000, { n: 'لوتس', p: 2000 }), 15000, 'prep'));
  db.orders.push(co(1005, 'حسن كريم', '07712223344', todayStr() + 'T14:00', cl('كيك تخرج', 'كبير (20 شخص)', 75000, { n: 'فانيلا', p: 0 }, [], 'مبروك التخرج يا علي'), 30000, 'ready'));
  { const x = co(1007, 'مريم جاسم', '07733334444', todayStr() + 'T21:00', cl('كيك الفراولة', 'وسط (12 شخص)', 40000, { n: 'فراولة', p: 0 }, [], 'Happy Birthday'), 15000, 'prep'); x.prod.d_cake = 'ready'; db.orders.push(x); }
  db.orders.push(co(1006, 'سجى أحمد', '07505556677', addDays(todayStr(), -1) + 'T18:00', cl('كيك الفراولة', 'صغير (6 أشخاص)', 25000, { n: 'فراولة', p: 0 }), 10000, 'done', { coll: 15000, debt: 0, disc: 0, doneAt: Date.now() - 20 * 3600e3, collBy: 'سارة أحمد' }));
  db.orders.push({ id: uid(), no: 1001, kind: 'special', at: Date.now() - 5 * 3600e3, by: 'سارة أحمد', name: 'زهراء محمد', phone: '07701234567', due: tm + 'T17:00', dep: 25000, total: 50000, st: 'new', note: 'عزيمة 50 شخص',
    lines: [{ id: uid(), iid: pz.id, name: pz.name, dept: 'd_pastry', qty: 50, unit: 'قطعة', price: 1000 }], chefs: { d_pastry: P('haider').id }, prod: { d_pastry: 'new' } });
  db.orders.push({ id: uid(), no: 1002, kind: 'special', at: Date.now() - 2 * 3600e3, by: 'سارة أحمد', name: 'أبو حسين', phone: '07801112233', due: tm + 'T12:00', dep: 30000, total: 69000, st: 'prep', note: 'تغليف علب هدايا',
    lines: [{ id: uid(), iid: mam.id, name: mam.name, dept: 'd_sweets', qty: 3, unit: 'كغم', price: 15000 }, { id: uid(), iid: kl.id, name: kl.name, dept: 'd_sweets', qty: 2, unit: 'كغم', price: 12000 }],
    chefs: { d_sweets: P('ali').id }, prod: { d_sweets: 'prep' } });
  db.meta.seq = 1007;
  return db;
}

const LocalDB = {
  key: 'sanabel_v2', skey: 'sanabel_v2_session', _db: null, canResetOthers: true,
  token() { return Promise.resolve(null); },
  db() {
    if (!this._db) { try { const s = localStorage.getItem(this.key); if (s) this._db = JSON.parse(s); } catch (e) {}
      if (!this._db) { this._db = seedData(); this._save(); } }
    return this._db;
  },
  _save() { try { localStorage.setItem(this.key, JSON.stringify(this._db)); } catch (e) { toast('ذاكرة الجهاز ممتلئة'); } },
  _pub(p) { const { password, ...rest } = p; return clone(rest); },
  async login(username, password) {
    const p = this.db().profiles.find(x => x.username === username.trim().toLowerCase() && x.password === password);
    if (!p) throw new Error('اسم المستخدم أو كلمة المرور غير صحيحة');
    if (!p.active) throw new Error('هذا الحساب موقوف، راجع المدير');
    try { localStorage.setItem(this.skey, p.id); } catch (e) {}
    return this._pub(p);
  },
  async session() { let id = null; try { id = localStorage.getItem(this.skey); } catch (e) {} const p = id && this.db().profiles.find(x => x.id === id && x.active); return p ? this._pub(p) : null; },
  async logout() { try { localStorage.removeItem(this.skey); } catch (e) {} },
  async needsSetup() { return false; },
  async list(t, f = {}) {
    let rows = this.db()[t] || [];
    if (f.field && f.from) rows = rows.filter(x => (x[f.field] || '') >= f.from);
    if (f.field && f.to) rows = rows.filter(x => (x[f.field] || '') <= f.to);
    return t === 'profiles' ? rows.map(p => this._pub(p)) : clone(rows);
  },
  async get(t, id) { const r = (this.db()[t] || []).find(x => x.id === id); return r ? clone(r) : null; },
  async upsert(t, o) {
    const a = this.db()[t] || (this.db()[t] = []); o = clone(o); let i;
    if (t === 'shifts') i = a.findIndex(x => x.date === o.date && x.shift === o.shift);
    else { if (!o.id) o.id = uid(); i = a.findIndex(x => x.id === o.id); }
    if (i >= 0) a[i] = { ...a[i], ...o }; else { if (!o.created_at && t !== 'shifts') o.created_at = new Date().toISOString(); a.push(o); }
    this._save(); return clone(i >= 0 ? a[i] : o);
  },
  async remove(t, id) { const db = this.db(); db[t] = (db[t] || []).filter(x => x.id !== id); this._save(); },
  async nextNo() { const m = this.db().meta || (this.db().meta = { seq: 1000 }); m.seq++; this._save(); return m.seq; },
  async bumpNo(n) { const m = this.db().meta || (this.db().meta = { seq: 1000 }); m.seq = Math.max(m.seq, n); this._save(); },
  async photo(id) { const p = (this.db().ophotos || {})[id]; return p || null; },
  async setPhoto(id, d) { const db = this.db(); db.ophotos = db.ophotos || {}; db.ophotos[id] = d; this._save(); },
  async createUser({ username, password, full_name, role, depts }) {
    username = username.trim().toLowerCase();
    if (this.db().profiles.some(p => p.username === username)) throw new Error('اسم المستخدم مستخدم سابقاً');
    const p = { id: uid(), username, password, full_name, role, depts: depts || [], active: true, created_at: new Date().toISOString() };
    this.db().profiles.push(p); this._save(); return this._pub(p);
  },
  async updateUser(id, patch) { const p = this.db().profiles.find(x => x.id === id); Object.assign(p, patch); this._save(); return this._pub(p); },
  async setPassword(id, pw) { const p = this.db().profiles.find(x => x.id === id); p.password = pw; this._save(); },
  async changeMyPassword(pw) { const s = await this.session(); if (s) await this.setPassword(s.id, pw); },
  onChange(cb) { window.addEventListener('storage', e => { if (e.key === this.key) { this._db = null; cb('*'); } }); },
  stopLive() {},
  resetDemo() { try { localStorage.removeItem(this.key); localStorage.removeItem(this.skey); } catch (e) {} this._db = null; },
};

/* ===== Firebase (Auth + Firestore) ===== */
const FIRE_ERR = e => {
  const c = (e && e.code) || '';
  if (/wrong-password|invalid-credential|user-not-found|invalid-email|invalid-login/.test(c)) return 'اسم المستخدم أو كلمة المرور غير صحيحة';
  if (/too-many-requests/.test(c)) return 'محاولات كثيرة، انتظر دقائق وحاول مرة ثانية';
  if (/network|unavailable/.test(c)) return 'ماكو اتصال بالإنترنت';
  if (/email-already-in-use/.test(c)) return 'اسم المستخدم مستخدم سابقاً';
  if (/weak-password/.test(c)) return 'كلمة المرور ضعيفة، 6 أحرف على الأقل';
  if (/requires-recent-login/.test(c)) return 'لأمان حسابك: سجّل خروج ودخول، وبعدها غيّر كلمة المرور';
  if (/permission-denied/.test(c)) return 'ما عندك صلاحية لهالشي';
  return (e && e.message) || 'صار خطأ';
};
const FireDB = {
  canResetOthers: false, cloud: true,
  token(force) { const u = this.auth && this.auth.currentUser; return u ? u.getIdToken(!!force) : Promise.resolve(null); },
  init() { this.app = firebase.initializeApp(CFG.firebase); this.auth = firebase.auth(); this.fs = firebase.firestore();
    try { this.fs.enablePersistence({ synchronizeTabs: true }).catch(() => {}); } catch (e) {} },
  email(u) { return u.trim().toLowerCase() + '@' + (CFG.emailDomain || 'sanabel.app'); },
  docId(t, o) { return t === 'shifts' ? o.date + '_' + o.shift : o.id; },
  async profile(uidv) {
    let d; try { d = await this.fs.collection('profiles').doc(uidv).get(); } catch (e) { throw new Error(FIRE_ERR(e)); }
    if (!d.exists) { await this.auth.signOut(); throw new Error('الحساب غير مربوط بصلاحية، راجع المدير'); }
    const p = { id: uidv, ...d.data() };
    if (!p.active) { await this.auth.signOut(); throw new Error('هذا الحساب موقوف، راجع المدير'); }
    return p;
  },
  async login(username, password) { let cred; try { cred = await this.auth.signInWithEmailAndPassword(this.email(username), password); } catch (e) { throw new Error(FIRE_ERR(e)); } return this.profile(cred.user.uid); },
  session() { return new Promise(res => { const un = this.auth.onAuthStateChanged(async u => { un(); if (!u) return res(null); try { res(await this.profile(u.uid)); } catch (e) { res(null); } }); }); },
  async logout() { this.stopLive(); await this.auth.signOut(); },
  async needsSetup() { try { const d = await this.fs.collection('meta').doc('setup').get(); return !d.exists; } catch (e) { return false; } },
  async setupFirstAdmin({ username, password, full_name }) {
    let cred; try { cred = await this.auth.createUserWithEmailAndPassword(this.email(username), password); } catch (e) { throw new Error(FIRE_ERR(e)); }
    const id = cred.user.uid, now = new Date().toISOString(), b = this.fs.batch();
    b.set(this.fs.collection('profiles').doc(id), { username: username.trim().toLowerCase(), full_name, role: OWNER, depts: [], active: true, created_at: now });
    b.set(this.fs.collection('meta').doc('setup'), { at: now, by: id });
    try { await b.commit(); } catch (e) { try { await cred.user.delete(); } catch (_) {} throw new Error(FIRE_ERR(e)); }
    const cat = defaultCatalog(), b2 = this.fs.batch();
    cat.items.forEach(o => b2.set(this.fs.collection('items').doc(o.id), o));
    cat.materials.forEach(o => b2.set(this.fs.collection('materials').doc(o.id), o));
    cat.settings.forEach(o => b2.set(this.fs.collection('settings').doc(o.id), o));
    try { await b2.commit(); } catch (e) {}
    return this.profile(id);
  },
  async list(t, f = {}) {
    let q = this.fs.collection(t);
    if (f.field && f.from) q = q.where(f.field, '>=', f.from);
    if (f.field && f.to) q = q.where(f.field, '<=', f.to);
    try { const s = await q.get(); return s.docs.map(d => ({ ...d.data(), id: d.id })); } catch (e) { throw new Error(FIRE_ERR(e)); }
  },
  async get(t, id) { try { const d = await this.fs.collection(t).doc(id).get(); return d.exists ? { ...d.data(), id: d.id } : null; } catch (e) { throw new Error(FIRE_ERR(e)); } },
  async upsert(t, o) {
    o = clone(o); if (t !== 'shifts' && !o.id) o.id = uid();
    if (!o.created_at && ['kitchen_orders', 'wh_requests'].includes(t)) o.created_at = new Date().toISOString();
    const id = this.docId(t, o), data = { ...o }; if (t === 'shifts') delete data.id;
    try { await this.fs.collection(t).doc(id).set(data, { merge: true }); } catch (e) { throw new Error(FIRE_ERR(e)); }
    return t === 'shifts' ? o : { ...o, id };
  },
  async remove(t, id) { try { await this.fs.collection(t).doc(id).delete(); } catch (e) { throw new Error(FIRE_ERR(e)); } },
  async nextNo() {
    const ref = this.fs.collection('meta').doc('counter');
    try { return await this.fs.runTransaction(async tx => { const d = await tx.get(ref); const n = ((d.exists && d.data().seq) || 1000) + 1; tx.set(ref, { seq: n }, { merge: true }); return n; }); }
    catch (e) { return null; }
  },
  async bumpNo(n) { const ref = this.fs.collection('meta').doc('counter');
    try { await this.fs.runTransaction(async tx => { const d = await tx.get(ref); const c = (d.exists && d.data().seq) || 1000; if (n > c) tx.set(ref, { seq: n }, { merge: true }); }); } catch (e) {} },
  async photo(id) { try { const d = await this.fs.collection('ophotos').doc(id).get(); return d.exists ? d.data().d : null; } catch (e) { return null; } },
  async setPhoto(id, d) { await this.fs.collection('ophotos').doc(id).set({ d }); },
  async createUser({ username, password, full_name, role, depts }) {
    const sec = firebase.apps.find(a => a.name === 'secondary') || firebase.initializeApp(CFG.firebase, 'secondary');
    let cred; try { cred = await sec.auth().createUserWithEmailAndPassword(this.email(username), password); } catch (e) { throw new Error(FIRE_ERR(e)); }
    try { await sec.auth().signOut(); } catch (e) {}
    const p = { username: username.trim().toLowerCase(), full_name, role, depts: depts || [], active: true, created_at: new Date().toISOString() };
    try { await this.fs.collection('profiles').doc(cred.user.uid).set(p); } catch (e) { throw new Error(FIRE_ERR(e)); }
    return { id: cred.user.uid, ...p };
  },
  async updateUser(id, patch) { try { await this.fs.collection('profiles').doc(id).update(patch); } catch (e) { throw new Error(FIRE_ERR(e)); } const d = await this.fs.collection('profiles').doc(id).get(); return { id, ...d.data() }; },
  async setPassword() { throw new Error('تغيير كلمة مرور موظف ثاني ما يصير من التطبيق'); },
  async changeMyPassword(pw) { try { await this.auth.currentUser.updatePassword(pw); } catch (e) { throw new Error(FIRE_ERR(e)); } },
  _uns: [],
  stopLive() { this._uns.forEach(u => { try { u(); } catch (e) {} }); this._uns = []; },
  onChange(cb) {
    this.stopLive();
    const from = addDays(todayStr(), -45);
    const watch = [['kitchen_orders', 'for_date'], ['wh_requests', 'date'], ['shifts', 'date'], ['orders'], ['profiles'], ['roles'], ['depts'], ['items'], ['show_cats'], ['materials'], ['settings']];
    watch.forEach(([t, field]) => {
      let q = this.fs.collection(t); if (field) q = q.where(field, '>=', from);
      let first = true;
      this._uns.push(q.onSnapshot(s => { if (first) { first = false; return; } if (s.metadata.hasPendingWrites) return; cb(t, s.docs.map(d => ({ ...d.data(), id: d.id }))); }, () => {}));
    });
  },
};
const DB = MODE === 'cloud' ? FireDB : LocalDB;
if (MODE === 'cloud') FireDB.init();
