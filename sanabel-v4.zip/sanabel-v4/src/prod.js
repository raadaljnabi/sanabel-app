/* ===== الإنتاج: كل شيف يشوف شغله بس، ويضغط بلشت ← جهزت ← سلّمت ===== */
OST.ready = 'جاهزة بالمطبخ'; OST.sent = 'بانتظار الاستلام';
const PST = { new: 'جديد', prep: 'بلشت', ready: 'جهزت', sent: 'سلّمت' };
/* أقسام الكيك: قسم d_cake + أي قسم بي تصاميم كيك + أي قسم معلّم «كيك» */
const cakeDepts = () => new Set(['d_cake', ...bookItems().map(i => i.dept).filter(Boolean), ...S.depts.filter(d => d.cake).map(d => d.id)]);
const poSt = s => s === 'prod' ? 'prep' : s === 'ready' ? 'ready' : s === 'sent' ? 'sent' : s === 'done' ? 'sent' : 'new';
const isToday = x => x && fmtD(new Date(x)) === todayStr();
/* كل شغلة إنتاج: طلبية صالة لقسم واحد، أو جزء قسم واحد من طلب زبون */
function prodJobs() {
  const J = [];
  S.porders.forEach(o => { const st = poSt(o.status); if (st === 'sent' && !isToday(o.sent_at || o.received_at)) return;
    J.push({ k: 'po:' + o.id, kind: 'po', dept: o.dept || '', chef: o.chef_id, st, due: o.for_date + 'T07:00', o, at: o.sent_at || o.received_at,
      title: 'طلبية الصالة' + (o.status === 'done' ? ' · استلمتها الصالة' : ''), lines: Object.entries(o.lines || {}).filter(([, q]) => q > 0).map(([id, q]) => ({ name: itemOf(id)?.name || 'صنف محذوف', q: r3(q) + ' ' + (itemOf(id)?.unit || '') })), note: o.notes }); });
  S.corders.forEach(o => { if (o.st === 'cancel') return;
    oDepts(o).forEach(d => { let st = (o.prod || {})[d] || 'new'; if (o.st === 'ready' || o.st === 'done') st = 'sent';
      const lg = (o.prodLog || []).filter(x => (x.d || '') === d && x.st === 'sent').pop(), at = lg ? lg.at : o.doneAt;
      if (st === 'sent' && !isToday(at)) return;
      J.push({ k: 'co:' + o.id + ':' + d, kind: 'co', ck: kindOf(o), dept: d, chef: (o.chefs || {})[d], st, due: o.due, o, at,
        title: `${kindOf(o) === 'cake' ? 'كيك زبون' : 'طلب زبون'} #${o.no} · ${o.name}`, lines: o.lines.filter(l => (l.dept || '') === d).map(l => ({ name: l.name, q: qtyTxt(l), d: lineDesc(l), txt: l.txt, note: l.note, img: l.iid && itemOf(l.iid)?.img })), note: o.note }); }); });
  return J;
}
const canJob = j => j.chef === S.me.id || P('prod_all');
const NEXT = { new: ['prep', 'play', 'بلشت', 'p'], prep: ['ready', 'check', 'جهزت', 'g'], ready: ['sent', 'send', 'سلّمت', 'p'] };
function prodBoard(opt) {
  const all = P('prod_all') || opt.viewAll, mineOnly = !all || (P('prod') && S.mine), t = new Date(), tk = todayStr(), tm = addDays(tk, 1), kf = S.kf || 'all';
  let J = prodJobs().filter(j => (!opt.depts || opt.depts.has(j.dept)) && (!mineOnly || j.chef === S.me.id) && (!S.pdept || j.dept === S.pdept));
  J = J.filter(j => { const k = (j.due || '').slice(0, 10); return j.st === 'sent' || kf === 'all' || k <= tk || (kf === 'tom' && k === tm); }).sort((a, b) => a.due < b.due ? -1 : 1);
  let depts = all ? act(S.depts) : act(S.depts).filter(d => myDepts().includes(d.id)); if (opt.depts) depts = depts.filter(d => opt.depts.has(d.id));
  const card = j => { const d = new Date(j.due), late = d < t && j.kind === 'co' && j.st !== 'sent', soon = !late && j.kind === 'co' && j.st !== 'sent' && d - t < 2 * 36e5, ph = j.kind === 'co' && j.o.ph, nx = NEXT[j.st], img = j.kind === 'co' && j.lines.find(l => l.img);
    return `<div class="kc ${late ? 'late' : soon ? 'soon' : ''} ${j.st === 'sent' ? 'kdone' : ''}"><div class="kch"><span>${deptDot(j.dept)} ${esc(deptName(j.dept))}</span><span>${late ? '⚠ متأخر · ' : ''}${(j.due || '').slice(0, 10) === tk ? 'اليوم' : dayName((j.due || '').slice(0, 10))}${j.kind === 'co' ? ' · <b>' + fT(d) + '</b>' : ''}</span></div>
      <div class="kct">${j.kind === 'co' ? ic(j.ck === 'cake' ? 'cake' : 'bag') : ic('store')} ${esc(j.title)}</div>
      <div class="kcb"><div class="grow">${j.lines.map(l => `<div class="kl"><b>${esc(l.name)}</b> <span class="kq">${esc(l.q)}</span>${l.d ? `<div class="muted small">${esc(l.d)}</div>` : ''}${l.txt ? `<div class="ktx">✍️ «${esc(l.txt)}»</div>` : ''}${l.note ? `<div class="knt">📝 ${esc(l.note)}</div>` : ''}</div>`).join('')}</div>
        ${ph ? `<span class="ophw"><img class="oph" data-ph="${j.o.id}" data-a="ophv" data-id="${j.o.id}" alt="" src="data:image/gif;base64,R0lGODlhAQABAAAAACw=">${(j.o.phn || 1) > 1 ? `<i>${j.o.phn}</i>` : ''}</span>` : img ? `<img class="oph" src="${img.img}" alt="" data-a="kimg" data-src="${img.img}">` : ''}</div>
      ${j.note ? `<div class="knt">📝 ${esc(j.note)}</div>` : ''}
      <div class="kf"><span class="muted small">الشيف: <b>${esc(userOf(j.chef)?.full_name || '—')}</b></span>
      ${j.st === 'sent' ? `<span class="chip done">${j.kind === 'po' ? (j.o.status === 'done' ? 'استلمتها الصالة ✓' : 'بانتظار استلام الصالة') : j.o.st === 'done' ? 'انسلّم للزبون ✓' : 'عند الكاونتر'}</span>`
        : canJob(j) ? `<button class="btn ${nx[3]}" data-a="pjob" data-k="${j.k}" data-to="${nx[0]}">${ic(nx[1])} ${nx[2]}</button>` : `<span class="chip">${PST[j.st]}</span>`}</div></div>`; };
  const cols = [['new', 'جديد'], ['prep', 'بلشت'], ['ready', 'جهزت'], ['sent', 'سلّمت اليوم']];
  $('#view').innerHTML = `${opt.head || ''}<div class="toolbar">${seg('data-kf', [['all', 'كل المفتوح'], ['tom', 'لحد باجر'], ['today', 'لحد اليوم']], kf)}<span class="sp"></span>
    ${depts.length > 1 ? `<select class="inp" id="pDept" style="width:auto"><option value="">${all ? 'كل الأقسام' : 'كل أقسامي'}</option>${depts.map(d => `<option value="${d.id}" ${d.id === S.pdept ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select>` : ''}
    ${all && P('prod') ? `<label class="row small muted" style="gap:6px"><input type="checkbox" id="mine" ${S.mine ? 'checked' : ''}> شغلي فقط</label>` : ''}</div>
    ${!all && !myDepts().length ? `<div class="alert warn">${ic('alert')}<div>إنت مو مربوط بأي قسم إنتاج بعد. المدير يربطك من «أقسام الإنتاج والشيفات».</div></div>` : ''}
    <div class="kcols k4">${cols.map(([s, l]) => { const L = J.filter(j => j.st === s); if (s === 'sent') L.sort((a, b) => (b.at || 0) > (a.at || 0) ? 1 : -1); return `<section class="kcol k-${s}"><h3>${l} <em>${L.length}</em></h3>${L.length ? L.map(card).join('') : '<p class="kemp">ماكو</p>'}</section>`; }).join('')}</div>`;
  loadPh();
}
R.production = () => prodBoard({});
/* مطبخ الكيك: طلبات كيك الزبائن + طلبيات كيك الصالة (للعرض) */
R.k_kit = () => { const cd = cakeDepts(), chef = myDepts().some(d => cd.has(d));
  prodBoard({ depts: cd, viewAll: !chef && P('c_kitchen'), head: `<div class="alert">${ic('cake')}<div>هنا شغل الكيك كله: <b>طلبات كيك الزبائن</b> و<b>طلبيات كيك الصالة للعرض</b>. كل شيف يشوف شغله ويضغط <b>بلشت ← جهزت ← سلّمت</b>.</div></div>` }); };
H.click.push(async (t, ds) => {
  if (ds.kf) { S.kf = ds.kf; return render(), true; }
  if (ds.a === 'kimg') { viewImg(ds.src, ''); return true; }
  if (ds.a !== 'pjob') return;
  const [kind, id, dept] = ds.k.split(':'), to = ds.to, now = new Date().toISOString(), L = { prep: 'بلشت', ready: 'جهزت', sent: 'سلّمت' }[to];
  t.disabled = true;
  if (kind === 'po') { const o = S.porders.find(x => x.id === id); if (!o) return true; o.status = to === 'prep' ? 'prod' : to; o[to === 'prep' ? 'prod_at' : to + '_at'] = now; o.prod_by = S.me.full_name;
    await DB.upsert('kitchen_orders', o); logAdd(`${L} · طلبية الصالة (${deptName(o.dept)}) ليوم ${o.for_date}`, 'prod');
    if (to === 'sent') { notify(`سلّمت ✓ طلبية ${deptName(o.dept)} بانتظار تأكيد استلام الصالة`); render(); return true; } }
  else { const o = findCO(id); if (!o) return true; o.prod = o.prod || {}; o.prod[dept || ''] = to; (o.prodLog = o.prodLog || []).push({ d: dept || '', st: to, at: Date.now(), by: S.me.full_name }); syncSt(o);
    await saveCO(o, `${L} ${deptName(dept)} للطلب #${o.no}${o.st === 'ready' ? ' · الطلب كله وصل الكاونتر' : ''}`);
    if (o.st === 'ready' && await confirmBox(`الطلب #${o.no} صار عند الكاونتر. ترسل رسالة للزبون على واتساب؟`, 'إرسال')) waReady(o); }
  toast(L + ' ✓'); render(); return true;
});
H.change.push(async t => { if (t.id === 'mine') { S.mine = t.checked; render(); return true; } });
