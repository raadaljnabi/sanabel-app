"""يبني ملفات public/ للرفع على Firebase. شغّله بعد أي تعديل داخل src/:  python3 build.py"""
import os, shutil, json
R = os.path.dirname(os.path.abspath(__file__)); P = os.path.join(R, 'public')
rd = lambda p: open(os.path.join(R, 'src', p), encoding='utf-8').read()
FB = 'https://www.gstatic.com/firebasejs/10.14.1/'
JS = ['perms.js', 'db.js', 'core.js', 'hall.js', 'prod.js', 'qr.js', 'sales.js', 'print.js', 'admin.js']
if os.path.exists(P): shutil.rmtree(P)
os.makedirs(P)
html = f'''<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#331701"><title>سنابل الطاحونة</title>
<link rel="manifest" href="manifest.webmanifest"><meta name="mobile-web-app-capable" content="yes">
<link rel="icon" href="icon-192.png"><link rel="apple-touch-icon" href="icon-192.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&family=Cairo:wght@400;700;800&family=Almarai:wght@400;700;800&display=swap" rel="stylesheet">
<style>{rd("styles.css")}</style></head>
<body>{rd("splash.html")}<div id="root"></div><div id="pd" hidden></div><div id="modalRoot"></div>
<script src="config.js"></script>
<script src="{FB}firebase-app-compat.js"></script><script src="{FB}firebase-auth-compat.js"></script><script src="{FB}firebase-firestore-compat.js"></script>
<script>
{chr(10).join(rd(f) for f in JS)}
boot();
</script></body></html>'''
open(os.path.join(P, 'index.html'), 'w', encoding='utf-8').write(html)
for f in ['config.js', 'privacy.html', 'up.html']: shutil.copy(os.path.join(R, 'src', f), P)
for f in os.listdir(os.path.join(R, 'assets')): shutil.copy(os.path.join(R, 'assets', f), P)
json.dump({"id": "/", "name": "سنابل الطاحونة", "short_name": "سنابل الطاحونة", "description": "الكيك والمخبز والصالة والمستودع بتطبيق واحد.",
  "lang": "ar", "dir": "rtl", "start_url": "/", "scope": "/", "display": "standalone", "orientation": "any", "background_color": "#F6F2ED", "theme_color": "#331701", "categories": ["business", "productivity"],
  "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"}, {"src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"}, {"src": "icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}]},
  open(os.path.join(P, 'manifest.webmanifest'), 'w', encoding='utf-8'), ensure_ascii=False)
os.makedirs(os.path.join(P, '.well-known'), exist_ok=True)
if os.path.exists(os.path.join(R, 'assetlinks.json')): shutil.copy(os.path.join(R, 'assetlinks.json'), os.path.join(P, '.well-known', 'assetlinks.json'))
# الكاش: ملفات التطبيق + مكتبة Firebase والخطوط حتى يفتح بدون إنترنت بعد أول تشغيل
open(os.path.join(P, 'sw.js'), 'w', encoding='utf-8').write("""const C='sanabel-v4-1';const F=['./','index.html','config.js','logo.png','icon-192.png','manifest.webmanifest'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))));self.clients.claim()});
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET')return;
const lib=u.origin==='https://www.gstatic.com'&&u.pathname.startsWith('/firebasejs/'),font=u.origin==='https://fonts.googleapis.com'||u.origin==='https://fonts.gstatic.com';
if(u.origin!==location.origin&&!lib&&!font)return;
if(lib||font){e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(n=>{const c=n.clone();caches.open(C).then(x=>x.put(e.request,c));return n})));return}
e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(C).then(x=>x.put(e.request,c));return r}).catch(()=>caches.match(e.request,{ignoreSearch:true})))});
""")
shutil.copy(os.path.join(R, 'src', 'offline.html'), os.path.join(R, 'android', 'app', 'src', 'main', 'assets', 'offline.html'))
print('built', sorted(os.listdir(P)))
